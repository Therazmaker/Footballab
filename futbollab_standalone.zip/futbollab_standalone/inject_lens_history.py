import os
import json
import uuid
import datetime

profiles_dir = 'brain/database/profiles'
tracker_dir = 'brain/database/tracker'

def get_team_map():
    team_map = {}
    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(profiles_dir, f), 'r', encoding='utf-8') as j:
                p = json.load(j)
                name = p.get('teamName', '')
                tid = p.get('teamId', '')
                if name and tid:
                    team_map[name.lower()] = tid
        except: continue
    return team_map

def find_id(name, team_map):
    name = name.lower()
    for k, v in team_map.items():
        if name == k or name in k or k in name: return v
    overrides = {
        "marseille": "marsella", "nice": "niza", "rennes": "stade rennais",
        "monaco": "mónaco", "strasbourg": "estrasburgo", "psg": "psg"
    }
    if name in overrides:
        target = overrides[name]
        for k, v in team_map.items():
            if target in k: return v
    return None

team_map = get_team_map()
lens_id = team_map.get('lens')

# All matches for Lens 25/26 season (up to matchday 32)
lens_all_matches = [
    {"date": "2025-08-16", "home": "Lens", "away": "Lyon", "score": "0-1"},
    {"date": "2025-08-24", "home": "Le Havre", "away": "Lens", "score": "1-2"},
    {"date": "2025-08-29", "home": "Lens", "away": "Brest", "score": "3-1"},
    {"date": "2025-09-14", "home": "PSG", "away": "Lens", "score": "2-0"},
    {"date": "2025-09-20", "home": "Lens", "away": "Lille", "score": "3-0"},
    {"date": "2025-09-28", "home": "Stade Rennais", "away": "Lens", "score": "0-0"},
    {"date": "2025-10-04", "home": "Auxerre", "away": "Lens", "score": "1-2"},
    {"date": "2025-10-19", "home": "Lens", "away": "Paris FC", "score": "2-1"},
    {"date": "2025-10-25", "home": "Lens", "away": "Marsella", "score": "2-1"},
    {"date": "2025-10-29", "home": "Metz", "away": "Lens", "score": "2-0"},
    {"date": "2025-11-02", "home": "Lens", "away": "Lorient", "score": "3-0"},
    {"date": "2025-11-08", "home": "Mónaco", "away": "Lens", "score": "1-4"},
    {"date": "2025-11-22", "home": "Lens", "away": "Estrasburgo", "score": "1-0"},
    {"date": "2025-11-30", "home": "Angers", "away": "Lens", "score": "1-2"},
    {"date": "2025-12-06", "home": "Nantes", "away": "Lens", "score": "1-2"},
    {"date": "2025-12-14", "home": "Lens", "away": "Niza", "score": "2-0"},
    {"date": "2026-01-02", "home": "Toulouse", "away": "Lens", "score": "0-3"},
    {"date": "2026-01-17", "home": "Lens", "away": "Auxerre", "score": "1-0"},
    {"date": "2026-01-24", "home": "Marsella", "away": "Lens", "score": "3-1"},
    {"date": "2026-01-30", "home": "Lens", "away": "Le Havre", "score": "1-0"},
    {"date": "2026-02-07", "home": "Lens", "away": "Stade Rennais", "score": "3-1"},
    {"date": "2026-02-14", "home": "Paris FC", "away": "Lens", "score": "0-5"},
    {"date": "2026-02-21", "home": "Lens", "away": "Mónaco", "score": "2-3"},
    {"date": "2026-02-27", "home": "Estrasburgo", "away": "Lens", "score": "1-1"},
    {"date": "2026-03-08", "home": "Lens", "away": "Metz", "score": "3-0"},
    # The others are already in from previous update
]

print(f"Inyectando {len(lens_all_matches)} partidos históricos del Lens...")

for m in lens_all_matches:
    h_id = find_id(m['home'], team_map)
    a_id = find_id(m['away'], team_map)
    
    if not h_id or not a_id:
        print(f"Error IDs: {m['home']} vs {m['away']}")
        continue
        
    m_id = f"tr_{uuid.uuid4().hex[:12]}"
    score_parts = m['score'].split('-')
    
    match_obj = {
        "id": m_id, "leagueId": "lg_z0lkmnis0ge", "date": m['date'],
        "homeId": h_id, "awayId": a_id,
        "homeGoals": int(score_parts[0]), "awayGoals": int(score_parts[1]),
        "homeName": m['home'], "awayName": m['away'],
        "note": "Temporada Completa 25/26 (Inyectado)",
        "opponentStrengthByTeam": {}
    }
    
    with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
        json.dump(match_obj, j, indent=2)
    
    for tid in [h_id, a_id]:
        profile_file = os.path.join(profiles_dir, f"id_{tid}.json")
        if not os.path.exists(profile_file): continue
        with open(profile_file, 'r', encoding='utf-8') as j:
            p = json.load(j)
        if 'matchRefs' not in p: p['matchRefs'] = []
        if not any(ref.get('date') == m['date'] for ref in p['matchRefs']):
            p['matchRefs'].append({
                "memoryId": m_id, "teamId": tid, "teamName": p.get('teamName'),
                "date": m['date'], "opponent": m['away'] if tid == h_id else m['home'],
                "score": m['score']
            })
            p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
            with open(profile_file, 'w', encoding='utf-8') as j:
                json.dump(p, j, indent=2)

print("Inyección histórica completada.")

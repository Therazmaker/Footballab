import json
import os

# Paths
BACKUP_FILE = 'footballlab-brain-backup-v1-20260313-1711.json'
BRAIN_DIR = 'brain'

# Same structure as app.py
DB_SUBDIRS = {
    'teams': os.path.join(BRAIN_DIR, 'database', 'teams'),
    'leagues': os.path.join(BRAIN_DIR, 'database', 'leagues'),
    'tracker': os.path.join(BRAIN_DIR, 'database', 'tracker'),
    'players': os.path.join(BRAIN_DIR, 'database', 'players'),
    'profiles': os.path.join(BRAIN_DIR, 'database', 'profiles'),
    'meta': os.path.join(BRAIN_DIR, 'meta'),
    'general': os.path.join(BRAIN_DIR, 'general')
}

for path in DB_SUBDIRS.values():
    os.makedirs(path, exist_ok=True)

def sanitize(name):
    return "".join([c for c in name if c.isalnum() or c in (' ', '.', '_', ':')]).rstrip().replace(':', '_').replace(' ', '_')

def run_import():
    if not os.path.exists(BACKUP_FILE):
        print(f"Error: No se encuentra el archivo {BACKUP_FILE}")
        return

    print(f"Iniciando importación granular desde {BACKUP_FILE}...")
    
    with open(BACKUP_FILE, 'r', encoding='utf-8') as f:
        backup = json.load(f)
    
    data = backup.get('data', {})
    
    # 1. Process footballDB from localStorageDump
    ls_dump = data.get('localStorageDump', {})
    if 'footballDB' in ls_dump:
        print("Procesando footballDB...")
        db = json.loads(ls_dump['footballDB'])
        
        # Save teams
        for team in db.get('teams', []):
            tid = team.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['teams'], f"{sanitize(tid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(team, f, indent=2, ensure_ascii=False)
        
        # Save leagues
        for league in db.get('leagues', []):
            lid = league.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['leagues'], f"{sanitize(lid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(league, f, indent=2, ensure_ascii=False)
        
        # Save tracker
        for match in db.get('tracker', []):
            mid = match.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['tracker'], f"{sanitize(mid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(match, f, indent=2, ensure_ascii=False)

        # Save players
        for player in db.get('players', []):
            pid = player.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['players'], f"{sanitize(pid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(player, f, indent=2, ensure_ascii=False)

        # Skeleton
        skeleton = db.copy()
        for k in ['teams', 'leagues', 'tracker', 'players']: skeleton[k] = []
        with open(os.path.join(DB_SUBDIRS['meta'], "footballDB_skeleton.json"), 'w', encoding='utf-8') as f:
            json.dump(skeleton, f, indent=2, ensure_ascii=False)

    # 2. Process FL_BRAIN_V2
    if 'FL_BRAIN_V2' in ls_dump:
        print("Procesando FL_BRAIN_V2...")
        brain = json.loads(ls_dump['FL_BRAIN_V2'])
        profiles = brain.get('teamProfiles', {})
        for tid, profile in profiles.items():
            with open(os.path.join(DB_SUBDIRS['profiles'], f"{sanitize(tid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(profile, f, indent=2, ensure_ascii=False)
        
        # Skeleton
        skeleton = brain.copy()
        skeleton['teamProfiles'] = {}
        with open(os.path.join(DB_SUBDIRS['meta'], "FL_BRAIN_V2_skeleton.json"), 'w', encoding='utf-8') as f:
            json.dump(skeleton, f, indent=2, ensure_ascii=False)

    # 3. Other LS keys
    for key, val_str in ls_dump.items():
        if key in ['footballDB', 'FL_BRAIN_V2']: continue
        try:
            val = json.loads(val_str)
            with open(os.path.join(DB_SUBDIRS['meta'], f"{sanitize(key)}.json"), 'w', encoding='utf-8') as f:
                json.dump(val, f, indent=2, ensure_ascii=False)
        except:
            with open(os.path.join(DB_SUBDIRS['meta'], f"{sanitize(key)}.json"), 'w', encoding='utf-8') as f:
                f.write(val_str)

    print("Importación granular completada.")

if __name__ == '__main__':
    run_import()

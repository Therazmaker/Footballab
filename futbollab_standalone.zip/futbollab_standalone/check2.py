import os, json
tr_dir = 'brain/database/tracker'
wrong = []
for f in os.listdir(tr_dir):
    p = os.path.join(tr_dir, f)
    with open(p, 'r', encoding='utf-8') as j: m = json.load(j)
    if m.get('leagueId') == 'lg_z0lkmnis0ge':
        hn = m.get('homeName','').lower()
        an = m.get('awayName','').lower()
        if not hn or not an or hn in ['psg','mónaco','monaco','marsella','marseille','lens','lille','niza','nice','lyon','stade rennais','rennes','reims','toulouse','estrasburgo','strasbourg','montpellier','nantes','le havre','auxerre','angers','saint-étienne','saint-etienne','brest','metz','paris fc','lorient'] or an in ['psg','mónaco','monaco','marsella','marseille','lens','lille','niza','nice','lyon','stade rennais','rennes','reims','toulouse','estrasburgo','strasbourg','montpellier','nantes','le havre','auxerre','angers','saint-étienne','saint-etienne','brest','metz','paris fc','lorient']:
            wrong.append(f"{hn} vs {an}")
print("Ligue 1 teams or empty in Serie A:", len(wrong), wrong[:10])

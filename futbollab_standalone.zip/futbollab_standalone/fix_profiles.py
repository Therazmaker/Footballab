import os, json

profiles_dir = 'brain/database/profiles'
tr_dir = 'brain/database/tracker'

tracker_files = set(f.replace('.json', '') for f in os.listdir(tr_dir) if f.endswith('.json'))

cleaned = 0
total_removed = 0

for f in os.listdir(profiles_dir):
    if not f.endswith('.json'): continue
    p = os.path.join(profiles_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        profile = json.load(j)
    
    old_refs = profile.get('matchRefs', [])
    new_refs = [ref for ref in old_refs if ref.get('memoryId', '') in tracker_files]
    
    removed = len(old_refs) - len(new_refs)
    if removed > 0:
        profile['matchRefs'] = new_refs
        profile['updatedAt'] = int(__import__('datetime').datetime.now().timestamp() * 1000)
        with open(p, 'w', encoding='utf-8') as j:
            json.dump(profile, j, indent=2, ensure_ascii=False)
        cleaned += 1
        total_removed += removed

print(f"Perfiles limpiados: {cleaned}")
print(f"Referencias rotas eliminadas: {total_removed}")
print("Listo.")

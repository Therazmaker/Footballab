function renderEvents(events) {
    const logs = document.getElementById("sr-interceptor-logs");
    const status = document.getElementById("sr-status");
    
    if (events && events.length > 0) {
        status.innerHTML = "🟢 Capturando";
        status.style.background = "rgba(34, 197, 94, 0.4)";
        logs.innerHTML = "";
        
        events.forEach(evento => {
            const item = document.createElement("div");
            item.className = `log-item ${evento.team}`;
            item.innerHTML = `
                <span><strong style="color:#94a3b8">[${evento.interval}]</strong> ${evento.action}</span>
                <span style="font-weight:bold; font-size:10px; opacity:0.7; margin-top:2px;">${evento.team}</span>
            `;
            logs.appendChild(item);
        });
    }
}

// Cargar estado inicial
chrome.storage.local.get({ sr_events: [] }, (result) => {
    renderEvents(result.sr_events);
});

// Escuchar cambios en vivo
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.sr_events) {
        renderEvents(changes.sr_events.newValue);
    }
});

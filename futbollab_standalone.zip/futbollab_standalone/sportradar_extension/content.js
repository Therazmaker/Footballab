console.log("⚽ [Sportradar Interceptor] MAIN Extensión cargada en este frame:", window.location.href);

const originalFetch = window.fetch;
window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    try {
        const url = args[0] instanceof Request ? args[0].url : args[0];
        if (typeof url === 'string' && url.includes('sportradar') && url.includes('match_')) {
            const cloned = response.clone();
            cloned.json().then(data => procesarEventos(data, url)).catch(e => {});
        }
    } catch (e) {}
    return response;
};

const XHR = window.XMLHttpRequest;
const originalOpen = XHR.prototype.open;
const originalSend = XHR.prototype.send;
XHR.prototype.open = function(method, url) {
    this._url = url;
    return originalOpen.apply(this, arguments);
};
XHR.prototype.send = function() {
    this.addEventListener('load', function() {
        try {
            if (typeof this._url === 'string' && this._url.includes('sportradar') && this._url.includes('match_')) {
                const data = JSON.parse(this.responseText);
                procesarEventos(data, this._url);
            }
        } catch(e) {}
    });
    return originalSend.apply(this, arguments);
};

const eventosProcesados = new Set();

// Enviamos un ping para avisar que sí estamos vivos dentro del frame de Sportradar
setInterval(() => {
    window.postMessage({ type: "SPORTRADAR_PING", data: window.location.href }, "*");
}, 5000);

function procesarEventos(data, url) {
    // Intentar buscar la lista de eventos en varias posibles estructuras
    let events = null;
    
    if (data && data.doc && data.doc[0] && data.doc[0].data) {
        if (data.doc[0].data.events) events = data.doc[0].data.events;
        else if (data.doc[0].data.timeline) events = data.doc[0].data.timeline;
    } else if (data && data.events) {
        events = data.events;
    } else if (data && data.timeline) {
        events = data.timeline;
    } else if (data && data.match && data.match.events) {
        events = data.match.events;
    }

    if (!events || !Array.isArray(events)) return;

    const match = url.match(/match_[a-z]+\/(\d+)/);
    const matchId = match ? match[1] : 'unknown';

    events.forEach(ev => {
        const eventId = ev.id || `${ev.match_time || ev.time}_${ev.type}_${ev.team}`;
        if (eventosProcesados.has(eventId)) return;
        eventosProcesados.add(eventId);

        const min = ev.match_time || ev.time;
        const type = ev.type; 
        const team = ev.team; 

        let interval = getInterval(min);
        let actionType = mapAction(type);

        if (interval && actionType) {
            const eventoObj = {
                matchId: matchId,
                minute: min,
                interval: interval,
                action: actionType,
                team: team === "home" ? "LOCAL" : (team === "away" ? "VISITANTE" : "NONE"),
                rawType: type,
                timestamp: new Date().toISOString()
            };
            enviarABackend(eventoObj);
            window.postMessage({ type: "SPORTRADAR_EVENT", data: eventoObj }, "*");
        }
    });
}

function getInterval(minute) {
    if (minute == null) return null;
    if (minute <= 15) return "0-15'";
    if (minute <= 30) return "15-30'";
    if (minute <= 45) return "30-45'";
    if (minute <= 60) return "45-60'";
    if (minute <= 75) return "60-75'";
    if (minute <= 90) return "75-90'";
    return "90+'";
}

function mapAction(type) {
    const typeStr = (type || "").toLowerCase();
    
    if (typeStr === "dangerous_attack") return "Atq. Peligroso";
    if (typeStr === "attack") return "Ataque";
    if (typeStr === "safe_possession") return "Posesión";
    if (typeStr === "corner_kick" || typeStr === "corner") return "Corner";
    if (typeStr.includes("goal") && !typeStr.includes("kick")) return "Gol";
    if (typeStr.includes("free_kick")) return "Tiro Libre";
    if (typeStr.includes("foul") || typeStr.includes("card")) return "Falta";
    if (typeStr.includes("offside")) return "Fuera Juego";
    if (typeStr.includes("save")) return "Parada";
    
    return null; 
}

function enviarABackend(evento) {
    window.originalFetch = window.originalFetch || window.fetch;
    
    originalFetch("http://127.0.0.1:5000/api/tracker/push_event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(evento)
    }).catch(err => {});
}

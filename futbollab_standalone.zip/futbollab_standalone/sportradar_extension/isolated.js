console.log("⚽ [Sportradar Interceptor] ISOLATED script cargado.");

window.addEventListener("message", (event) => {
    // Solo aceptamos mensajes de la misma ventana
    if (event.source !== window) return;

    if (event.data && event.data.type === "SPORTRADAR_EVENT") {
        const evento = event.data.data;
        
        // Guardamos en chrome.storage
        chrome.storage.local.get({ sr_events: [] }, (result) => {
            let events = result.sr_events;
            events.unshift(evento); // añadir al principio
            if (events.length > 20) events.pop(); // mantener maximo 20
            
            chrome.storage.local.set({ sr_events: events });
        });
    }
});

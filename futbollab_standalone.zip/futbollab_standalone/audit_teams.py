import os, json

teams_dir = 'brain/database/teams'
SERIE_A_ID = 'lg_z0lkmnis0ge'
LIGUE1_ID = 'lg_f06f449614c'

SERIE_A_TEAMS = {
    'inter', 'milan', 'ac milan', 'juventus', 'atalanta', 'roma', 'lazio',
    'napoli', 'fiorentina', 'torino', 'bologna', 'genoa', 'monza', 'lecce',
    'udinese', 'verona', 'cagliari', 'empoli', 'parma', 'como', 'venezia',
    'hellas verona'
}

LIGUE1_TEAMS = {
    'psg', 'paris saint-germain', 'monaco', 'marsella', 'marseille',
    'lens', 'lille', 'niza', 'nice', 'lyon',
    'stade rennais', 'rennes', 'reims', 'toulouse', 'estrasburgo', 'strasbourg',
    'montpellier', 'nantes', 'le havre', 'auxerre', 'angers',
    'brest', 'metz', 'paris fc', 'lorient'
}

# Check what leagueId all teams have
print("=== TODOS los equipos por liga ===")
no_league = []
in_sa = []
in_l1 = []
other = []

for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
        t = json.load(j)
    name = t.get('name', '')
    nl = name.lower()
    league = t.get('leagueId', '')
    
    if not league:
        no_league.append(name)
    elif league == SERIE_A_ID:
        in_sa.append(name)
    elif league == LIGUE1_ID:
        in_l1.append(name)
    else:
        other.append((name, league))

print(f"\nSin liga ({len(no_league)}): {no_league}")
print(f"\nEn Serie A ({len(in_sa)}): {in_sa}")
print(f"\nEn Ligue 1 ({len(in_l1)}): {in_l1}")
print(f"\nOtra liga ({len(other)}): {other[:20]}")

# Now fix: any team whose name matches a Serie A team but has wrong leagueId
print("\n=== Buscando equipos de Serie A con leagueId incorrecto ===")
needs_fix_sa = []
for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
        t = json.load(j)
    name = t.get('name', '')
    nl = name.lower()
    league = t.get('leagueId', '')
    
    if nl in SERIE_A_TEAMS and league != SERIE_A_ID:
        needs_fix_sa.append((f, name, league))
        print(f"  NECESITA FIX: {name} esta en liga '{league}' pero deberia estar en Serie A")

# Fix them
for f, name, old_league in needs_fix_sa:
    p = os.path.join(teams_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        t = json.load(j)
    t['leagueId'] = SERIE_A_ID
    with open(p, 'w', encoding='utf-8') as j:
        json.dump(t, j, indent=2, ensure_ascii=False)

if needs_fix_sa:
    print(f"\nCorregidos {len(needs_fix_sa)} equipos -> Serie A")

# Count again
sa_count = sum(1 for f in os.listdir(teams_dir) if f.endswith('.json') and json.load(open(os.path.join(teams_dir,f),'r',encoding='utf-8')).get('leagueId') == SERIE_A_ID)
print(f"\nTotal equipos en Serie A ahora: {sa_count}")

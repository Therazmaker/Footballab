import os
import json

tracker_dir = 'brain/database/tracker'
lens_id = 'tm_gqi13oasmeo'

results = []
for f in os.listdir(tracker_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(tracker_dir, f), 'r', encoding='utf-8') as j:
        data = json.load(j)
        if data.get('homeId') == lens_id or data.get('awayId') == lens_id:
            results.append({
                "date": data.get('date'),
                "home": data.get('homeName'),
                "away": data.get('awayName'),
                "score": f"{data.get('homeGoals')}-{data.get('awayGoals')}",
                "note": data.get('note')
            })

results.sort(key=lambda x: x['date'] if x['date'] else "")
print(json.dumps(results, indent=2))

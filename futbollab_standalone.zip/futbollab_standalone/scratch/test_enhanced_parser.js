
const fs = require('fs');

function sectionToPos(text) {
    const t = String(text || "").toLowerCase();
    if (t.includes("portero")) return "GK";
    if (t.includes("defensa")) return "DF";
    if (t.includes("centrocamp") || t.includes("medio")) return "MF";
    if (t.includes("delanter")) return "FW";
    return "OT";
}

function normalizePlayerPos(pos) {
    if (!pos) return "OT";
    const p = String(pos).trim().toUpperCase();
    if (p === "GK" || p === "POR" || p === "PORTERO") return "GK";
    if (p === "DF" || p === "DEF" || p === "DEFENSA") return "DF";
    if (p === "MF" || p === "MED" || p === "MEDIO" || p === "CENTROCAMPISTA") return "MF";
    if (p === "FW" || p === "DEL" || p === "DELANTERO") return "FW";
    return "OT";
}

function parseManualSquadText(raw) {
    const lines = String(raw || "").split(/\r?\n/);
    const tokens = [];
    
    for (const line of lines) {
        const lineTrimmed = line.trim();
        if (!lineTrimmed) continue;
        
        if (lineTrimmed.includes('\t')) {
            tokens.push(...lineTrimmed.split('\t').map(t => t.trim()).filter(Boolean));
        } else {
            // Split by multiple spaces (>=2)
            const parts = lineTrimmed.split(/\s{2,}/);
            if (parts.length > 1) {
                tokens.push(...parts.map(t => t.trim()).filter(Boolean));
            } else {
                // If it's just one line, check if it has single spaces but looks like it might have multiple tokens
                // Flashscore sometimes has "43 de Gea David 35 36..."
                // If it starts with a number, then has text, then numbers...
                const match = lineTrimmed.match(/^(\d+)\s+(.*?)\s+(\d+.*)$/);
                if (match) {
                    tokens.push(match[1], match[2], ...match[3].split(/\s+/));
                } else {
                    tokens.push(lineTrimmed);
                }
            }
        }
    }

    const isNumericToken = (value) => /^-?\d+(?:[.,]\d+)?$/.test(String(value || "").trim());
    const toNumber = (value) => {
        const n = Number(String(value).replace(",", "."));
        return Number.isFinite(n) ? n : null;
    };
    const isHeaderToken = (value) => {
        const token = String(value || "").trim().toLowerCase();
        // Expand headers
        return ["#", "name", "nombre", "edad", "age", "min", "mins", "minutos", "pj", "apps", "goals", "goles", "a", "asistencias", "amarillas", "rojas", "ta", "tr", "pos", "p", "g", "pts"].includes(token);
    };
    const isSectionToken = (value) => {
        const token = String(value || "").trim().toLowerCase();
        return token.includes("portero") || token.includes("defensa") || token.includes("centrocamp") || token.includes("medio") || token.includes("delanter") || token.includes("otros");
    };
    const looksLikeName = (value) => {
        const token = String(value || "").trim();
        if (!token || isHeaderToken(token) || isSectionToken(token) || isNumericToken(token)) return false;
        return /[a-zA-Z\u00C0-\u017F]/.test(token);
    };

    const rows = [];
    let i = 0;
    let currentPos = "OT";
    while (i < tokens.length) {
        const token = tokens[i];
        if (isSectionToken(token)) {
            currentPos = sectionToPos(token);
            i += 1;
            continue;
        }
        if (isHeaderToken(token)) {
            i += 1;
            continue;
        }

        let number = null;
        let name = "";
        
        if (isNumericToken(token) && i + 1 < tokens.length && looksLikeName(tokens[i + 1])) {
            number = toNumber(token);
            name = tokens[i + 1];
            i += 2;
        } else if (looksLikeName(token)) {
            name = token;
            i += 1;
        } else {
            i += 1;
            continue;
        }

        const numericFields = [];
        while (i < tokens.length && isNumericToken(tokens[i]) && numericFields.length < 10) {
            const n = toNumber(tokens[i]);
            if (Number.isFinite(n)) numericFields.push(n);
            i += 1;
        }

        rows.push({
            name,
            pos: currentPos,
            number,
            age: numericFields[0] ?? null,
            appearances: numericFields[1] ?? null,
            minutes: numericFields[2] ?? null,
            goals: numericFields[3] ?? null,
            assists: numericFields[4] ?? null,
            yellowCards: numericFields[5] ?? null,
            redCards: numericFields[6] ?? null,
        });
    }

    return rows.filter((row) => row.name);
}

// Test with tab-separated format
const tabInput = `
Porteros	#	Nombre	Edad	PJ	MIN	G	A	TA	TR
43	de Gea David	35	36	3240	0	0	0	0
Defensas
62	Balbo Luis	20	4	181	0	0	0	0
15	Comuzzo Pietro	21	25	1587	1	0	2	0
`;
const tabResults = parseManualSquadText(tabInput);
console.log("Tab format results:", tabResults.length);
console.log(JSON.stringify(tabResults, null, 2));

const singleLineInput = "43 de Gea David 35 36 3240 0 0 0 0";
console.log("Single line results:", JSON.stringify(parseManualSquadText(singleLineInput), null, 2));

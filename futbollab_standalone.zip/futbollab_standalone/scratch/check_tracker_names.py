import json
import os

base_path = r'c:\Users\Herraz Marrero\Documents\MemoryCarl-main (4)\futbollab_standalone\brain\database'
tracker_path = os.path.join(base_path, 'tracker')
teams_path = os.path.join(base_path, 'teams')

teams = {}
for f in os.listdir(teams_path):
    if f.endswith('.json'):
        with open(os.path.join(teams_path, f), 'r', encoding='utf-8') as j:
            t = json.load(j)
            teams[t.get('id')] = t.get('name')

matches = []
for f in os.listdir(tracker_path):
    if f.endswith('.json'):
        with open(os.path.join(tracker_path, f), 'r', encoding='utf-8') as j:
            matches.append(json.load(j))

may9 = [m for m in matches if m.get('date') == '2026-05-09']
print(f"Games for 2026-05-09: {len(may9)}")
for m in may9:
    h = teams.get(m.get('homeId'), m.get('homeId'))
    a = teams.get(m.get('awayId'), m.get('awayId'))
    print(f"- {h} vs {a} (Goals: {m.get('homeGoals')}-{m.get('awayGoals')})")

import re

def parse_flashscore_dom(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    matches = []
    blocks = re.split(r'id="g_1_', content)
    for b in blocks[1:]:
        participants = re.findall(r'class="[^"]*wcl-name_jjfMf"[^>]*>([^<]+)</span>', b)
        if len(participants) < 2:
            participants = re.findall(r'class="event__(?:home|away)Participant"[^>]*>.*?>(.*?)</span>', b, re.DOTALL)
            if len(participants) < 2: continue
        
        home = participants[0].strip()
        away = participants[1].strip()
        
        score_home_match = re.search(r'event__score--home"[^>]*>(\d+)</span>', b)
        score_away_match = re.search(r'event__score--away"[^>]*>(\d+)</span>', b)
        
        if score_home_match and score_away_match:
            h_g = int(score_home_match.group(1))
            a_g = int(score_away_match.group(1))
            matches.append({
                'home': home,
                'away': away,
                'homeGoals': h_g,
                'awayGoals': a_g
            })
    return matches

m = parse_flashscore_dom('Ligue 1 DOM.txt')
print("Matches with Monaco or Reims in extracted matches:")
for match in m:
    if 'Monaco' in match['home'] or 'Mónaco' in match['home'] or 'Reims' in match['home'] or 'Monaco' in match['away'] or 'Mónaco' in match['away'] or 'Reims' in match['away']:
        print(f"  {match['home']} vs {match['away']}")

import os
import json

tracker_dir = 'brain/database/tracker'
scores = {}

for f in os.listdir(tracker_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(tracker_dir, f), 'r', encoding='utf-8') as j:
        data = json.load(j)
        score = f"{data.get('homeGoals', 0)}-{data.get('awayGoals', 0)}"
        scores[score] = scores.get(score, 0) + 1

print(json.dumps(scores, indent=2))

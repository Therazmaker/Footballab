import json
import os

db_path = r'c:\Users\Herraz Marrero\Documents\MemoryCarl-main (4)\futbollab_standalone\brain\database\tracker'
matches = []
for f in os.listdir(db_path):
    if f.endswith('.json'):
        with open(os.path.join(db_path, f), 'r', encoding='utf-8') as j:
            matches.append(json.load(j))

print(f"Total matches in tracker: {len(matches)}")
# Print games for May 9th
may9 = [m for m in matches if m.get('date') == '2026-05-09']
print(f"Games for 2026-05-09: {len(may9)}")
for m in may9:
    print(f"- {m.get('homeId')} vs {m.get('awayId')} (Goals: {m.get('homeGoals')}-{m.get('awayGoals')})")

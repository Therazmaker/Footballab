
const fs = require('fs');

function sectionToPos(text) {
    const t = String(text || "").toLowerCase();
    if (t.includes("portero")) return "GK";
    if (t.includes("defensa")) return "DF";
    if (t.includes("centrocamp") || t.includes("medio")) return "MF";
    if (t.includes("delanter")) return "FW";
    return "OT";
}

function parseManualSquadText(raw) {
    const tokens = String(raw || "")
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean);

    const isNumericToken = (value) => /^-?\d+(?:[.,]\d+)?$/.test(String(value || "").trim());
    const toNumber = (value) => {
        const n = Number(String(value).replace(",", "."));
        return Number.isFinite(n) ? n : null;
    };
    const isHeaderToken = (value) => {
        const token = String(value || "").trim().toLowerCase();
        return ["#", "name", "nombre", "edad", "age", "min", "mins", "minutos", "pj", "apps", "goals", "goles", "a", "asistencias", "amarillas", "rojas"].includes(token);
    };
    const isSectionToken = (value) => {
        const token = String(value || "").trim().toLowerCase();
        return token.includes("portero") || token.includes("defensa") || token.includes("centrocamp") || token.includes("medio") || token.includes("delanter") || token.includes("otros");
    };
    const looksLikeName = (value) => {
        const token = String(value || "").trim();
        if (!token || isHeaderToken(token) || isSectionToken(token) || isNumericToken(token)) return false;
        // Simple name check: contains at least one letter
        return /[a-zA-Z\u00C0-\u017F]/.test(token);
    };

    const rows = [];
    let i = 0;
    let currentPos = "OT";
    while (i < tokens.length) {
        const token = tokens[i];
        if (isSectionToken(token)) {
            currentPos = sectionToPos(token);
            i += 1;
            continue;
        }
        if (isHeaderToken(token)) {
            i += 1;
            continue;
        }

        let number = null;
        let name = "";
        if (isNumericToken(token) && looksLikeName(tokens[i + 1])) {
            number = toNumber(token);
            name = tokens[i + 1];
            i += 2;
        } else if (looksLikeName(token)) {
            name = token;
            i += 1;
        } else {
            i += 1;
            continue;
        }

        const numericFields = [];
        while (i < tokens.length && isNumericToken(tokens[i]) && numericFields.length < 7) {
            const n = toNumber(tokens[i]);
            if (Number.isFinite(n)) numericFields.push(n);
            i += 1;
        }

        rows.push({
            name,
            pos: currentPos,
            number,
            age: numericFields[0] ?? null,
            appearances: numericFields[1] ?? null,
            minutes: numericFields[2] ?? null,
            goals: numericFields[3] ?? null,
            assists: numericFields[4] ?? null,
            yellowCards: numericFields[5] ?? null,
            redCards: numericFields[6] ?? null,
        });
    }

    return rows.filter((row) => row.name);
}

const input = fs.readFileSync('flashscore_input.txt', 'utf8');
const results = parseManualSquadText(input);
console.log(JSON.stringify(results, null, 2));
console.log("Total players parsed:", results.length);

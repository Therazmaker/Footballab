import json
import os

base_path = r'c:\Users\Herraz Marrero\Documents\MemoryCarl-main (4)\futbollab_standalone\brain\database'
leagues_path = os.path.join(base_path, 'leagues')

leagues = []
for f in os.listdir(leagues_path):
    if f.endswith('.json'):
        with open(os.path.join(leagues_path, f), 'r', encoding='utf-8') as j:
            leagues.append(json.load(j))

for l in leagues:
    print(f"- {l.get('id')}: {l.get('name')} ({l.get('code')})")

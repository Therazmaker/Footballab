import re
content = open('Ligue 1 DOM.txt', encoding='utf-8').read()
blocks = re.split(r'id="g_1_', content)
for b in blocks:
    if 'Angers' in b and 'Toulouse' in b:
        # Find home and away
        participants = re.findall(r'class="[^"]*wcl-name_jjfMf"[^>]*>([^<]+)</span>', b)
        if len(participants) >= 2:
            print(f"{participants[0]} vs {participants[1]}")

import os
import json

PROFILES_DIR = 'brain/database/profiles'

def audit():
    print("Auditoría de partidos por equipo:")
    print("-" * 40)
    
    counts = {}
    for f in os.listdir(PROFILES_DIR):
        if f.endswith('.json'):
            path = os.path.join(PROFILES_DIR, f)
            with open(path, 'r', encoding='utf-8') as j:
                data = json.load(j)
                name = data.get('teamName', f)
                matches = data.get('matchRefs', [])
                if len(matches) > 0:
                    counts[name] = len(matches)
    
    # Sort by count
    sorted_counts = sorted(counts.items(), key=lambda x: x[1])
    for name, count in sorted_counts:
        print(f"{name}: {count} partidos")

if __name__ == '__main__':
    audit()

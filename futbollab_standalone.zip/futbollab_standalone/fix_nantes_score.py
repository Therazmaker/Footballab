import os
import json

tracker_dir = 'brain/database/tracker'
profiles_dir = 'brain/database/profiles'

# Files to fix/cleanup for Nantes 3-0 Marseille (2026-05-02)
files_to_fix = ['tr_534a24e76e6b.json', 'tr_5fb6ea38ab7c.json', 'tr_fa7ead07abb6.json']
correct_id = 'tr_nantes_marseille_fix'

print("Corrigiendo marcador: Nantes 3-0 Marseille...")

# 1. Update/Create the tracker file with correct score
match_data = None
for f in files_to_fix:
    path = os.path.join(tracker_dir, f)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as j:
            match_data = json.load(j)
        os.remove(path) # Cleanup old/wrong files

if match_data:
    match_data['homeGoals'] = 3
    match_data['awayGoals'] = 0
    match_data['date'] = '2026-05-02' # Ensure correct year
    match_data['note'] = 'MARCADOR CORREGIDO: Nantes 3-0 Marseille (Momentum de Supervivencia)'
    
    with open(os.path.join(tracker_dir, f"{correct_id}.json"), 'w', encoding='utf-8') as j:
        json.dump(match_data, j, indent=2)

# 2. Update Profiles (Nantes and Marseille)
for f in os.listdir(profiles_dir):
    if not f.endswith('.json'): continue
    path = os.path.join(profiles_dir, f)
    with open(path, 'r', encoding='utf-8') as j:
        p = json.load(j)
    
    updated = False
    if 'matchRefs' in p:
        new_refs = []
        for ref in p['matchRefs']:
            # If it's one of the old IDs or the correct date
            if ref.get('memoryId') in files_to_fix or (ref.get('date') in ['2026-05-02', '2025-05-02'] and 'Marseille' in str(ref) or 'Marsella' in str(ref)):
                ref['memoryId'] = correct_id
                ref['score'] = '3-0'
                ref['date'] = '2026-05-02'
                updated = True
            new_refs.append(ref)
        p['matchRefs'] = new_refs
    
    if updated:
        with open(path, 'w', encoding='utf-8') as j:
            json.dump(p, j, indent=2)

print("Marcador corregido y perfiles sincronizados.")

import os, json

teams_dir = 'brain/database/teams'
profiles_dir = 'brain/database/profiles'
tr_dir = 'brain/database/tracker'
SERIE_A_ID = 'lg_z0lkmnis0ge'
LIGUE1_ID  = 'lg_f06f449614c'

# Duplicados a fusionar: (nombre_a_ELIMINAR, nombre_a_CONSERVAR)
DUPLICATES = [
    ('Bologna',  'Bolonia'),    # conservamos el español "Bolonia"
    ('Monaco',   'Mónaco'),     # conservamos "Mónaco" con tilde
]

def get_all_teams():
    teams = {}
    for f in os.listdir(teams_dir):
        if not f.endswith('.json'): continue
        with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
            t = json.load(j)
        teams[t['name']] = (f, t)
    return teams

teams = get_all_teams()

for remove_name, keep_name in DUPLICATES:
    if remove_name not in teams or keep_name not in teams:
        print(f"Saltando {remove_name} -> {keep_name}: uno o ambos no encontrados")
        continue

    rm_file, rm_team = teams[remove_name]
    kp_file, kp_team = teams[keep_name]
    rm_id = rm_team['id']
    kp_id = kp_team['id']

    print(f"\nFusionando '{remove_name}' ({rm_id}) -> '{keep_name}' ({kp_id})")

    # 1. Actualizar todos los trackers que referencian el ID eliminado
    fixed_tr = 0
    for tf in os.listdir(tr_dir):
        if not tf.endswith('.json'): continue
        tp = os.path.join(tr_dir, tf)
        with open(tp, 'r', encoding='utf-8') as j:
            m = json.load(j)
        changed = False
        if m.get('homeId') == rm_id:
            m['homeId'] = kp_id; m['homeName'] = keep_name; changed = True
        if m.get('awayId') == rm_id:
            m['awayId'] = kp_id; m['awayName'] = keep_name; changed = True
        if changed:
            with open(tp, 'w', encoding='utf-8') as j:
                json.dump(m, j, indent=2, ensure_ascii=False)
            fixed_tr += 1
    print(f"  Trackers actualizados: {fixed_tr}")

    # 2. Mover el perfil del ID eliminado al ID conservado (si existe)
    rm_profile_path = os.path.join(profiles_dir, f"id_{rm_id}.json")
    kp_profile_path = os.path.join(profiles_dir, f"id_{kp_id}.json")
    if os.path.exists(rm_profile_path):
        with open(rm_profile_path, 'r', encoding='utf-8') as j:
            rm_profile = json.load(j)
        
        rm_refs = rm_profile.get('matchRefs', [])
        
        if os.path.exists(kp_profile_path):
            with open(kp_profile_path, 'r', encoding='utf-8') as j:
                kp_profile = json.load(j)
            existing_ids = {r['memoryId'] for r in kp_profile.get('matchRefs', [])}
            for ref in rm_refs:
                if ref['memoryId'] not in existing_ids:
                    ref['teamId'] = kp_id
                    ref['teamName'] = keep_name
                    kp_profile.setdefault('matchRefs', []).append(ref)
            with open(kp_profile_path, 'w', encoding='utf-8') as j:
                json.dump(kp_profile, j, indent=2, ensure_ascii=False)
        os.remove(rm_profile_path)
        print(f"  Perfil fusionado y eliminado: id_{rm_id}.json")

    # 3. Eliminar el equipo duplicado
    os.remove(os.path.join(teams_dir, rm_file))
    print(f"  Equipo eliminado: {rm_file}")

# Resultado final
teams = get_all_teams()
sa_teams = [n for n, (f,t) in teams.items() if t.get('leagueId') == SERIE_A_ID]
l1_teams = [n for n, (f,t) in teams.items() if t.get('leagueId') == LIGUE1_ID]
print(f"\n=== FINAL ===")
print(f"Serie A ({len(sa_teams)} equipos): {sorted(sa_teams)}")
print(f"Ligue 1 ({len(l1_teams)} equipos): {sorted(l1_teams)}")

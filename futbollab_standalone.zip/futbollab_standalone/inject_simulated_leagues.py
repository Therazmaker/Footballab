import os
import json
import uuid
import datetime
import random

teams_dir = 'brain/database/teams'
profiles_dir = 'brain/database/profiles'
tracker_dir = 'brain/database/tracker'
leagues_dir = 'brain/database/leagues'

def get_existing_teams():
    team_name_to_id = {}
    for f in os.listdir(teams_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
                t = json.load(j)
                if t.get('name') and t.get('id'):
                    team_name_to_id[t['name'].lower()] = t['id']
        except: continue
    return team_name_to_id

def ensure_league(name, code):
    for f in os.listdir(leagues_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(leagues_dir, f), 'r', encoding='utf-8') as j:
                l = json.load(j)
                if name.lower() in l.get('name', '').lower() or code.lower() == l.get('code', '').lower():
                    return l['id']
        except: continue
    
    lid = f"lg_{uuid.uuid4().hex[:11]}"
    league_obj = {
        "id": lid,
        "name": name,
        "code": code,
        "type": "league"
    }
    with open(os.path.join(leagues_dir, f"{lid}.json"), 'w', encoding='utf-8') as j:
        json.dump(league_obj, j, indent=2)
    return lid

def ensure_team(team_name, league_id, existing_teams):
    name_lower = team_name.lower()
    for k, v in existing_teams.items():
        if name_lower == k or name_lower in k or k in name_lower:
            return v
    
    tid = f"tm_{uuid.uuid4().hex[:11]}"
    team_obj = {
      "id": tid,
      "name": team_name,
      "apiTeamId": "",
      "leagueId": league_id,
      "meta": { "stadium": "", "city": "", "capacity": "" },
      "intProfile": {
        "priorityCompetition": "Liga", "seasonGoal": "", "squadDepth": 3,
        "coachRotation": 3, "styleTags": [], "derbyRivals": [], "seasonContext": "",
        "modeLens": "empresa", "seasonObjective": "", "coachRotationPolicy": 3,
        "psychTags": [], "rivalries": [],
        "seasonBase": { "pj": 0, "g": 0, "e": 0, "p": 0, "gf": 0, "gc": 0, "dg": 0, "pts": 0, "position": 0 }
      },
      "futureMatches": [], "intSnapshotsByMatchId": {}, "intPatterns": {}, "intMatchStateById": {},
      "contextoEstrategico": { "rachaLocal": "", "ausenciasClave": [], "patrones": [], "factorDia": {} }
    }
    with open(os.path.join(teams_dir, f"{tid}.json"), 'w', encoding='utf-8') as j:
        json.dump(team_obj, j, indent=2)
    
    existing_teams[name_lower] = tid
    return tid

def ensure_profile(tid, team_name):
    profile_path = os.path.join(profiles_dir, f"id_{tid}.json")
    if os.path.exists(profile_path):
        return
    prof_obj = {
        "teamId": tid,
        "teamName": team_name,
        "matchRefs": [],
        "updatedAt": int(datetime.datetime.now().timestamp() * 1000)
    }
    with open(profile_path, 'w', encoding='utf-8') as j:
        json.dump(prof_obj, j, indent=2)

def generate_matches(league_id, teams, start_date, matches_per_team):
    existing_teams = get_existing_teams()
    team_ids = {}
    for t, strength in teams.items():
        tid = ensure_team(t, league_id, existing_teams)
        ensure_profile(tid, t)
        team_ids[t] = tid

    # Create double round robin
    all_teams = list(teams.keys())
    matchups = []
    for i in range(len(all_teams)):
        for j in range(len(all_teams)):
            if i != j:
                matchups.append((all_teams[i], all_teams[j]))

    random.shuffle(matchups)
    # We only play `matches_per_team` / 2 * len(all_teams) total matches if the season isn't over.
    # To keep it simple, we simulate the whole season or up to matchday 32
    total_matches_to_play = int(len(all_teams) * (matches_per_team / 2))
    matchups = matchups[:total_matches_to_play]

    base_date = datetime.datetime.strptime(start_date, "%Y-%m-%d")
    matches_added = 0

    # Load all profiles into memory to update efficiently
    profiles = {}
    for tid in team_ids.values():
        p_path = os.path.join(profiles_dir, f"id_{tid}.json")
        with open(p_path, 'r', encoding='utf-8') as j:
            profiles[tid] = json.load(j)

    for home_name, away_name in matchups:
        h_id = team_ids[home_name]
        a_id = team_ids[away_name]
        
        # Simple poisson-ish simulation based on strength difference
        h_strength = teams[home_name] + 0.5  # Home advantage
        a_strength = teams[away_name]
        
        home_goals = max(0, int(random.gauss(h_strength, 1.0)))
        away_goals = max(0, int(random.gauss(a_strength, 1.0)))
        
        date_str = (base_date + datetime.timedelta(days=random.randint(0, 260))).strftime("%Y-%m-%d")
        m_id = f"tr_{uuid.uuid4().hex[:12]}"
        
        match_obj = {
            "id": m_id,
            "leagueId": league_id,
            "date": date_str,
            "homeId": h_id,
            "awayId": a_id,
            "homeGoals": home_goals,
            "awayGoals": away_goals,
            "homeName": home_name,
            "awayName": away_name,
            "note": "Generado 25/26",
            "opponentStrengthByTeam": {}
        }
        
        with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
            json.dump(match_obj, j, indent=2)
            
        score_str = f"{home_goals}-{away_goals}"
        
        p = profiles[h_id]
        if 'matchRefs' not in p: p['matchRefs'] = []
        p['matchRefs'].append({
            "memoryId": m_id, "teamId": h_id, "teamName": p.get('teamName'),
            "date": date_str, "opponent": away_name, "score": score_str
        })
        p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)

        p2 = profiles[a_id]
        if 'matchRefs' not in p2: p2['matchRefs'] = []
        p2['matchRefs'].append({
            "memoryId": m_id, "teamId": a_id, "teamName": p2.get('teamName'),
            "date": date_str, "opponent": home_name, "score": score_str
        })
        p2['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
        
        matches_added += 1

    # Save profiles back
    for tid, p in profiles.items():
        with open(os.path.join(profiles_dir, f"id_{tid}.json"), 'w', encoding='utf-8') as j:
            json.dump(p, j, indent=2)

    return matches_added

def main():
    print("Inyectando Ligue 1...")
    l1_id = ensure_league("Francia: Ligue 1", "FL1")
    ligue1_teams = {
        "PSG": 2.5, "Mónaco": 2.0, "Marsella": 1.9, "Lens": 1.8, "Lille": 1.8, 
        "Niza": 1.7, "Lyon": 1.8, "Stade Rennais": 1.7, "Reims": 1.4, "Toulouse": 1.4, 
        "Estrasburgo": 1.3, "Montpellier": 1.3, "Nantes": 1.3, "Le Havre": 1.1, 
        "Auxerre": 1.1, "Angers": 1.0, "Saint-Étienne": 1.1, "Brest": 1.5
    }
    m1 = generate_matches(l1_id, ligue1_teams, "2025-08-16", 32)
    print(f"Ligue 1 inyectada ({m1} partidos).")

    print("Inyectando Serie A...")
    sa_id = ensure_league("Italia: Serie A", "SA")
    seriea_teams = {
        "Inter": 2.4, "Milan": 2.1, "Juventus": 2.1, "Atalanta": 2.0, "Roma": 1.9, 
        "Lazio": 1.8, "Napoli": 2.0, "Fiorentina": 1.7, "Torino": 1.5, "Bologna": 1.6, 
        "Genoa": 1.3, "Monza": 1.2, "Lecce": 1.1, "Udinese": 1.2, "Verona": 1.1, 
        "Cagliari": 1.1, "Empoli": 1.0, "Parma": 1.1, "Como": 1.0, "Venezia": 0.9
    }
    m2 = generate_matches(sa_id, seriea_teams, "2025-08-16", 34)
    print(f"Serie A inyectada ({m2} partidos).")

if __name__ == '__main__':
    main()

import requests
import json

def analyze_trap():
    url = "http://127.0.0.1:5000/api/ollama"
    
    prompt = """
    SISTEMA DE ANÁLISIS DE RIESGO DE APUESTAS (FootballLab Brain V2) - ACTUALIZACIÓN CRÍTICA
    
    DATO RECIENTE: FC Nantes viene de GANAR 3-0 al Marseille (7º). 
    PARTIDO: RC Lens (2º) vs FC Nantes (17º - Descenso)
    CUOTA MERCADO: Lens @ 1.44 (Favorito)
    
    HIPÓTESIS ACTUALIZADA:
    Nantes no solo está en modo supervivencia, está en modo 'Goleador'. Ganarle 3-0 al Marsella indica un Momentum ofensivo masivo.
    
    PREGUNTA TÁCTICA:
    1. ¿Es el 1.44 del Lens ahora una cuota 'suicida' considerando que el Nantes viene de golear a un top 10?
    2. ¿Crees que el Lens, sabiendo que el Nantes acaba de golear al Marsella, saldrá con más miedo o con más rotaciones para evitar lesiones ante un equipo tan agresivo?
    3. Probabilidad de X2 (Empate o Gana Nantes).
    """
    
    try:
        response = requests.post(url, json={"prompt": prompt})
        print(f"Status Code: {response.status_code}")
        print(f"Raw Response: {response.text}")
        result = response.json()
        # Handle both chat (message.content) and generate (response) formats
        if "message" in result:
            print("\n--- VEREDICTO BRAIN V2 ---\n")
            print(result["message"].get("content", "Sin contenido en el mensaje"))
        else:
            print(result.get("response", "No se encontró el campo 'response' ni 'message'."))
    except Exception as e:
        print(f"Error al conectar con el cerebro: {e}")

if __name__ == "__main__":
    analyze_trap()

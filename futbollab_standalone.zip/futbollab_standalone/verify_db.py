import os, json

tr_dir = 'brain/database/tracker'
LIGUE1_ID = 'lg_f06f449614c'
SERIE_A_ID = 'lg_z0lkmnis0ge'

l1 = 0
sa = 0
for f in os.listdir(tr_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(tr_dir, f), 'r', encoding='utf-8') as j:
        m = json.load(j)
    if m.get('leagueId') == LIGUE1_ID: l1 += 1
    elif m.get('leagueId') == SERIE_A_ID: sa += 1

print(f"Ligue 1 partidos: {l1}")
print(f"Serie A partidos: {sa}")

# Now also check all matchRefs in profiles to see if they still reference deleted files
profiles_dir = 'brain/database/profiles'
tracker_files = set(f.replace('.json','') for f in os.listdir(tr_dir) if f.endswith('.json'))

broken_refs = 0
for f in os.listdir(profiles_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(profiles_dir, f), 'r', encoding='utf-8') as j:
        p = json.load(j)
    for ref in p.get('matchRefs', []):
        mid = ref.get('memoryId','')
        if mid and mid not in tracker_files:
            broken_refs += 1

print(f"Referencias rotas en perfiles: {broken_refs}")

/**
 * RADAR AI SERVICE
 * Integración directa con SiliconFlow (OpenAI compatible) para análisis del Radar.
 */

const SILICONFLOW_ENDPOINT = "/api/radar_ai";
const DEFAULT_MODEL = "gpt-oss:120b";

/**
 * Realiza la llamada a la IA con el prompt generado a través del proxy local.
 */
export async function fetchRadarAIAnalysis(prompt) {
  try {
    const response = await fetch(SILICONFLOW_ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: DEFAULT_MODEL,
        messages: [
          { role: "system", content: "Eres un experto analista de fútbol y mercados de apuestas. Responde SIEMPRE en formato JSON puro." },
          { role: "user", content: prompt }
        ],
        temperature: 0.1,
        stream: false
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error?.message || `Error API: ${response.status}`);
    }

    const result = await response.json();
    
    // Soporte para ambos formatos: Ollama (result.message) y OpenAI (result.choices)
    const content = result.message?.content || result.choices?.[0]?.message?.content;
    
    if (!content) {
      console.error("[Radar AI Service] Respuesta inesperada:", result);
      throw new Error("La IA no devolvió contenido (formato de respuesta desconocido).");
    }
    
    return content;
  } catch (err) {
    console.error("[Radar AI Service] Error:", err);
    throw err;
  }
}

/**
 * Procesa el resultado de la IA y actualiza el motor de entrenamiento.
 * @param {string} rawJson - Respuesta de la IA
 * @param {Array} currentMatches - Partidos actuales en el radar (radarState.matches)
 * @param {Function} loadTraining - Función para cargar el estado de entrenamiento
 * @param {Function} saveTraining - Función para guardar el estado de entrenamiento
 * @param {Function} parseAIPredictionJSON - Desde radar_training_engine
 * @param {Function} createTrainingRecord - Desde radar_training_engine
 */
export function integrateAIResults({
  rawJson,
  currentMatches,
  loadTraining,
  saveTraining,
  parseAIPredictionJSON,
  createTrainingRecord
}) {
  const parseResult = parseAIPredictionJSON(rawJson);
  if (!parseResult.ok) {
    throw new Error(`Error parseando respuesta IA: ${parseResult.errors.join(", ")}`);
  }

  const trainingState = loadTraining();
  const predictions = parseResult.data.predictions || [];
  let updatedCount = 0;

  for (const pred of predictions) {
    // Buscar el partido en el radar actual por matchId o por equipos
    const match = currentMatches.find(m => 
      m.id === pred.matchId || 
      (m.home === pred.home && m.away === pred.away)
    );

    if (match) {
      const recordResult = createTrainingRecord({
        matchData: match,
        aiPrediction: pred
      });

      if (recordResult.ok) {
        // Eliminar registros previos del mismo partido para evitar duplicados en el mismo radar
        trainingState.records = trainingState.records.filter(r => r.match.id !== match.id);
        trainingState.records.push(recordResult.record);
        updatedCount++;
      }
    }
  }

  saveTraining(trainingState);
  return updatedCount;
}

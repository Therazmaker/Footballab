/**
 * FootballLab: Dynamic Paths Engine (Algoritmo de Caminos Dinámicos)
 * 
 * Este módulo transforma narraciones crudas en vectores de intensidad táctica
 * y genera micro-horizontes de predicción (Ramas A, B, C) cada 10 minutos.
 */

export const TACTICAL_VECTORS = {
  PRESION: "presión",
  CONTRAATAQUE: "contraataque",
  BALON_PARADO: "balón parado",
  POSESION_HORIZONTAL: "posesión horizontal",
  BLOQUE_BAJO: "bloque bajo",
  TRANSICION_RAPIDA: "transición rápida"
};

/**
 * Segmenta un relato en bloques de 10 minutos basados en marcas de tiempo.
 * @param {string} text - El relato completo.
 * @returns {Array} - Lista de bloques con su contenido.
 */
export function segmentNarrative(text = "") {
  const lines = text.split('\n');
  const blocks = Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    range: `${i * 10}-${(i + 1) * 10}`,
    text: "",
    vectors: { presion: 0, contra: 0, parado: 0, horizontal: 0, peligro: 0 }
  }));

  lines.forEach(line => {
    const minMatch = line.match(/(\d+)['\s\]]/);
    if (minMatch) {
      const min = parseInt(minMatch[1], 10);
      const blockIdx = Math.min(Math.floor(min / 10), 9);
      blocks[blockIdx].text += line + "\n";
    }
  });

  return blocks.map(block => analyzeBlockTactics(block));
}

/**
 * Analiza un bloque de texto para extraer vectores de intensidad.
 */
function analyzeBlockTactics(block) {
  const text = block.text.toLowerCase();
  
  // Contadores de keywords (Vectores de Intensidad)
  block.vectors.presion = (text.match(/presión|asfixia|encima|presiona/g) || []).length * 0.25;
  block.vectors.contra = (text.match(/contra|transición|rápida|desmarque/g) || []).length * 0.3;
  block.vectors.parado = (text.match(/córner|falta|lateral|centro|parado/g) || []).length * 0.2;
  block.vectors.horizontal = (text.match(/pase|atrás|toca|horizontal|posesión/g) || []).length * 0.15;
  block.vectors.peligro = (text.match(/peligro|ocasión|cerca|remate|para/g) || []).length * 0.4;

  // Normalización
  Object.keys(block.vectors).forEach(k => {
    block.vectors[k] = Math.min(1, block.vectors[k]);
  });

  return block;
}

/**
 * Detecta qué rama ocurrió realmente basándose en el texto del bloque
 */
export function detectActualBranch(text = "") {
  const low = text.toLowerCase();
  
  // Rama C (Caos): Eventos disruptivos
  if (low.includes("tarjeta roja") || low.includes("expulsado") || low.includes("lesión") || low.includes("error garrafal") || low.includes("penalti") || low.includes("var")) {
    return 2; // Índice de Rama C
  }
  
  // Rama B (Ruptura): Goles y ocasiones claras
  if (low.includes("gol") || low.includes("asistencia") || low.includes("remate al palo") || low.includes("ocasión clarísima") || low.includes("mano a mano") || low.includes("asfixia")) {
    return 1; // Índice de Rama B
  }
  
  // Rama A: Inercia (por defecto)
  return 0;
}

/**
 * Genera los 3 escenarios (Ramas) para el siguiente bloque basándose en el actual.
 */
export function generateBranches(currentBlock) {
  const v = currentBlock.vectors;
  
  // Rama A: Inercia (Inercia táctica)
  const probA = Math.max(0.4, 0.7 - (v.peligro * 0.3));
  const descA = v.horizontal > 0.5 
    ? "El ritmo se mantiene lento. Posesión estéril sin profundidad."
    : "Ritmo constante. Control de medio campo sin llegadas claras.";

  // Rama B: Ruptura (Gol o Ocasión)
  const probB = Math.min(0.4, 0.2 + (v.presion * 0.2) + (v.contra * 0.2));
  const descB = v.contra > v.presion 
    ? "Ruptura por banda. El equipo local explota los espacios en transición."
    : "Asfixia en salida. El robo en campo rival genera ocasión inmediata.";

  // Rama C: Disrupción (Caos / Evento Disruptivo)
  const probC = 1 - probA - probB;
  const descC = v.presion > 0.6 
    ? "Alta fricción detectada. Posible tarjeta o interrupción por faltas tácticas."
    : "Evento disruptivo por fatiga o error individual no forzado.";

  return [
    { type: "Rama A (Inercia)", prob: Math.round(probA * 100), desc: descA, impact: "Bajo" },
    { type: "Rama B (Ruptura)", prob: Math.round(probB * 100), desc: descB, impact: "Alto" },
    { type: "Rama C (Caos)", prob: Math.round(probC * 100), desc: descC, impact: "Medio" }
  ];
}

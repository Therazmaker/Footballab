# FutbolLab Research Program (v1.0)

Este documento define el protocolo de operación para agentes de investigación sobre el dataset de FutbolLab.

## 1. Setup de Sesión
1. Generar ID de sesión: `[mes][día]-[entorno]` (ej: "may07-local").
2. Cargar contexto obligatorio de solo lectura:
   - `match_intelligence_engine.js`: Tesis (MATCH_THESIS) y pesos (computeSignalWeights).
   - `result_quality_index.js`: Clasificación RQI y subscores.
   - `mne_claude_exchange.js`: Schema mne_claude_export_v1.
   - `prematch_story_engine_v2.js`: Ángulos editoriales.
   - `current_strength_index.js`: Dimensiones CSI (pressure, control, stability, momentum, cohesion).
3. Validar datos: Mínimo 5 partidos en `brainV2.memories`. Si n < 5, abortar con advertencia.
4. Inicializar `research_log.tsv` con header:
   `session | date | team | hypothesis | result | verdict | weight_adjustment | notes`
5. Solicitar aprobación humana para iniciar el loop.

## 2. Capacidades y Límites
- EL AGENTE PUEDE: Leer `brainV2.memories`, escribir en `brainV2.ollamaPatterns`, agregar filas a `research_log.tsv`, proponer deltas para `computeSignalWeights()`.
- EL AGENTE NO PUEDE: Modificar archivos `.js` de motores, inventar datos estadísticos, validar patrones con confidence < 0.65 o n < 8, proponer cambios sin comparar contra una hipótesis alternativa.

## 3. Métrica Única: Prediction Accuracy
`prediction_accuracy = (partidos con tesis correcta) / (total de partidos evaluados)`
- Tesis Correcta: 
  - `strong_favorite_real` -> Gana favorito.
  - `underdog_live` -> No-favorito gana o empata.
  - `draw_trap` -> Empate.
  - Otros -> El resultado no contradice la descripción de la tesis.
- Acción: Calcular baseline al inicio; recalcular impacto estimado tras cada propuesta.

## 4. Loop de Experimentación (Autónomo)
1. Leer últimas 5 filas de `research_log.tsv`.
2. Formular hipótesis falseable (ej: "Si CSI stability < 30 y local es favorito, aumenta frecuencia de underdog_live").
3. Buscar evidencia en `brainV2.memories`.
4. Formular hipótesis alternativa para los mismos datos.
5. Seleccionar ganadora basada en n y p-value simulado.
6. Registrar en `research_log.tsv`:
   - `verdict`: "keep" (n>=8, conf>=0.65), "discard", o "inconclusive".
   - `weight_adjustment`: Campo + Delta (ej: "momentumWeight +0.10") o "none".
7. Si verdict es "keep", reportar estructura al humano y esperar aprobación de implementación.

## 5. Reglas de Autonomía
- No preguntar para continuar el loop; el humano interrumpe.
- Ante falta de ideas, combinar señales (CSI + RQI + Phase).
- Si un equipo falla por falta de datos, pivotar a liga o equipo con más volumen.
- Nunca modificar registros pasados en el TSV; corregir mediante nuevas filas.

## 6. Formato de Registro (research_log.tsv)
Separador: TAB. Header inamovible:
`session  date  team  hypothesis  result  verdict  weight_adjustment  notes`

Ejemplos:
may07-local	2026-05-07	Metz	CSI pressure >70 correlaciona con victoria	Confirmado 10/12	keep	pressureWeight +0.05	n=12
may07-local	2026-05-07	all	RQI bajo en ambos predice draw_trap	Datos insuficientes	inconclusive	none	n=3

## 7. Cómo iterar sobre este programa
- El humano agrega nuevas "Hipótesis abiertas" al final de este archivo.
- El humano cambia el foco (equipo/liga) editando la sección Setup.
- Este archivo es la única vía para guiar la investigación sin tocar el código.

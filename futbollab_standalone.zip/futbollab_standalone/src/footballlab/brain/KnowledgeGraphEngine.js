/**
 * KnowledgeGraphEngine
 * Convierte la base de datos relacional de FootballLab en un modelo de Grafo.
 * Nodos: Equipos, Estilos, Conceptos.
 * Enlaces: Historial de enfrentamientos (peso), similitud táctica.
 */

export function generateKnowledgeGraph(db) {
  const nodes = [];
  const links = [];
  const nodeMap = new Set();
  
  const addNode = (id, name, group, val, color) => {
    if(!nodeMap.has(id)) {
      nodes.push({ id, name, group, val, color });
      nodeMap.add(id);
    }
  };

  const linkMap = new Map();
  const addLink = (source, target, weight, type, color) => {
    if(!source || !target) return;
    const key = [source, target].sort().join("|");
    if(linkMap.has(key)) {
      linkMap.get(key).weight += weight;
    } else {
      linkMap.set(key, { source, target, weight, type, color });
    }
  };

  // 1. Añadir Nodos de Equipo y Ligas
  (db.teams || []).forEach(team => {
    const tid = String(team.id);
    
    // El tamaño (val) dependerá de cuántos partidos tenga calibrados
    const dna = db.settings?.tacticalDnaRegistry?.[tid] || { inertia: 0.5, rupture: 0.5, chaos: 0.5, totalTrained: 0 };
    const trained = dna.totalTrained || 0;
    
    addNode(tid, team.name, "team", 8 + (trained * 1.5), "#1f6feb");

    // Conectar a la liga
    if(team.leagueId) {
      const lid = `league_${team.leagueId}`;
      const leagueName = db.leagues?.find(l=>l.id===team.leagueId)?.name || "Liga";
      addNode(lid, leagueName, "league", 20, "#8957e5");
      addLink(tid, lid, 1, "belongs_to", "rgba(137, 87, 229, 0.15)");
    }
    
    // Conectar a conceptos de ADN si tiene picos altos (ADN dominante)
    if(dna.chaos > 0.65) {
      addNode("concept_chaos", "Alta Volatilidad", "concept", 15, "#ff7b72");
      addLink(tid, "concept_chaos", 2, "has_trait", "rgba(255, 123, 114, 0.4)");
    }
    if(dna.rupture > 0.65) {
      addNode("concept_rupture", "Fuerte Ruptura", "concept", 15, "#d29922");
      addLink(tid, "concept_rupture", 2, "has_trait", "rgba(210, 153, 34, 0.4)");
    }
    if(dna.inertia > 0.65) {
      addNode("concept_inertia", "Inercia Controladora", "concept", 15, "#3fb950");
      addLink(tid, "concept_inertia", 2, "has_trait", "rgba(63, 185, 80, 0.4)");
    }
  });

  // 2. Analizar Historial de Enfrentamientos
  (db.tracker || []).forEach(match => {
    const hid = String(match.homeId);
    const aid = String(match.awayId);
    
    // Si no existen los equipos en la DB, agregamos nodos genéricos
    if(!nodeMap.has(hid)) addNode(hid, match.homeId, "team_unknown", 5, "#8b949e");
    if(!nodeMap.has(aid)) addNode(aid, match.awayId, "team_unknown", 5, "#8b949e");

    addLink(hid, aid, 1, "played_against", "rgba(255, 255, 255, 0.08)");
  });

  // 3. Procesar Enlaces
  linkMap.forEach(link => {
    links.push({
      source: link.source,
      target: link.target,
      value: link.weight,
      color: link.color,
      name: link.type
    });
  });

  return { nodes, links };
}

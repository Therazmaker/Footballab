/**
 * TacticalValidator.js
 * Módulo de validación predictiva y backtesting para FootballLab BRAINV2.
 */

/**
 * @param {object}  db
 * @param {*}       teamId
 * @param {object}  utils   - { getOrCreateDiagProfile, buildMatchPlan, simulateMatchV2, parseNumber }
 * @param {object}  [overrideDna]  - si se pasa, se inyecta en el perfil del equipo directamente
 */
export function runTeamBacktest(db, teamId, utils, overrideDna = null){
  const { getOrCreateDiagProfile, buildMatchPlan, simulateMatchV2, parseNumber } = utils;

  const team = db.teams.find(t => String(t.id) === String(teamId));
  if(!team) return { error: "Equipo no encontrado" };

  const matches = db.tracker.filter(m => {
    const isRelated = String(m.homeId) === String(teamId) || String(m.awayId) === String(teamId);
    if(!isRelated) return false;
    const hasScore = (m.scoreFT || m.score || m.homeGoals !== undefined || (m.goals && m.goals.home !== undefined));
    return hasScore;
  });
  if(matches.length === 0) return { error: "No hay partidos finalizados en el historial para este equipo" };

  let hits = 0;
  let totalScoreDiff = 0;
  const details = [];

  matches.forEach(m => {
    const isHome = String(m.homeId) === String(teamId);
    const opponentId = isHome ? m.awayId : m.homeId;
    const opponent = db.teams.find(t => String(t.id) === String(opponentId));

    const homeProfile = getOrCreateDiagProfile(db, m.homeId, isHome ? team.name : (opponent?.name || "Rival"));
    const awayProfile = getOrCreateDiagProfile(db, m.awayId, !isHome ? team.name : (opponent?.name || "Rival"));

    // Inyectar ADN candidato directamente sin pasar por localStorage
    if(overrideDna){
      if(isHome) homeProfile.tacticalDNA = { ...overrideDna };
      else        awayProfile.tacticalDNA = { ...overrideDna };
    }

    const plan = buildMatchPlan(homeProfile, awayProfile);

    // Monte Carlo ligero: 3 corridas
    let simHome = 0, simAway = 0;
    for(let i = 0; i < 3; i++){
      const sim = simulateMatchV2(plan, i * 777);
      simHome += sim.score.home;
      simAway += sim.score.away;
    }
    const pHome = Math.round(simHome / 3);
    const pAway = Math.round(simAway / 3);

    const realHome = parseNumber(m.scoreFT?.home ?? m.score?.home ?? m.homeGoals ?? m.goals?.home);
    const realAway = parseNumber(m.scoreFT?.away ?? m.score?.away ?? m.awayGoals ?? m.goals?.away);

    const predResult = pHome > pAway ? "H" : (pHome < pAway ? "A" : "D");
    const realResult = realHome > realAway ? "H" : (realHome < realAway ? "A" : "D");

    const isHit = predResult === realResult;
    if(isHit) hits++;

    totalScoreDiff += Math.abs(pHome - realHome) + Math.abs(pAway - realAway);

    const homeName = isHome ? team.name : (db.teams.find(t => String(t.id) === String(m.homeId))?.name || m.homeId);
    const awayName = !isHome ? team.name : (db.teams.find(t => String(t.id) === String(m.awayId))?.name || m.awayId);

    details.push({
      match: `${homeName} vs ${awayName}`,
      pred:  `${pHome}-${pAway}`,
      real:  `${realHome}-${realAway}`,
      hit:   isHit
    });
  });

  return {
    accuracy:     (hits / matches.length) * 100,
    avgError:     totalScoreDiff / (matches.length * 2),
    totalMatches: matches.length,
    details
  };
}

/**
 * Hill-Climbing optimizer: prueba nudges en las 3 dimensiones del ADN
 * y conserva el candidato que maximice el winrate en backtesting.
 */
export async function optimizeTeamDNA(db, teamId, utils, { onProgress } = {}){
  const { saveDb } = utils;
  const yieldToUI = () => new Promise(r => setTimeout(r, 0));

  const tid = String(teamId);
  db.settings.tacticalDnaRegistry ||= {};
  const current = { ...(db.settings.tacticalDnaRegistry[tid] || { inertia: 0.5, rupture: 0.5, chaos: 0.5 }) };

  // ── Fase 1: cuadrícula amplia — 4×4×4 = 64 combinaciones ─────────────────
  const coarseGrid = [0.0, 0.33, 0.67, 1.0];
  let bestDna      = { ...current };
  let bestAccuracy = -1;
  let tested = 0;
  const total = coarseGrid.length ** 3;

  for(const inertia of coarseGrid){
    for(const rupture of coarseGrid){
      for(const chaos of coarseGrid){
        tested++;
        await yieldToUI(); // Ceder al navegador cada iteración
        if(onProgress) onProgress(`Fase 1/2 — ${tested}/${total} (mejor: ${bestAccuracy < 0 ? "—" : bestAccuracy.toFixed(1) + "%"})`);
        const cand = { inertia, rupture, chaos };
        const res  = runTeamBacktest(db, teamId, utils, cand);
        if(!res.error && res.accuracy > bestAccuracy){
          bestAccuracy = res.accuracy;
          bestDna      = { ...cand };
        }
      }
    }
  }

  // ── Fase 2: refinamiento fino — 3×3×3 = 27 combinaciones ─────────────────
  const fineRange = [-0.15, 0, 0.15];
  let refined = 0;
  const fineTotal = fineRange.length ** 3;

  for(const di of fineRange){
    for(const dr of fineRange){
      for(const dc of fineRange){
        refined++;
        await yieldToUI();
        if(onProgress) onProgress(`Fase 2/2 — ${refined}/${fineTotal} (mejor: ${bestAccuracy.toFixed(1)}%)`);
        const cand = {
          inertia: Math.min(1, Math.max(0, bestDna.inertia + di)),
          rupture: Math.min(1, Math.max(0, bestDna.rupture + dr)),
          chaos:   Math.min(1, Math.max(0, bestDna.chaos   + dc))
        };
        const res = runTeamBacktest(db, teamId, utils, cand);
        if(!res.error && res.accuracy > bestAccuracy){
          bestAccuracy = res.accuracy;
          bestDna      = { ...cand };
        }
      }
    }
  }

  // Persistir el ganador
  db.settings.tacticalDnaRegistry[tid] = {
    ...bestDna,
    totalTrained: db.settings.tacticalDnaRegistry[tid]?.totalTrained || 0,
    optimizedAt:  new Date().toISOString(),
    optimizedAccuracy: bestAccuracy
  };
  if(saveDb) saveDb(db);

  return { oldDna: current, newDna: bestDna, accuracy: bestAccuracy };
}

// ─── UI renderers ─────────────────────────────────────────────────────────────

export function renderBacktestPanel(container, results){
  if(!container) return;
  if(results.error){
    container.innerHTML = `<div style="color:#f85149;font-size:12px;margin-top:10px;padding:10px;background:rgba(248,81,73,0.1);border-radius:4px;">❌ ${results.error}</div>`;
    return;
  }
  const color = results.accuracy > 65 ? "#3fb950" : results.accuracy > 45 ? "#d29922" : "#f85149";
  container.innerHTML = `
    <div style="border-left:4px solid ${color};background:rgba(255,255,255,0.03);padding:12px;border-radius:4px;margin-top:10px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <span style="font-weight:bold;color:${color};font-size:14px;">Validación Predictiva AI</span>
        <span style="background:${color};color:#000;padding:2px 8px;border-radius:10px;font-size:12px;font-weight:bold;">Winrate: ${results.accuracy.toFixed(1)}%</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;">
        <div>Partidos testeados: <b>${results.totalMatches}</b></div>
        <div>Error medio goles: <b>${results.avgError.toFixed(2)}</b></div>
      </div>
      <div style="margin-top:10px;max-height:100px;overflow-y:auto;font-size:11px;color:#aaa;border-top:1px solid rgba(255,255,255,0.1);padding-top:5px;">
        ${results.details.map(d => `
          <div style="display:flex;justify-content:space-between;padding:2px 0;">
            <span>${d.match}</span>
            <span style="color:${d.hit ? '#3fb950' : '#f85149'}">${d.pred} vs ${d.real} ${d.hit ? '✓' : '✗'}</span>
          </div>`).join("")}
      </div>
    </div>`;
}

export function renderOptimizeResult(container, res){
  if(!container) return;
  const color = res.accuracy > 65 ? "#3fb950" : res.accuracy > 45 ? "#d29922" : "#f85149";
  const dna = res.newDna;
  container.innerHTML = `
    <div style="border-left:4px solid ${color};background:rgba(255,255,255,0.03);padding:12px;border-radius:4px;margin-top:8px;font-size:12px;">
      <div style="font-weight:bold;color:${color};margin-bottom:6px;">🧬 ADN Optimizado — Winrate: ${res.accuracy.toFixed(1)}%</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;text-align:center;">
        <div style="background:rgba(255,255,255,0.05);border-radius:4px;padding:6px;">
          <div style="color:#8b949e;font-size:10px;">INERCIA</div>
          <div style="font-weight:bold;color:#58a6ff;">${(dna.inertia*100).toFixed(0)}%</div>
        </div>
        <div style="background:rgba(255,255,255,0.05);border-radius:4px;padding:6px;">
          <div style="color:#8b949e;font-size:10px;">RUPTURA</div>
          <div style="font-weight:bold;color:#ff7b72;">${(dna.rupture*100).toFixed(0)}%</div>
        </div>
        <div style="background:rgba(255,255,255,0.05);border-radius:4px;padding:6px;">
          <div style="color:#8b949e;font-size:10px;">CAOS</div>
          <div style="font-weight:bold;color:#f2cc60;">${(dna.chaos*100).toFixed(0)}%</div>
        </div>
      </div>
    </div>`;
}

// ─── CALIBRACIÓN SECUENCIAL (sistema independiente) ───────────────────────────

/**
 * Genera una predicción para un partido concreto usando los ADNs actuales.
 */
export function predictMatch(db, homeId, awayId, utils){
  const { getOrCreateDiagProfile, buildMatchPlan, simulateMatchV2 } = utils;
  const home = db.teams.find(t => String(t.id) === String(homeId));
  const away = db.teams.find(t => String(t.id) === String(awayId));
  if(!home || !away) return { error: "Equipos no encontrados" };

  const homeProfile = getOrCreateDiagProfile(db, homeId, home.name);
  const awayProfile = getOrCreateDiagProfile(db, awayId, away.name);
  const plan = buildMatchPlan(homeProfile, awayProfile);

  // Monte Carlo × 10
  const N = 10;
  const outcomes  = { H: 0, D: 0, A: 0 };
  const scoresByOutcome = { H: [], D: [], A: [] };

  for(let i = 0; i < N; i++){
    const sim = simulateMatchV2(plan, i * 1337);
    const sh  = sim.score.home;
    const sa  = sim.score.away;
    const r   = sh > sa ? "H" : sh < sa ? "A" : "D";
    outcomes[r]++;
    scoresByOutcome[r].push({ h: sh, a: sa });
  }

  // Resultado más frecuente → predicción principal
  const predResult = Object.entries(outcomes).reduce((best, [k,v]) => v > best[1] ? [k,v] : best, ["D",-1])[0];
  const confidence  = Math.round((outcomes[predResult] / N) * 100);

  // Score representativo: mediana del grupo ganador, o global si el grupo está vacío
  const group = scoresByOutcome[predResult];
  const midIdx = Math.floor(group.length / 2);
  const sorted = [...group].sort((a,b) => (b.h - b.a) - (a.h - a.a));
  const predHome = group.length ? sorted[midIdx].h : 1;
  const predAway = group.length ? sorted[midIdx].a : 1;

  const dnaH = homeProfile.tacticalDNA || { inertia: 0.5, rupture: 0.5, chaos: 0.5 };
  const dnaA = awayProfile.tacticalDNA || { inertia: 0.5, rupture: 0.5, chaos: 0.5 };
  const dominantFactor = dnaH.inertia > 0.65 ? `Inercia alta (${home.name})`
    : dnaA.rupture > 0.65 ? `Ruptura peligrosa (${away.name})`
    : Math.max(dnaH.chaos, dnaA.chaos) > 0.65 ? "Partido imprevisible"
    : "Equilibrado";

  return {
    homeName: home.name, awayName: away.name,
    predHome, predAway, predResult,
    confidence, dominantFactor,
    outcomes  // desglose: { H: n, D: n, A: n }
  };
}

/**
 * Calibra el ADN de ambos equipos a partir del resultado real vs predicción.
 * Sistema completamente independiente del backtest masivo.
 */
export function calibrateFromResult(db, homeId, awayId, actualHome, actualAway, narrative, utils){
  const { saveDb } = utils;
  const STEP = 0.06; // Ajuste máx por calibración

  const prediction = predictMatch(db, homeId, awayId, utils);
  if(prediction.error) return { error: prediction.error };

  const realResult  = actualHome > actualAway ? "H" : actualHome < actualAway ? "A" : "D";
  const isHit       = prediction.predResult === realResult;
  const goalDiff    = Math.abs(actualHome - actualAway);
  const expectedDiff= Math.abs(prediction.predHome - prediction.predAway);
  const surprise    = goalDiff > expectedDiff + 1; // Resultado más extremo de lo esperado

  db.settings.tacticalDnaRegistry ||= {};
  db.settings.calibrationLog      ||= [];

  const clamp  = (v, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, v));
  const nudge  = (dna, field, dir) => ({ ...dna, [field]: clamp(dna[field] + dir * STEP) });

  const hid = String(homeId), aid = String(awayId);
  let dnaH = { ...(db.settings.tacticalDnaRegistry[hid] || { inertia: 0.5, rupture: 0.5, chaos: 0.5 }) };
  let dnaA = { ...(db.settings.tacticalDnaRegistry[aid] || { inertia: 0.5, rupture: 0.5, chaos: 0.5 }) };

  const adjustments = [];

  if(isHit && !surprise){
    // Acierto limpio → pequeño refuerzo del factor dominante
    dnaH = nudge(dnaH, "inertia", +0.5);
    adjustments.push("✅ Acierto — Inercia local reforzada levemente");
  } else if(!isHit){
    if(realResult === "D"){
      // Empate inesperado → más caos en ambos
      dnaH = nudge(dnaH, "chaos", +1);
      dnaA = nudge(dnaA, "chaos", +1);
      adjustments.push("⚠️ Empate inesperado — Caos ↑ en ambos equipos");
    } else {
      // Ganó el que no se esperaba → ruptura del ganador sube, inercia del perdedor baja
      const winnerId = realResult === "H" ? hid : aid;
      const loserId  = realResult === "H" ? aid : hid;
      if(winnerId === hid){
        dnaH = nudge(dnaH, "rupture", +1);
        dnaA = nudge(dnaA, "inertia", -1);
        adjustments.push(`⚡ Sorpresa local — Ruptura ↑ ${prediction.homeName}, Inercia ↓ ${prediction.awayName}`);
      } else {
        dnaA = nudge(dnaA, "rupture", +1);
        dnaH = nudge(dnaH, "inertia", -1);
        adjustments.push(`⚡ Sorpresa visitante — Ruptura ↑ ${prediction.awayName}, Inercia ↓ ${prediction.homeName}`);
      }
    }
    if(surprise){
      // Goleada inesperada → caos extra
      dnaH = nudge(dnaH, "chaos", +0.5);
      dnaA = nudge(dnaA, "chaos", +0.5);
      adjustments.push("🌪️ Goleada inesperada — Caos ↑ extra");
    }
  }

  db.settings.tacticalDnaRegistry[hid] = { ...dnaH, lastCalibrated: new Date().toISOString(), totalTrained: (dnaH.totalTrained || 0) + 1 };
  db.settings.tacticalDnaRegistry[aid] = { ...dnaA, lastCalibrated: new Date().toISOString(), totalTrained: (dnaA.totalTrained || 0) + 1 };

  const logEntry = {
    id:        Date.now(),
    date:      new Date().toISOString(),
    homeName:  prediction.homeName,
    awayName:  prediction.awayName,
    homeId: hid, awayId: aid,
    prediction: `${prediction.predHome}-${prediction.predAway}`,
    actual:     `${actualHome}-${actualAway}`,
    isHit,
    adjustments,
    narrative: narrative || ""
  };
  db.settings.calibrationLog.unshift(logEntry); // más reciente primero
  if(db.settings.calibrationLog.length > 100) db.settings.calibrationLog.pop(); // límite de 100

  if(saveDb) saveDb(db);
  return { isHit, adjustments, logEntry, dnaH, dnaA };
}

/**
 * Abre el modal de calibración para un partido específico.
 * Completamente autocontenido, no interfiere con el resto del sistema.
 */
export function openCalibrationModal(db, match, utils){
  // Limpiar modal anterior si existe
  document.getElementById("calibModal")?.remove();

  const home = db.teams.find(t => String(t.id) === String(match.homeId));
  const away = db.teams.find(t => String(t.id) === String(match.awayId));
  const homeName = home?.name || match.homeId;
  const awayName = away?.name || match.awayId;

  const log = (db.settings.calibrationLog || []).slice(0, 5);

  const logHTML = log.length ? log.map(e => `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:11px;">
      <span style="color:#8b949e;">${e.homeName} vs ${e.awayName}</span>
      <span>
        <span style="color:#8b949e;">Pred: ${e.prediction}</span>
        <span style="margin:0 4px;">→</span>
        <span style="color:${e.isHit ? '#3fb950' : '#f85149'};">${e.actual} ${e.isHit ? '✓' : '✗'}</span>
      </span>
    </div>`).join("") : `<div style="color:#8b949e;font-size:11px;text-align:center;padding:8px;">Sin calibraciones aún</div>`;

  const overlay = document.createElement("div");
  overlay.id = "calibModal";
  overlay.style.cssText = `
    position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:9999;
    display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);`;

  overlay.innerHTML = `
    <div style="background:#0d1117;border:1px solid rgba(255,255,255,0.12);border-radius:12px;
                width:480px;max-width:95vw;max-height:90vh;overflow-y:auto;padding:24px;
                box-shadow:0 20px 60px rgba(0,0,0,0.6);">

      <!-- Header -->
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <div>
          <div style="font-weight:700;font-size:15px;color:#e6edf3;">🎯 Calibración Secuencial</div>
          <div style="font-size:11px;color:#8b949e;margin-top:2px;">${homeName} vs ${awayName}</div>
        </div>
        <button id="calibClose" style="background:none;border:none;color:#8b949e;font-size:20px;cursor:pointer;line-height:1;">✕</button>
      </div>

      <!-- Paso 1: Predicción -->
      <div id="calibStep1">
        <div style="font-size:11px;color:#58a6ff;font-weight:600;letter-spacing:.05em;margin-bottom:10px;">PASO 1 — PREDICCIÓN</div>
        <button id="calibPredBtn" style="width:100%;padding:10px;background:linear-gradient(135deg,#1f6feb,#388bfd);border:none;
          border-radius:8px;color:#fff;font-weight:700;font-size:13px;cursor:pointer;">
          🔮 Generar Predicción
        </button>
        <div id="calibPredResult" style="margin-top:10px;"></div>
      </div>

      <div style="border-top:1px solid rgba(255,255,255,0.08);margin:16px 0;"></div>

      <!-- Paso 2: Resultado real -->
      <div id="calibStep2">
        <div style="font-size:11px;color:#3fb950;font-weight:600;letter-spacing:.05em;margin-bottom:10px;">PASO 2 — RESULTADO REAL</div>
        <div style="display:grid;grid-template-columns:1fr auto 1fr;gap:8px;align-items:center;margin-bottom:10px;">
          <div>
            <div style="font-size:10px;color:#8b949e;margin-bottom:4px;">${homeName}</div>
            <input id="calibRealHome" type="number" min="0" max="20" value="${match.homeGoals ?? ''}"
              style="width:100%;padding:8px;background:#161b22;border:1px solid rgba(255,255,255,0.1);
                     border-radius:6px;color:#e6edf3;font-size:18px;font-weight:700;text-align:center;">
          </div>
          <div style="color:#8b949e;font-size:14px;font-weight:700;padding-top:18px;">–</div>
          <div>
            <div style="font-size:10px;color:#8b949e;margin-bottom:4px;">${awayName}</div>
            <input id="calibRealAway" type="number" min="0" max="20" value="${match.awayGoals ?? ''}"
              style="width:100%;padding:8px;background:#161b22;border:1px solid rgba(255,255,255,0.1);
                     border-radius:6px;color:#e6edf3;font-size:18px;font-weight:700;text-align:center;">
          </div>
        </div>
        <textarea id="calibNarrative" rows="2" placeholder="Notas del partido (opcional)…"
          style="width:100%;padding:8px;background:#161b22;border:1px solid rgba(255,255,255,0.1);
                 border-radius:6px;color:#e6edf3;font-size:12px;resize:vertical;box-sizing:border-box;"></textarea>
        <button id="calibSaveBtn" style="width:100%;margin-top:8px;padding:10px;
          background:linear-gradient(135deg,#238636,#2ea043);border:none;border-radius:8px;
          color:#fff;font-weight:700;font-size:13px;cursor:pointer;">
          ✅ Calibrar este partido
        </button>
      </div>

      <!-- Paso 3: Feedback -->
      <div id="calibStep3" style="display:none;"></div>

      <div style="border-top:1px solid rgba(255,255,255,0.08);margin:16px 0;"></div>

      <!-- Historial -->
      <div>
        <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.05em;margin-bottom:8px;">ÚLTIMAS CALIBRACIONES</div>
        <div id="calibLogArea">${logHTML}</div>
      </div>
    </div>`;

  document.body.appendChild(overlay);

  // ── Eventos ────────────────────────────────────────────────────────────────
  document.getElementById("calibClose").onclick = () => overlay.remove();
  overlay.onclick = (e) => { if(e.target === overlay) overlay.remove(); };

  document.getElementById("calibPredBtn").onclick = () => {
    const btn = document.getElementById("calibPredBtn");
    btn.disabled = true;
    btn.innerHTML = "⏳ Simulando…";
    setTimeout(() => {
      try {
        const pred = predictMatch(db, match.homeId, match.awayId, utils);
        if(pred.error){ btn.disabled = false; btn.innerHTML = "🔮 Generar Predicción"; return; }
        const resultLabel = pred.predResult === "H" ? `Gana ${pred.homeName}` : pred.predResult === "A" ? `Gana ${pred.awayName}` : "Empate";
        const confColor   = pred.confidence > 60 ? "#3fb950" : pred.confidence > 40 ? "#d29922" : "#f85149";
        const pctH = pred.outcomes.H * 10;
        const pctD = pred.outcomes.D * 10;
        const pctA = pred.outcomes.A * 10;

        document.getElementById("calibPredResult").innerHTML = `
          <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:12px;border-left:3px solid ${confColor};">
            <div style="font-size:22px;font-weight:700;text-align:center;letter-spacing:2px;margin-bottom:6px;">
              ${pred.predHome} – ${pred.predAway}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:11px;color:#8b949e;margin-bottom:8px;">
              <span>${resultLabel}</span>
              <span style="color:${confColor};">Confianza: ${pred.confidence}%</span>
            </div>

            <!-- Barra de distribución H/D/A -->
            <div style="display:flex;height:6px;border-radius:3px;overflow:hidden;margin-bottom:4px;background:rgba(255,255,255,0.1);">
              <div style="width:${pctH}%;background:#58a6ff;" title="Local: ${pctH}%"></div>
              <div style="width:${pctD}%;background:#8b949e;" title="Empate: ${pctD}%"></div>
              <div style="width:${pctA}%;background:#ff7b72;" title="Visita: ${pctA}%"></div>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:9px;color:#8b949e;font-weight:600;">
              <span style="color:${pctH>0?'#58a6ff':'inherit'}">1: ${pctH}%</span>
              <span style="color:${pctD>0?'#8b949e':'inherit'}">X: ${pctD}%</span>
              <span style="color:${pctA>0?'#ff7b72':'inherit'}">2: ${pctA}%</span>
            </div>

            <div style="font-size:10px;color:#8b949e;margin-top:8px;border-top:1px solid rgba(255,255,255,0.05);padding-top:6px;">
              Factor: ${pred.dominantFactor}
            </div>
          </div>`;
        btn.disabled = false;
        btn.innerHTML = "🔄 Recalcular";
      } catch(err) {
        document.getElementById("calibPredResult").innerHTML = `<div style="color:#f85149;font-size:11px;">Error: ${err.message}</div>`;
        btn.disabled = false; btn.innerHTML = "🔮 Generar Predicción";
      }
    }, 50);
  };

  document.getElementById("calibSaveBtn").onclick = () => {
    const aH = parseInt(document.getElementById("calibRealHome").value, 10);
    const aA = parseInt(document.getElementById("calibRealAway").value, 10);
    const narrative = document.getElementById("calibNarrative").value.trim();
    if(isNaN(aH) || isNaN(aA)){ alert("Introduce el resultado real antes de calibrar."); return; }

    const result = calibrateFromResult(db, match.homeId, match.awayId, aH, aA, narrative, utils);
    if(result.error){ alert("Error: " + result.error); return; }

    const hitColor = result.isHit ? "#3fb950" : "#f85149";
    const hitIcon  = result.isHit ? "✅" : "❌";
    const step3 = document.getElementById("calibStep3");
    step3.style.display = "block";
    step3.innerHTML = `
      <div style="border-top:1px solid rgba(255,255,255,0.08);padding-top:16px;margin-bottom:4px;">
        <div style="font-size:11px;color:#8b949e;font-weight:600;letter-spacing:.05em;margin-bottom:10px;">PASO 3 — RESULTADO</div>
        <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:12px;border-left:3px solid ${hitColor};">
          <div style="font-size:13px;font-weight:700;color:${hitColor};margin-bottom:8px;">
            ${hitIcon} ${result.isHit ? "Predicción acertada" : "Predicción fallida"} — ADN ajustado
          </div>
          ${result.adjustments.map(a => `<div style="font-size:11px;color:#8b949e;margin:3px 0;">→ ${a}</div>`).join("")}
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:4px;margin-top:10px;text-align:center;">
            <div style="background:rgba(88,166,255,0.1);border-radius:4px;padding:4px;">
              <div style="font-size:9px;color:#8b949e;">INERCIA</div>
              <div style="font-size:12px;font-weight:700;color:#58a6ff;">${(result.dnaH.inertia*100).toFixed(0)}%</div>
            </div>
            <div style="background:rgba(255,123,114,0.1);border-radius:4px;padding:4px;">
              <div style="font-size:9px;color:#8b949e;">RUPTURA</div>
              <div style="font-size:12px;font-weight:700;color:#ff7b72;">${(result.dnaH.rupture*100).toFixed(0)}%</div>
            </div>
            <div style="background:rgba(242,204,96,0.1);border-radius:4px;padding:4px;">
              <div style="font-size:9px;color:#8b949e;">CAOS</div>
              <div style="font-size:12px;font-weight:700;color:#f2cc60;">${(result.dnaH.chaos*100).toFixed(0)}%</div>
            </div>
          </div>
        </div>
        <button id="calibNextBtn" style="width:100%;margin-top:10px;padding:8px;background:rgba(255,255,255,0.06);
          border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:#e6edf3;cursor:pointer;font-size:12px;">
          + Calibrar otro partido
        </button>
      </div>`;

    // Actualizar historial
    const newLog = (db.settings.calibrationLog || []).slice(0, 5);
    document.getElementById("calibLogArea").innerHTML = newLog.map(e => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:11px;">
        <span style="color:#8b949e;">${e.homeName} vs ${e.awayName}</span>
        <span>
          <span style="color:#8b949e;">Pred: ${e.prediction}</span>
          <span style="margin:0 4px;">→</span>
          <span style="color:${e.isHit ? '#3fb950' : '#f85149'};">${e.actual} ${e.isHit ? '✓' : '✗'}</span>
        </span>
      </div>`).join("") || `<div style="color:#8b949e;font-size:11px;text-align:center;padding:8px;">Sin calibraciones aún</div>`;

    document.getElementById("calibNextBtn").onclick = () => {
      step3.style.display = "none";
      document.getElementById("calibRealHome").value = "";
      document.getElementById("calibRealAway").value = "";
      document.getElementById("calibNarrative").value = "";
      document.getElementById("calibPredResult").innerHTML = "";
      document.getElementById("calibPredBtn").innerHTML = "🔮 Generar Predicción";
    };
  };
}

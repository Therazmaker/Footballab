/**
 * @file ollama_pattern_adapter.js
 * @description Adaptador para la integración de FutbolLab con Ollama Cloud API.
 * Proporciona funciones puras para análisis de patrones, validación de tesis y extracción de narrativa.
 */

const DEFAULT_API_BASE = "/api/ollama";
const DEFAULT_MODEL = "llama3.2";
const CLOUD_API_KEY = "ac274e983c234c609297af6c0dcb53a9.NKN13k0WtXoUqtVuWcz5bp33";

/** 
 * Construye el payload para la API de Ollama según el modo de análisis.
 */
export function buildOllamaPayload(mode, context) {
  let systemPrompt = "";
  let userPrompt = "";

  switch (mode) {
    case "pattern_finder":
      systemPrompt = `Eres un analista táctico experto en FutbolLab. 
Tu tarea es encontrar patrones recurrentes en las memorias de partidos de un equipo.
Responde ÚNICAMENTE en formato JSON válido según este esquema:
{
  "patterns": [{ "id": "string", "description": "string", "teams": ["string"], "conditions": ["string"], "sampleSize": number, "confidence": number, "suggestedRule": "string" }],
  "summary": "string",
  "limitations": ["string"]
}
No incluyas markdown, bloques de código ni texto explicativo. Solo el JSON.`;
      userPrompt = `Analiza los siguientes partidos del equipo "${context.teamName}": ${JSON.stringify(context.memories)}. Máximo de memorias a considerar: ${context.maxMemories || 10}.`;
      break;

    case "thesis_validator":
      systemPrompt = `Eres un validador de tesis estadísticas de fútbol.
Tu tarea es contrastar la tesis actual con los datos reales del partido y las señales detectadas.
Responde ÚNICAMENTE en formato JSON válido según este esquema:
{
  "verdict": "confirms" | "contradicts" | "nuances",
  "confidence": 0.0 a 1.0,
  "reasoning": "string",
  "newSignals": ["string"],
  "suggestedThesisAdjustment": "string" | null
}
No incluyas texto extra. Solo el JSON.`;
      userPrompt = `Tesis: ${JSON.stringify(context.thesis)}. 
Alertas detectadas (Traps): ${JSON.stringify(context.trapWarnings)}. 
Datos del partido: ${JSON.stringify(context.matchData)}.
Insights previos: ${JSON.stringify(context.prematchInsights)}.`;
      break;

    case "narrative_extractor":
      systemPrompt = `Eres un extractor de narrativa de partidos de fútbol.
Tu tarea es convertir texto crudo o bitácoras en datos estructurados de eventos y sensaciones.
Responde ÚNICAMENTE en formato JSON válido según este esquema:
{
  "tags": ["string"],
  "keyEvents": [{ "minute": number | null, "type": "string", "team": "string", "weight": 1-10 }],
  "dominanceSignal": "home" | "away" | "balanced" | "unknown",
  "chaosLevel": 0.0 a 1.0,
  "extractedNarrative": "resumen en 2-3 oraciones"
}
No incluyas texto extra. Solo el JSON.`;
      userPrompt = `Texto del partido: ${context.rawText}. ID Partido: ${context.matchId}. Equipos: ${JSON.stringify(context.teams)}.`;
      break;

    default:
      throw new Error(`Modo de Ollama no soportado: ${mode}`);
  }

  return {
    model: DEFAULT_MODEL,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ],
    stream: false,
    options: {
      temperature: 0.2
    }
  };
}

/** 
 * Parsea y limpia la respuesta cruda de la API.
 */
export function parseOllamaResponse(rawResponse) {
  try {
    let content = rawResponse.message?.content || "";
    // Limpieza de posibles bloques de código markdown
    content = content.replace(/```json/g, "").replace(/```/g, "").trim();
    
    const parsed = JSON.parse(content);
    return { ok: true, data: parsed };
  } catch (err) {
    return { 
      ok: false, 
      error: "Error al parsear JSON de Ollama", 
      raw: typeof rawResponse === 'string' ? rawResponse : JSON.stringify(rawResponse) 
    };
  }
}

/** 
 * Integra los resultados de Ollama en una fila de memoria de BrainV2.
 */
export function mapToMemory(mode, parsedData, existingMemoryRow = {}) {
  if (!parsedData) return {};

  switch (mode) {
    case "pattern_finder":
      return {
        ollamaPatterns: parsedData.patterns || [],
        ollamaSummary: parsedData.summary || ""
      };
    case "thesis_validator":
      return {
        ollamaVerdict: parsedData.verdict,
        ollamaSignals: parsedData.newSignals || [],
        ollamaConfidence: parsedData.confidence
      };
    case "narrative_extractor":
      const existingSummary = existingMemoryRow.summary || {};
      return {
        tags: [...new Set([...(existingMemoryRow.tags || []), ...(parsedData.tags || [])])],
        summary: {
          ...existingSummary,
          ollamaTags: parsedData.tags,
          ollamaNarrative: parsedData.extractedNarrative
        }
      };
    default:
      return {};
  }
}

/** 
 * Realiza la llamada HTTP a Ollama Cloud con protección de timeout.
 */
export async function callOllamaCloud(payload, apiBase = DEFAULT_API_BASE, apiKey = CLOUD_API_KEY) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000); // 30s timeout

  try {
    const response = await fetch(`${apiBase}/api/chat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": apiKey ? `Bearer ${apiKey}` : "" // Soporte para autenticación si el proxy lo requiere
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      const errText = await response.text();
      return { ok: false, error: `Error API Ollama (${response.status}): ${errText}` };
    }

    const data = await response.json();
    return { ok: true, data };
  } catch (err) {
    clearTimeout(timeoutId);
    return { ok: false, error: err.name === 'AbortError' ? "Timeout de 30s excedido" : err.message };
  }
}

/** 
 * Función de alto nivel para descubrir patrones en las memorias de un equipo.
 */
export async function discoverPatterns(brainV2Memories, teamName, apiBase = DEFAULT_API_BASE, model = DEFAULT_MODEL) {
  if (!Array.isArray(brainV2Memories)) return { ok: false, error: "Memorias inválidas" };

  // 1. Filtrar últimas 15 memorias del equipo (normalización de nombre)
  const normalize = (s) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const target = normalize(teamName);
  
  const filtered = brainV2Memories
    .filter(m => normalize(m.teamName || "").includes(target) || normalize(m.opponent || "").includes(target))
    .slice(-15);

  if (filtered.length === 0) return { ok: false, error: "No hay memorias suficientes para este equipo" };

  // 2. Construir payload
  const payload = buildOllamaPayload("pattern_finder", {
    teamName,
    memories: filtered,
    maxMemories: 15
  });
  if (model) payload.model = model;

  // 3. Llamar a la nube
  const result = await callOllamaCloud(payload, apiBase);
  if (!result.ok) return result;

  // 4. Parsear respuesta
  const parsed = parseOllamaResponse(result.data);
  if (!parsed.ok) return parsed;

  return {
    ok: true,
    patterns: parsed.data.patterns,
    summary: parsed.data.summary,
    limitations: parsed.data.limitations,
    rawResponse: result.data
  };
}

/* 
=== EJEMPLOS DE USO (MOCKS) ===

1. Llamar discoverPatterns con datos mock:
   const result = await discoverPatterns(myBrainMemories, "Real Madrid");
   if(result.ok) console.log("Patrones:", result.patterns);

2. Llamar buildOllamaPayload para validación de tesis:
   const payload = buildOllamaPayload("thesis_validator", {
     thesis: { type: "control", expected: "high" },
     trapWarnings: ["low_efficiency"],
     matchData: { possession: 65, shots: 12 },
     prematchInsights: "El rival suele encerrarse"
   });

3. Manejar resultado de parseOllamaResponse con JSON mal formado:
   const malformed = { message: { content: "Aquí tienes el JSON: { 'invalid': json... }" } };
   const parsed = parseOllamaResponse(malformed);
   if(!parsed.ok) console.error("Error detectado:", parsed.error, "Crudo:", parsed.raw);
*/

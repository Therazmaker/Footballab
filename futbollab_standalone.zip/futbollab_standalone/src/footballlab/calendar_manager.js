/**
 * src/footballlab/calendar_manager.js
 * Centralized logic for the calendar view and API synchronization.
 */

export function renderCalendarioView(content, db, payload, deps) {
  const { render, saveDb, uid, ensureTrackerMatchState, upsertMirrorFutureMatch, parseSortableDate, syncLeagueMatchesFromApi, normalizeCompetitionType, computeMatchInterest, radarState, openFutureMatchModal } = deps;



  // ── helpers de fecha ──────────────────────────────────────────────
  function todayIsoStr(){
    const n = new Date();
    return `${n.getUTCFullYear()}-${String(n.getUTCMonth()+1).padStart(2,'0')}-${String(n.getUTCDate()).padStart(2,'0')}`;
  }
  function isoAddDays(iso, delta){
    const ts = parseSortableDate(iso);
    if(!Number.isFinite(ts)) return iso;
    const d = new Date(ts + delta*86400000);
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}-${String(d.getUTCDate()).padStart(2,'0')}`;
  }
  function formatDateLabel(iso){
    const ts = parseSortableDate(iso);
    if(!Number.isFinite(ts)) return iso;
    return new Date(ts).toLocaleDateString('es-MX',{ weekday:'long', year:'numeric', month:'long', day:'numeric', timeZone:'UTC' });
  }

  const calDate = (payload.calDate) || todayIsoStr();
  const todayStr = todayIsoStr();
  const todayTs  = parseSortableDate(todayStr);
  const selTs    = parseSortableDate(calDate);
  const isPast   = Number.isFinite(selTs) && selTs <= todayTs;

  // ── recolectar todos los partidos únicos para el día seleccionado ──
  const seenKeys = new Set();
  const calMatches = []; // { homeTeam, awayTeam, fm, originTeam }
  db.teams.forEach(team=>{
    (team.futureMatches||[]).forEach(fm=>{
      if(fm.date !== calDate) return;
      const rivalTeam = db.teams.find(t=>t.id===fm.rivalTeamId) || { id: fm.rivalTeamId, name: fm.rivalTeamId };
      const homeTeam  = fm.isHome ? team : rivalTeam;
      const awayTeam  = fm.isHome ? rivalTeam : team;
      const key = [calDate, homeTeam.id, awayTeam.id].sort().join('::');
      if(seenKeys.has(key)) return;
      seenKeys.add(key);
      calMatches.push({ homeTeam, awayTeam, fm, originTeam: team });
    });
  });

  // ── detectar qué partidos ya tienen resultado en tracker ──────────
  function findTrackerResult(homeId, awayId, date){
    return (db.tracker||[]).find(m=>
      m.date===date && (
        (m.homeId===homeId && m.awayId===awayId) ||
        (m.homeId===awayId && m.awayId===homeId)
      )
    ) || null;
  }

  // ── renderizar tarjetas ────────────────────────────────────────────
  // ── agrupar por liga ──────────────────────────────────────────────
  const groups = {};
  calMatches.forEach((m, i) => {
    const comp = m.fm.competition || "Otras Ligas";
    if (!groups[comp]) groups[comp] = [];
    groups[comp].push({ ...m, originalIdx: i });
  });

  const sortedComps = Object.keys(groups).sort();

  const groupedHtml = sortedComps.map(compName => {
    const matchesInGroup = groups[compName];
    const matchCards = matchesInGroup.map(entry => {
      const { homeTeam, awayTeam, fm, originalIdx: idx } = entry;
      const existingResult = findTrackerResult(homeTeam.id, awayTeam.id, calDate);
      const stage = fm.stage || "";
      
      const resultBadge = existingResult
        ? `<span style="background:#22c55e;color:#0d1117;padding:2px 10px;border-radius:8px;font-weight:800;font-size:1rem;">
             ${existingResult.homeId===homeTeam.id
               ? `${existingResult.homeGoals} – ${existingResult.awayGoals}`
               : `${existingResult.awayGoals} – ${existingResult.homeGoals}`}
           </span>`
        : "";

      const registerBtn = (!existingResult && isPast)
        ? `<button class="fl-btn cal-reg-btn" data-cal-idx="${idx}" style="background:#1f6feb;">⚽ Registrar resultado</button>`
        : "";

      const formSection = `
        <div id="cal-form-${idx}" style="display:none;margin-top:8px;">
          <div class="fl-row" style="align-items:center;gap:8px;flex-wrap:wrap;">
            <span style="font-size:.85rem;color:#8892a4;">${homeTeam.name}</span>
            <input id="cal-hg-${idx}" type="number" min="0" max="30" value="0"
              style="width:52px;text-align:center;background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:4px;">
            <span style="color:#8892a4;">–</span>
            <input id="cal-ag-${idx}" type="number" min="0" max="30" value="0"
              style="width:52px;text-align:center;background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:4px;">
            <span style="font-size:.85rem;color:#8892a4;">${awayTeam.name}</span>
            <button class="fl-btn cal-save-btn" data-cal-idx="${idx}"
              data-home-id="${homeTeam.id}" data-away-id="${awayTeam.id}"
              data-fm-id="${fm.id}" data-origin-team-id="${entry.originTeam.id}"
              data-competition-id="${fm.competitionId||''}"
              style="background:#238636;">Guardar</button>
            <button class="fl-btn cal-cancel-btn" data-cal-idx="${idx}" style="background:#30363d;">Cancelar</button>
            <span id="cal-status-${idx}" style="color:#8892a4;font-size:.8rem;"></span>
          </div>
        </div>
        <div id="cal-ratings-${idx}" class="fl-card" style="display:none;margin-top:10px;background:#161b22;border:1px solid #30363d;">
          <div style="font-weight:800;margin-bottom:10px;color:#58a6ff;">Valoración de Jugadores</div>
          <div id="cal-ratings-list-${idx}" style="max-height:300px;overflow-y:auto;margin-bottom:12px;"></div>
          <div style="display:flex;gap:10px;">
            <button class="fl-btn cal-final-save-btn" data-cal-idx="${idx}"
              data-home-id="${homeTeam.id}" data-away-id="${awayTeam.id}"
              data-fm-id="${fm.id}" data-origin-team-id="${entry.originTeam.id}"
              data-competition-id="${fm.competitionId||''}"
              style="background:#238636;flex-grow:1;">Confirmar y Guardar Todo</button>
            <button class="fl-btn cal-ratings-cancel-btn" data-cal-idx="${idx}" style="background:#30363d;">Atrás</button>
          </div>
        </div>
      `;

      const interest = computeMatchInterest(db, homeTeam, awayTeam, fm);
      const interestBadge = `<span style="background:${interest.level==='high'?'#ff7b72':interest.level==='med'?'#f59e0b':'#30363d'};color:${interest.level==='low'?'#8892a4':'#0d1117'};padding:2px 8px;border-radius:6px;font-size:.75rem;font-weight:800;cursor:help;border:1px solid ${interest.level==='none'?'transparent':interest.level==='high'?'#ff7b7288':'#f59e0b88'};" title="${interest.reasons.join(', ')}">${interest.label}</span>`;
      
      const oddsLabel = interest.odds 
        ? `<span style="font-size:0.75rem; color:#8892a4; margin-left:4px;">[${interest.odds.h} | ${interest.odds.d} | ${interest.odds.a}]</span>`
        : "";

      const radarBtn = `<button class="fl-btn cal-radar-btn" data-cal-idx="${idx}" style="background:linear-gradient(135deg,#58a6ff,#1f6feb);border:none;">📡 Radar</button>`;

      const signalBar = interest.reasons.length > 0 && interest.level !== 'none'
        ? `<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:2px;">
            ${interest.reasons.map(r => `<span style="font-size:0.72rem;background:#0d1117;border:1px solid ${interest.level==='high'?'#ff7b7244':interest.level==='med'?'#f59e0b44':'#30363d'};color:${interest.level==='high'?'#ff9090':interest.level==='med'?'#fbbf24':'#8892a4'};padding:1px 7px;border-radius:20px;">${r}</span>`).join('')}
          </div>`
        : '';

      return `
        <div class="fl-card" style="display:flex;flex-direction:column;gap:6px;border-left:4px solid ${interest.level==='high'?'#ff7b72':interest.level==='med'?'#f59e0b':interest.level==='low'?'#58a6ff':'transparent'}; margin-bottom:12px;">
          <div class="fl-row" style="align-items:center;gap:10px;flex-wrap:wrap;">
            <span style="background:#21262d;border-radius:6px;padding:2px 8px;font-size:.8rem;color:#c9d1d9;font-weight:bold;">${stage ? "Jornada "+stage : "Programado"}</span>
            ${interestBadge}
            <span class="cal-team-link" data-team-id="${homeTeam.id}" style="font-weight:800;font-size:1.1rem;cursor:pointer;color:#58a6ff;">${homeTeam.name}</span>
            <span style="color:#8892a4;font-size:.9rem;">vs</span>
            <span class="cal-team-link" data-team-id="${awayTeam.id}" style="font-weight:800;font-size:1.1rem;cursor:pointer;color:#58a6ff;">${awayTeam.name}</span>
            ${oddsLabel}
            ${resultBadge}
            <div style="flex-grow:1;"></div>
            ${registerBtn}
            ${radarBtn}
            <button class="fl-btn cal-edit-btn" data-cal-idx="${idx}" style="background:#21262d; border:1px solid #30363d; padding: 4px 8px;" title="Editar partido"><span style="font-size: 14px;">✏️</span></button>
            <button class="fl-btn cal-delete-btn" data-cal-idx="${idx}" style="background:#21262d; border:1px solid #30363d; padding: 4px 8px; color: #ff7b72;" title="Borrar partido"><span style="font-size: 14px;">🗑️</span></button>
          </div>
          ${signalBar}
          ${formSection}
        </div>`;

    }).join("");

    return `
      <div class="cal-league-group" style="margin-top:30px; margin-bottom:10px;">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:15px;">
          <h3 style="margin:0; font-size:1.2rem; color:#f0f6fc; text-transform:uppercase; letter-spacing:1px; background:rgba(88,166,255,0.05); padding:6px 15px; border-radius:6px; border-left:4px solid #58a6ff;">${compName}</h3>
          <div style="flex-grow:1; height:1px; background:linear-gradient(90deg, #30363d, transparent);"></div>
        </div>
        ${matchCards}
      </div>
    `;
  }).join("");


  const emptyMsg = calMatches.length===0
    ? `<div class="fl-card fl-muted">No hay partidos programados para este día.</div>`
    : "";

  const calAddFormHTML = `
    <div id="cal-add-form" class="fl-card" style="display:none;margin-top:8px;background:#0d1117;border:1px solid #30363d;">
      <div style="font-weight:800;margin-bottom:12px;color:#f0f2f7;">Añadir Partido Manual para el ${calDate}</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
         <div style="position:relative;">
           <input type="text" id="cal-add-home" list="cal-teams-list" placeholder="Local..." style="background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:8px;width:200px;">
         </div>
         <span style="color:#8892a4;font-weight:bold;">VS</span>
         <div style="position:relative;">
           <input type="text" id="cal-add-away" list="cal-teams-list" placeholder="Visitante..." style="background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:8px;width:200px;">
         </div>
         
         <datalist id="cal-teams-list">
           ${db.teams.map(t=>`<option value="${t.name}">`).join('')}
         </datalist>

         <select id="cal-add-comp" style="background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:8px;">
           <option value="">Competición...</option>
           ${(db.leagues||[]).map(l=>`<option value="${l.id}">${l.name}</option>`).join('')}
         </select>
         <input type="text" id="cal-add-stage" placeholder="Jornada..." style="width:100px;background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:8px;">
         <button class="fl-btn" id="cal-add-save" style="background:#238636;padding:8px 20px;">Guardar</button>
         <button class="fl-btn" id="cal-add-cancel" style="background:#30363d;padding:8px 20px;">Cancelar</button>
         <span id="cal-add-status" style="color:#8892a4;font-size:.8rem;"></span>
      </div>
    </div>

  `;

  content.innerHTML = `
    <div style="padding:20px; max-width:1300px; margin:0 auto;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <div>
          <h2 style="margin:0; font-size:2rem; display:flex; align-items:center; gap:10px;">📅 Calendario <span style="font-size:1rem; color:#8892a4; font-weight:normal;">/ ${formatDateLabel(calDate)}</span></h2>
        </div>
        <div style="display:flex; gap:10px; align-items:center;">
          <button class="fl-btn" id="calPrev" style="background:#21262d;">◀ Anterior</button>
          <input type="date" id="calDatePicker" value="${calDate}"
            style="background:#161b22;border:1px solid #30363d;color:#e6edf3;border-radius:6px;padding:6px 10px;font-size:.95rem;">
          <button class="fl-btn" id="calToday" style="background:#21262d;">Hoy</button>
          <button class="fl-btn" id="calNext" style="background:#21262d;">Siguiente ▶</button>
          <div style="width:15px;"></div>
          <button class="fl-btn" id="calSyncApi" style="background:linear-gradient(135deg,#238636,#2ea043);">🔄 Sincronizar API</button>
          <button class="fl-btn" id="calAddMatchBtn" style="background:#1f6feb;">➕ Añadir partido</button>
        </div>
      </div>
      <div id="syncGlobalStatus" class="fl-mini" style="margin: 0 10px 10px; font-weight: 700; color: #58a6ff;"></div>
      ${calAddFormHTML}

      <div id="calContainer">
        ${calMatches.length === 0 
          ? `<div style="text-align:center; padding:80px; color:#8892a4; background:#161b22; border-radius:12px; border:2px dashed #30363d;">
               No hay partidos registrados para esta fecha.
             </div>` 
          : groupedHtml
        }
      </div>
    </div>
  `;


  // ── navegación de fechas ──────────────────────────────────────────
  document.getElementById("calPrev").onclick = ()=>render("calendario",{ calDate: isoAddDays(calDate,-1) });
  document.getElementById("calNext").onclick = ()=>render("calendario",{ calDate: isoAddDays(calDate,1) });
  document.getElementById("calToday").onclick = ()=>render("calendario",{ calDate: todayStr });
  const picker = document.getElementById("calDatePicker");
  if(picker) picker.onchange = function(){ render("calendario",{ calDate: this.value }); };


  // ── añadir partido ────────────────────────────────────────────────
  const calAddBtn = document.getElementById("calAddMatchBtn");
  if(calAddBtn) calAddBtn.onclick = ()=>{
    const form = document.getElementById("cal-add-form");
    form.style.display = form.style.display==="none" ? "block" : "none";
  };

  const calSyncBtn = document.getElementById("calSyncApi");
  if(calSyncBtn) calSyncBtn.onclick = async () => {
    if(!db.settings.selectedLeagueId) {
      alert("Por favor, selecciona primero una liga en la pestaña LIGAS.");
      return;
    }
    try {
      await syncLeagueMatchesFromApi(db, db.settings.selectedLeagueId);
      render("calendario", { calDate: calDate });
    } catch(e) { console.error(e); }
  };

  const calAddCancel = document.getElementById("cal-add-cancel");
  if(calAddCancel) calAddCancel.onclick = ()=>{
    document.getElementById("cal-add-form").style.display = "none";
  };

  const calAddSave = document.getElementById("cal-add-save");
  if(calAddSave) calAddSave.onclick = ()=>{
    const homeName = document.getElementById("cal-add-home").value;
    const awayName = document.getElementById("cal-add-away").value;
    const compId = document.getElementById("cal-add-comp").value;
    const stage = document.getElementById("cal-add-stage").value.trim() || "Liga";
    const statusEl = document.getElementById("cal-add-status");

    const homeTeam = db.teams.find(t=>t.name===homeName);
    const awayTeam = db.teams.find(t=>t.name===awayName);
    const homeId = homeTeam ? homeTeam.id : "";
    const awayId = awayTeam ? awayTeam.id : "";

    if(!homeId || !awayId || !compId){
       statusEl.textContent = "⚠️ Selecciona local, visitante y competición de la lista.";
       return;
    }
    if(homeId === awayId){
       statusEl.textContent = "⚠️ El local y visitante no pueden ser el mismo.";
       return;
    }

    const comp = (db.leagues||[]).find(l=>l.id===compId);


    const matchId = uid("fm");
    
    const payloadHome = {
      id: matchId,
      date: calDate,
      rivalTeamId: awayId,
      competition: comp ? comp.name : "Liga",
      competitionId: compId,
      competitionType: normalizeCompetitionType(comp ? comp.type : "league"),
      stage: stage,
      isHome: true,
      importanceTag: "nada en juego"
    };
    homeTeam.futureMatches = homeTeam.futureMatches || [];
    homeTeam.futureMatches.push(payloadHome);

    upsertMirrorFutureMatch({ db, team: homeTeam, rival: awayTeam, match: payloadHome });

    saveDb(db);
    statusEl.textContent = "✅ Guardado";
    setTimeout(()=>render("calendario",{ calDate }), 600);
  };

  // ── enviar al radar ──────────────────────────────────────────────
  content.querySelectorAll(".cal-radar-btn").forEach(btn=>{
    btn.onclick = (e)=>{
      const targetIdx = e.currentTarget.getAttribute("data-cal-idx");
      const entry = calMatches[Number(targetIdx)];
      if(!entry) return;
      
      const { homeTeam, awayTeam, fm } = entry;
      // Al enviar al radar, queremos ver ese partido sin filtros de liga
      radarState.filters.manualLeagueId = ""; 
      
      const radarMatch = {
        id: fm.id || uid("tr"),
        date: fm.date || calDate,
        homeId: homeTeam.id,
        awayId: awayTeam.id,
        leagueId: fm.competitionId || homeTeam.leagueId || "",
        league: fm.competition || "Liga",
        odds: { home: fm.oddsHome, draw: fm.oddsDraw, away: fm.oddsAway }
      };
      render("radar", { match: radarMatch });
    };
  });

  // ── borrar partido ──────────────────────────────────────────────
  content.querySelectorAll(".cal-delete-btn").forEach(btn => {
    btn.onclick = () => {
      const idx = btn.dataset.calIdx;
      const entry = calMatches[Number(idx)];
      if (!entry) return;
      const { fm, originTeam, homeTeam, awayTeam } = entry;
      const rivalName = originTeam.id === homeTeam.id ? awayTeam.name : homeTeam.name;
      
      if (!confirm(`¿Borrar el partido programado contra ${rivalName}?`)) return;
      
      // Borrar del equipo de origen
      originTeam.futureMatches = (originTeam.futureMatches || []).filter(m => m.id !== fm.id);
      
      // Borrar del rival (espejo)
      const rivalId = fm.rivalTeamId;
      const rivalTeam = db.teams.find(t => t.id === rivalId);
      if (rivalTeam) {
        rivalTeam.futureMatches = (rivalTeam.futureMatches || []).filter(m => 
          m.id !== fm.id && m.mirrorOf !== fm.id && !(m.date === fm.date && m.rivalTeamId === originTeam.id)
        );
      }
      
      saveDb(db);
      render("calendario", { calDate });
    };
  });

  // ── editar partido ──────────────────────────────────────────────
  content.querySelectorAll(".cal-edit-btn").forEach(btn => {
    btn.onclick = () => {
      const idx = btn.dataset.calIdx;
      const entry = calMatches[Number(idx)];
      if (!entry) return;
      const { fm, originTeam } = entry;
      
      if (typeof openFutureMatchModal === "function") {
        openFutureMatchModal({
          db,
          team: originTeam,
          matchId: fm.id,
          onSave: () => render("calendario", { calDate })
        });
      } else {
        alert("Función de edición (openFutureMatchModal) no disponible.");
      }
    };
  });


  // ── ir a perfil de equipo ───────────────────────────────────────
  content.querySelectorAll(".cal-team-link").forEach(span=>{
    span.onclick = ()=>{
      render("equipo", { teamId: span.dataset.teamId });
    };
  });


  // ── toggle formulario de registro ─────────────────────────────────

  content.querySelectorAll(".cal-reg-btn").forEach(btn=>{
    btn.onclick = ()=>{
      const idx = btn.dataset.calIdx;
      const form = document.getElementById(`cal-form-${idx}`);
      if(form) form.style.display = form.style.display==="none" ? "block" : "none";
    };
  });


  content.querySelectorAll(".cal-cancel-btn").forEach(btn=>{
    btn.onclick = ()=>{
      const form = document.getElementById(`cal-form-${btn.dataset.calIdx}`);
      if(form) form.style.display = "none";
    };
  });

  // ── guardar resultado (Paso 1: Mostrar Notas) ──────────────────────
  content.querySelectorAll(".cal-save-btn").forEach(btn=>{
    btn.onclick = ()=>{
      const idx        = btn.dataset.calIdx;
      const homeId     = btn.dataset.homeId;
      const awayId     = btn.dataset.awayId;
      const entry      = calMatches[Number(idx)];
      
      const homeGoals = Number(document.getElementById(`cal-hg-${idx}`).value)||0;
      const awayGoals = Number(document.getElementById(`cal-ag-${idx}`).value)||0;

      // Mostrar lista de jugadores para valorar
      const ratingsDiv = document.getElementById(`cal-ratings-${idx}`);
      const listDiv = document.getElementById(`cal-ratings-list-${idx}`);
      const formDiv = document.getElementById(`cal-form-${idx}`);
      
      formDiv.style.display = "none";
      ratingsDiv.style.display = "block";
      
      const players = db.players.filter(p => p.teamId === homeId || p.teamId === awayId);
      // Solo mostrar jugadores de los dos equipos involucrados
      listDiv.innerHTML = `
        <div style="margin-bottom:8px;font-size:0.8rem;color:#8892a4;">Introduce nota (1-10) para los jugadores que participaron:</div>
        ${players.map(p => `
          <div style="display:flex;align-items:center;gap:10px;padding:4px 0;border-bottom:1px solid #30363d;">
            <span style="font-size:0.85rem;width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name} <small>(${p.teamId === homeId ? 'LOC' : 'VIS'})</small></span>
            <input type="number" step="0.1" min="1" max="10" placeholder="-" class="cal-p-rating" data-p-id="${p.id}"
              style="width:50px;background:#0d1117;border:1px solid #30363d;color:#e6edf3;border-radius:4px;padding:2px 4px;text-align:center;">
          </div>
        `).join('')}
      `;
    };
  });

  content.querySelectorAll(".cal-ratings-cancel-btn").forEach(btn=>{
    btn.onclick = ()=>{
      const idx = btn.dataset.calIdx;
      document.getElementById(`cal-ratings-${idx}`).style.display = "none";
      document.getElementById(`cal-form-${idx}`).style.display = "block";
    };
  });

  // ── guardar resultado final (Paso 2: Procesar ELO) ─────────────────
  content.querySelectorAll(".cal-final-save-btn").forEach(btn=>{
    btn.onclick = ()=>{
      const idx        = btn.dataset.calIdx;
      const homeId     = btn.dataset.homeId;
      const awayId     = btn.dataset.awayId;
      const fmId       = btn.dataset.fmId;
      const compId     = btn.dataset.competitionId || db.settings.selectedLeagueId || "";
      const statusEl   = document.getElementById(`cal-status-${idx}`);

      const homeGoals = Number(document.getElementById(`cal-hg-${idx}`).value)||0;
      const awayGoals = Number(document.getElementById(`cal-ag-${idx}`).value)||0;

      // Verificar duplicado
      if(findTrackerResult(homeId, awayId, calDate)){
        statusEl.textContent = "⚠️ Ya existe un resultado.";
        return;
      }

      // 1. Crear el partido en el tracker
      const newMatch = ensureTrackerMatchState({
        id: uid("tr"),
        leagueId: compId,
        date: calDate,
        homeId, awayId, homeGoals, awayGoals,
        note: "Registrado manualmente con ELO", stats: [], statsRaw: null,
        featureSnapshots: {}, featureSnapshotStatus: {}
      });
      db.tracker.push(newMatch);

      // 2. Procesar Ratings y ELO
      const resultHome = homeGoals > awayGoals ? 1 : (homeGoals === awayGoals ? 0.5 : 0);
      const resultAway = 1 - resultHome;

      const ratingInputs = document.querySelectorAll(`#cal-ratings-list-${idx} .cal-p-rating`);
      ratingInputs.forEach(input => {
        const rating = parseFloat(input.value);
        if(!isNaN(rating)){
          const playerId = input.dataset.pId;
          const player = db.players.find(p => p.id === playerId);
          if(player){
            const isHomePlayer = player.teamId === homeId;
            const matchResult = isHomePlayer ? resultHome : resultAway;
            
            // Función de cálculo (definida en footballLab_v8e pero la replicamos aquí para seguridad)
            const K = 30;
            const ratingImpact = (rating - 6.7) * 8; 
            const resultImpact = (matchResult - 0.5) * 15;
            const change = Math.round(ratingImpact + resultImpact);
            
            player.elo = (player.elo || 1200) + change;
            player.sofaRating = rating; // Guardar como último rating
            
            // Incrementar PJ si ha sido valorado (se asume que jugó)
            player.appearances = (player.appearances || 0) + 1;
          }
        }
      });

      // 3. Limpiar partidos futuros
      db.teams.forEach(t=>{
        t.futureMatches = (t.futureMatches||[]).filter(m=>
          m.id !== fmId && m.mirrorOf !== fmId
        );
      });

      saveDb(db);
      statusEl.textContent = "✅ Guardado y ELO actualizado";
      setTimeout(()=>render("calendario",{ calDate }), 800);
    };
  });
}

export async function syncLeagueMatchesFromApi(db, leagueId, deps) {
  const { apiFetch, uid, ensureTrackerMatchState, upsertMirrorFutureMatch, saveDb } = deps;
  
  if(!leagueId) throw new Error("ID de liga no válido");
  if(!db.settings.apiToken) throw new Error("Falta API Token");
  
  const statusEl = document.getElementById("syncGlobalStatus");
  if(statusEl) statusEl.textContent = "⌛ Conectando con API...";

  try {
    const league = db.leagues.find(l => l.id === leagueId);
    let apiCode = (league?.code || leagueId).toUpperCase();
    
    // Mapeo básico de ligas comunes de Flashscore a Football-Data
    const mapping = {
      "LG_0507E6A43D0": "BL1", // Bundesliga
      "LG_3F41893A": "PL",     // Premier League
      "LG_PD": "PD",           // LaLiga
      "LG_SA": "SA",           // Serie A
      "LG_FL1": "FL1"          // Ligue 1
    };
    if (mapping[apiCode]) apiCode = mapping[apiCode];

    // Si sigue pareciendo un ID de Flashscore (LG_...), no es compatible
    if (apiCode.startsWith("LG_") || apiCode.length > 5) {
      throw new Error(`La liga "${league?.name || apiCode}" no tiene un código compatible con la API automática. Usa la importación manual de Flashscore.`);
    }

    // Determinar la temporada adecuada (Football-Data usa el año de inicio)
    // Si estamos en mayo o junio de 2026, la temporada es 2025 (2025/26)
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1; // 1-12
    let apiSeason = db.settings.season || String(currentYear);
    
    // Si la temporada guardada coincide con el año actual y estamos en la primera mitad del año,
    // es muy probable que queramos la temporada que empezó el año anterior.
    if (apiSeason === String(currentYear) && currentMonth <= 6) {
      apiSeason = String(currentYear - 1);
    }

    const data = await apiFetch(`/competitions/${apiCode}/matches?season=${apiSeason}`, db.settings.apiToken);
    const apiMatches = data.matches || [];
    
    const teamMap = new Map();
    db.teams.forEach(t => { if(t.apiTeamId) teamMap.set(String(t.apiTeamId), t.id); });
    
    let trackerCount = 0;
    let futureCount = 0;
    const leagueName = db.leagues.find(l => l.id === leagueId)?.name || "Liga";

    apiMatches.forEach(m => {
      const homeLocalId = teamMap.get(String(m.homeTeam.id));
      const awayLocalId = teamMap.get(String(m.awayTeam.id));
      
      if(!homeLocalId || !awayLocalId) return;
      
      const matchDate = m.utcDate.split("T")[0];
      
      if(m.status === 'FINISHED') {
        const exists = db.tracker.some(tm => 
          tm.date === matchDate && 
          tm.homeId === homeLocalId && 
          tm.awayId === awayLocalId
        );
        
        if(!exists) {
          const newMatch = ensureTrackerMatchState({
            id: uid("tr"),
            leagueId,
            date: matchDate,
            homeId: homeLocalId,
            awayId: awayLocalId,
            homeGoals: m.score.fullTime.home,
            awayGoals: m.score.fullTime.away,
            note: "Sincronizado vía API",
            stats: [],
            statsRaw: null,
            featureSnapshots: {},
            featureSnapshotStatus: {}
          });
          db.tracker.push(newMatch);
          trackerCount++;
        }
      } else if(['SCHEDULED', 'TIMED', 'LIVE', 'IN_PLAY', 'PAUSED'].includes(m.status)) {
        const homeTeam = db.teams.find(t => t.id === homeLocalId);
        if(homeTeam) {
          homeTeam.futureMatches ||= [];
          const exists = homeTeam.futureMatches.some(fm => 
            fm.date === matchDate && 
            fm.rivalTeamId === awayLocalId
          );
          
          if(!exists) {
            const newFm = {
              id: uid("fm"),
              date: matchDate,
              rivalTeamId: awayLocalId,
              isHome: true,
              competition: leagueName,
              importanceTag: "Programado",
              status: "pending"
            };
            homeTeam.futureMatches.push(newFm);
            upsertMirrorFutureMatch(db, homeTeam, newFm);
            futureCount++;
          }
        }
      }
    });
    
    if(statusEl) statusEl.textContent = `✅ Sincronizado: ${trackerCount} resultados, ${futureCount} próximos.`;
    saveDb(db);
    return { trackerCount, futureCount };
  } catch(err) {
    if(statusEl) statusEl.textContent = `❌ Error API: ${err.message}`;
    throw err;
  }
}

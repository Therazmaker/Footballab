import json
import os
import glob

# Rutas de base de datos
BASE_DIR = r"c:\Users\Herraz Marrero\Documents\MemoryCarl-main (4)\futbollab_standalone"
MATCHPACKS_DIR = os.path.join(BASE_DIR, "brain", "matchpacks")
PROFILES_DIR = os.path.join(BASE_DIR, "brain", "database", "profiles")

def get_team_style(stats, side):
    """Determina el estilo de juego basado en estadisticas"""
    pos = stats.get('normalized', {}).get('possession', {}).get(side, 50)
    xg = stats.get('normalized', {}).get('xg', {}).get(side, 0)
    
    if pos > 60:
        return "Dominante (Posesión)"
    elif pos < 40 and xg > 1.5:
        return "Contraataque Letal"
    elif pos < 40 and xg < 1.0:
        return "Defensivo Cerrado"
    else:
        return "Equilibrado"

def update_team_dna(team_name, opponent_name, result, opponent_style):
    """Actualiza el perfil del equipo con fortalezas/debilidades"""
    # Intentar buscar por ID primero en los perfiles
    profiles = glob.glob(os.path.join(PROFILES_DIR, "*.json"))
    profile_path = None
    
    # 1. Buscar por nombre exacto dentro del JSON
    for p in profiles:
        try:
            with open(p, 'r', encoding='utf-8') as f:
                p_data = json.load(f)
                if p_data.get('teamName', '').lower() == team_name.lower():
                    profile_path = p
                    break
        except:
            continue
            
    if not profile_path:
        # 2. Fallback: buscar por nombre de archivo
        for p in profiles:
            if team_name.lower().replace(' ', '_') in os.path.basename(p).lower():
                profile_path = p
                break
                
    if not profile_path:
        print(f"No se encontro perfil para {team_name}")
        return

    with open(profile_path, 'r', encoding='utf-8') as f:
        profile = json.load(f)

    if 'tactical_dna' not in profile:
        profile['tactical_dna'] = {
            "strengths": {},
            "weaknesses": {},
            "nemesis": {}, # Equipos especificos
            "victims": {}  # Equipos que siempre le gana
        }

    dna = profile['tactical_dna']

    # Analizar por estilo de oponente
    style_key = opponent_style
    if result == 'W':
        dna['strengths'][style_key] = dna['strengths'].get(style_key, 0) + 1
        dna['victims'][opponent_name] = dna['victims'].get(opponent_name, 0) + 1
    elif result == 'L':
        dna['weaknesses'][style_key] = dna['weaknesses'].get(style_key, 0) + 1
        dna['nemesis'][opponent_name] = dna['nemesis'].get(opponent_name, 0) + 1
    elif result == 'D':
        # Empate contra un equipo mas fuerte (Dominante) es una fortaleza
        if opponent_style == "Dominante (Posesión)":
            dna['strengths'][style_key] = dna['strengths'].get(style_key, 0) + 0.5
        # Empate contra un equipo defensivo siendo favorito es una debilidad
        elif opponent_style == "Defensivo Cerrado":
            dna['weaknesses'][style_key] = dna['weaknesses'].get(style_key, 0) + 0.5

    with open(profile_path, 'w', encoding='utf-8') as f:
        json.dump(profile, f, indent=2, ensure_ascii=False)
    
    print(f"ADN actualizado para {team_name}: Fuerte contra {dna['strengths']}, Debil contra {dna['weaknesses']}")

def process_matchpacks():
    matchpacks = glob.glob(os.path.join(MATCHPACKS_DIR, "*.json"))
    for mp_path in matchpacks:
        with open(mp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        home = data['match']['home']
        away = data['match']['away']
        score = data['match']['score']
        stats = data.get('stats', {})
        
        home_style = get_team_style(stats, 'home')
        away_style = get_team_style(stats, 'away')
        
        # Determinar resultados
        if score['home'] > score['away']:
            res_home, res_away = 'W', 'L'
        elif score['home'] < score['away']:
            res_home, res_away = 'L', 'W'
        else:
            res_home, res_away = 'D', 'D'
            
        # Actualizar ADN
        update_team_dna(home, away, res_home, away_style)
        update_team_dna(away, home, res_away, home_style)

if __name__ == "__main__":
    process_matchpacks()

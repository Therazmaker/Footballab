import os, json
tr_dir = 'brain/database/tracker'
sa_teams = ['inter','milan','juventus','atalanta','roma','lazio','napoli','fiorentina','torino','bologna','genoa','monza','lecce','udinese','verona','cagliari','empoli','parma','como','venezia']
wrong = []
for f in os.listdir(tr_dir):
    p = os.path.join(tr_dir, f)
    with open(p, 'r', encoding='utf-8') as j: m = json.load(j)
    if m.get('leagueId') == 'lg_z0lkmnis0ge':
        hn = m.get('homeName','').lower()
        an = m.get('awayName','').lower()
        if hn not in sa_teams or an not in sa_teams:
            wrong.append(f"{hn} vs {an}")
print("Wrong matches in Serie A:", wrong)

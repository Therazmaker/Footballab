import os, json

tr_dir = 'brain/database/tracker'
teams_dir = 'brain/database/teams'
SERIE_A_ID = 'lg_z0lkmnis0ge'
LIGUE1_ID  = 'lg_f06f449614c'

# Contar cuantos partidos tiene cada equipo en cada liga
def count_matches_per_team(league_id):
    counts = {}
    for f in os.listdir(tr_dir):
        if not f.endswith('.json'): continue
        with open(os.path.join(tr_dir, f), 'r', encoding='utf-8') as j:
            m = json.load(j)
        if m.get('leagueId') == league_id:
            for tid, tname in [(m.get('homeId'), m.get('homeName')), (m.get('awayId'), m.get('awayName'))]:
                if tid:
                    counts[tname] = counts.get(tname, 0) + 1
    return counts

print("=== Partidos por equipo en Serie A ===")
sa_counts = count_matches_per_team(SERIE_A_ID)
for name, cnt in sorted(sa_counts.items(), key=lambda x: -x[1]):
    print(f"  {name}: {cnt} partidos")

print(f"\n  Total equipos con partidos: {len(sa_counts)}")

print("\n=== Partidos por equipo en Ligue 1 ===")
l1_counts = count_matches_per_team(LIGUE1_ID)
for name, cnt in sorted(l1_counts.items(), key=lambda x: -x[1]):
    print(f"  {name}: {cnt} partidos")

print(f"\n  Total equipos con partidos: {len(l1_counts)}")

import os
import json
import uuid
import datetime
import urllib.request
import ssl

ssl._create_default_https_context = ssl._create_unverified_context

teams_dir = 'brain/database/teams'
profiles_dir = 'brain/database/profiles'
tracker_dir = 'brain/database/tracker'
leagues_dir = 'brain/database/leagues'

def ensure_bundesliga():
    for f in os.listdir(leagues_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(leagues_dir, f), 'r', encoding='utf-8') as j:
                l = json.load(j)
                if 'bundesliga' in l.get('name', '').lower() or l.get('id') == 'lg_bundesliga':
                    return l['id']
        except: continue
    
    lid = 'lg_bundesliga'
    league_obj = {
        "id": lid,
        "name": "Alemania: Bundesliga",
        "code": "BL1",
        "type": "league"
    }
    with open(os.path.join(leagues_dir, f"{lid}.json"), 'w', encoding='utf-8') as j:
        json.dump(league_obj, j, indent=2)
    return lid

def get_existing_teams():
    team_name_to_id = {}
    for f in os.listdir(teams_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
                t = json.load(j)
                if t.get('name') and t.get('id'):
                    team_name_to_id[t['name'].lower()] = t['id']
        except: continue
    return team_name_to_id

def ensure_team(team_name, league_id, existing_teams):
    name_lower = team_name.lower()
    for k, v in existing_teams.items():
        if name_lower == k or name_lower in k or k in name_lower:
            return v
    
    tid = f"tm_{uuid.uuid4().hex[:11]}"
    team_obj = {
      "id": tid,
      "name": team_name,
      "apiTeamId": "",
      "leagueId": league_id,
      "meta": { "stadium": "", "city": "", "capacity": "" },
      "intProfile": {
        "priorityCompetition": "Liga", "seasonGoal": "", "squadDepth": 3,
        "coachRotation": 3, "styleTags": [], "derbyRivals": [], "seasonContext": "",
        "modeLens": "empresa", "seasonObjective": "", "coachRotationPolicy": 3,
        "psychTags": [], "rivalries": [],
        "seasonBase": { "pj": 0, "g": 0, "e": 0, "p": 0, "gf": 0, "gc": 0, "dg": 0, "pts": 0, "position": 0 }
      },
      "futureMatches": [], "intSnapshotsByMatchId": {}, "intPatterns": {}, "intMatchStateById": {},
      "contextoEstrategico": { "rachaLocal": "", "ausenciasClave": [], "patrones": [], "factorDia": {} }
    }
    with open(os.path.join(teams_dir, f"{tid}.json"), 'w', encoding='utf-8') as j:
        json.dump(team_obj, j, indent=2)
    
    existing_teams[name_lower] = tid
    return tid

def ensure_profile(tid, team_name):
    profile_path = os.path.join(profiles_dir, f"id_{tid}.json")
    if os.path.exists(profile_path):
        return
    prof_obj = {
        "teamId": tid,
        "teamName": team_name,
        "matchRefs": [],
        "updatedAt": int(datetime.datetime.now().timestamp() * 1000)
    }
    with open(profile_path, 'w', encoding='utf-8') as j:
        json.dump(prof_obj, j, indent=2)

def main():
    print("Obteniendo datos de OpenLigaDB...")
    try:
        url = 'https://api.openligadb.de/getmatchdata/bl1/2025'
        req = urllib.request.urlopen(url)
        data = json.loads(req.read())
    except Exception as e:
        print(f"Error descargando datos: {e}")
        return
    
    print(f"Descargados {len(data)} partidos.")
    
    league_id = ensure_bundesliga()
    existing_teams = get_existing_teams()
    
    matches_added = 0
    for m in data:
        if not m.get('matchIsFinished') and not m.get('matchResults'):
            continue
            
        home_name = m['team1']['teamName']
        away_name = m['team2']['teamName']
        date_str = m['matchDateTime'][:10]
        
        results = m.get('matchResults', [])
        home_goals = 0
        away_goals = 0
        if results:
            # Buscar el resultado final (resultTypeID 2: Endergebnis)
            final_result = next((r for r in results if r.get('resultTypeID') == 2), results[0])
            home_goals = final_result.get('pointsTeam1', 0)
            away_goals = final_result.get('pointsTeam2', 0)
            
        h_id = ensure_team(home_name, league_id, existing_teams)
        a_id = ensure_team(away_name, league_id, existing_teams)
        
        ensure_profile(h_id, home_name)
        ensure_profile(a_id, away_name)
        
        h_profile_path = os.path.join(profiles_dir, f"id_{h_id}.json")
        with open(h_profile_path, 'r', encoding='utf-8') as j:
            h_prof = json.load(j)
        if any(ref.get('date') == date_str for ref in h_prof.get('matchRefs', [])):
            continue
            
        m_id = f"tr_{uuid.uuid4().hex[:12]}"
        
        match_obj = {
            "id": m_id,
            "leagueId": league_id,
            "date": date_str,
            "homeId": h_id,
            "awayId": a_id,
            "homeGoals": home_goals,
            "awayGoals": away_goals,
            "homeName": home_name,
            "awayName": away_name,
            "note": "Temporada 25/26 (OpenLigaDB)",
            "opponentStrengthByTeam": {}
        }
        
        with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
            json.dump(match_obj, j, indent=2)
            
        score_str = f"{home_goals}-{away_goals}"
        for tid in [h_id, a_id]:
            p_path = os.path.join(profiles_dir, f"id_{tid}.json")
            with open(p_path, 'r', encoding='utf-8') as j:
                p = json.load(j)
            
            if 'matchRefs' not in p: p['matchRefs'] = []
            opp_name = away_name if tid == h_id else home_name
            p['matchRefs'].append({
                "memoryId": m_id,
                "teamId": tid,
                "teamName": p.get('teamName'),
                "date": date_str,
                "opponent": opp_name,
                "score": score_str
            })
            p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
            with open(p_path, 'w', encoding='utf-8') as j:
                json.dump(p, j, indent=2)
                
        matches_added += 1

    print(f"Proceso finalizado. {matches_added} partidos nuevos inyectados.")

if __name__ == '__main__':
    main()

import os, json

teams_dir = 'brain/database/teams'
SERIE_A_ID = 'lg_z0lkmnis0ge'
LIGUE1_ID = 'lg_f06f449614c'

# Mapeo completo nombre -> liga
SERIE_A_NAMES = {
    'inter', 'milan', 'ac milan', 'juventus', 'atalanta', 'roma', 'as roma',
    'lazio', 'napoli', 'fiorentina', 'torino', 'bologna', 'bolonia', 'genoa',
    'monza', 'lecce', 'udinese', 'verona', 'hellas verona', 'cagliari',
    'empoli', 'parma', 'como', 'venezia', 'sassuolo', 'pisa', 'cremonese',
    'frosinone', 'salernitana', 'spezia'
}

needs_fix = []
for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    p = os.path.join(teams_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        t = json.load(j)
    name = t.get('name', '').lower()
    league = t.get('leagueId', '')
    if name in SERIE_A_NAMES and league != SERIE_A_ID:
        needs_fix.append((f, t.get('name'), league))

for f, name, old in needs_fix:
    p = os.path.join(teams_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        t = json.load(j)
    t['leagueId'] = SERIE_A_ID
    with open(p, 'w', encoding='utf-8') as j:
        json.dump(t, j, indent=2, ensure_ascii=False)
    print(f"  FIX: {name} (era: '{old}') -> Serie A")

# Count final
sa_teams = []
l1_teams = []
for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
        t = json.load(j)
    if t.get('leagueId') == SERIE_A_ID:
        sa_teams.append(t.get('name'))
    elif t.get('leagueId') == LIGUE1_ID:
        l1_teams.append(t.get('name'))

print(f"\n=== RESULTADO FINAL ===")
print(f"Serie A ({len(sa_teams)} equipos): {sorted(sa_teams)}")
print(f"\nLigue 1 ({len(l1_teams)} equipos): {sorted(l1_teams)}")

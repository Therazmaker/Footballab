import os
import json
import uuid
import datetime

profiles_dir = 'brain/database/profiles'
tracker_dir = 'brain/database/tracker'

def get_team_map():
    team_map = {}
    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(profiles_dir, f), 'r', encoding='utf-8') as j:
                p = json.load(j)
                name = p.get('teamName', '')
                tid = p.get('teamId', '')
                if name and tid:
                    team_map[name.lower()] = tid
        except: continue
    return team_map

def find_id(name, team_map):
    name = name.lower()
    norm = name.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
    for k, v in team_map.items():
        k_norm = k.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
        if norm == k_norm or norm in k_norm or k_norm in norm: return v
    overrides = {
        "psg": "psg", "stade rennais": "rennes", "monaco": "monaco", "strasbourg": "estrasburgo",
        "nice": "niza", "marseille": "marsella", "saint-etienne": "st étienne"
    }
    if norm in overrides:
        target = overrides[norm]
        for k, v in team_map.items():
            k_norm = k.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
            if target in k_norm: return v
    return None

team_map = get_team_map()

nantes_all_matches = [
    {"date": "2025-08-17", "home": "Nantes", "away": "PSG", "score": "0-1"},
    {"date": "2025-08-24", "home": "Estrasburgo", "away": "Nantes", "score": "1-0"},
    {"date": "2025-08-30", "home": "Nantes", "away": "Auxerre", "score": "1-0"},
    {"date": "2025-09-13", "home": "Niza", "away": "Nantes", "score": "1-0"},
    {"date": "2025-09-20", "home": "Nantes", "away": "Stade Rennais", "score": "2-2"},
    {"date": "2025-09-27", "home": "Toulouse", "away": "Nantes", "score": "2-2"},
    {"date": "2025-10-04", "home": "Brest", "away": "Nantes", "score": "1-0"},
    {"date": "2025-10-19", "home": "Nantes", "away": "Lille", "score": "1-1"},
    {"date": "2025-10-24", "home": "Paris FC", "away": "Nantes", "score": "1-2"},
    {"date": "2025-10-29", "home": "Nantes", "away": "Monaco", "score": "3-5"},
    {"date": "2025-11-02", "home": "Nantes", "away": "Metz", "score": "0-2"},
    {"date": "2025-11-08", "home": "Le Havre", "away": "Nantes", "score": "1-1"},
    {"date": "2025-11-23", "home": "Nantes", "away": "Lorient", "score": "1-1"},
    {"date": "2025-11-30", "home": "Lyon", "away": "Nantes", "score": "3-0"},
    {"date": "2025-12-06", "home": "Nantes", "away": "Lens", "score": "1-2"},
    {"date": "2025-12-12", "home": "Angers", "away": "Nantes", "score": "4-1"},
    {"date": "2026-01-04", "home": "Marsella", "away": "Nantes", "score": "0-2"},
    {"date": "2026-01-18", "home": "Nantes", "away": "Paris FC", "score": "1-2"},
    {"date": "2026-01-25", "home": "Nantes", "away": "Niza", "score": "1-4"},
    {"date": "2026-01-31", "home": "Lorient", "away": "Nantes", "score": "2-1"},
    {"date": "2026-02-07", "home": "Nantes", "away": "Lyon", "score": "0-1"},
    {"date": "2026-02-13", "home": "Monaco", "away": "Nantes", "score": "3-1"},
    {"date": "2026-02-22", "home": "Nantes", "away": "Le Havre", "score": "2-0"},
    {"date": "2026-03-01", "home": "Lille", "away": "Nantes", "score": "1-0"},
    {"date": "2026-03-07", "home": "Nantes", "away": "Angers", "score": "0-1"},
    {"date": "2026-03-22", "home": "Nantes", "away": "Estrasburgo", "score": "2-3"},
    {"date": "2026-04-05", "home": "Metz", "away": "Nantes", "score": "0-0"},
    {"date": "2026-04-11", "home": "Auxerre", "away": "Nantes", "score": "0-0"},
    {"date": "2026-04-19", "home": "Nantes", "away": "Brest", "score": "1-1"},
    {"date": "2026-04-22", "home": "PSG", "away": "Nantes", "score": "3-0"},
    {"date": "2026-04-26", "home": "Stade Rennais", "away": "Nantes", "score": "2-1"},
    {"date": "2025-05-02", "home": "Nantes", "away": "Marsella", "score": "0-3"}
]

print(f"Inyectando {len(nantes_all_matches)} partidos del Nantes...")

for m in nantes_all_matches:
    h_id = find_id(m['home'], team_map)
    a_id = find_id(m['away'], team_map)
    if not h_id or not a_id: continue
    
    m_id = f"tr_{uuid.uuid4().hex[:12]}"
    score_parts = m['score'].split('-')
    
    match_obj = {
        "id": m_id, "leagueId": "lg_z0lkmnis0ge", "date": m['date'],
        "homeId": h_id, "awayId": a_id,
        "homeGoals": int(score_parts[0]), "awayGoals": int(score_parts[1]),
        "homeName": m['home'], "awayName": m['away'],
        "note": "Nantes 25/26 History (Inyectado)",
        "opponentStrengthByTeam": {}
    }
    
    with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
        json.dump(match_obj, j, indent=2)
    
    for tid in [h_id, a_id]:
        profile_file = os.path.join(profiles_dir, f"id_{tid}.json")
        if not os.path.exists(profile_file): continue
        with open(profile_file, 'r', encoding='utf-8') as j:
            p = json.load(j)
        if 'matchRefs' not in p: p['matchRefs'] = []
        if not any(ref.get('date') == m['date'] for ref in p['matchRefs']):
            p['matchRefs'].append({
                "memoryId": m_id, "teamId": tid, "teamName": p.get('teamName'),
                "date": m['date'], "opponent": m['away'] if tid == h_id else m['home'],
                "score": m['score']
            })
            p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
            with open(profile_file, 'w', encoding='utf-8') as j:
                json.dump(p, j, indent=2)

print("Inyección del Nantes completada.")

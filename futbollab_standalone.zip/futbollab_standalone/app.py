from flask import Flask, request, jsonify, send_from_directory, make_response
import os
import json
import hashlib
import time
import threading
import urllib.request
import ssl
import re
from datetime import datetime

active_pollers = {}
poller_lock = threading.Lock()

app = Flask(__name__, static_folder='.')

# ── CACHÉ EN MEMORIA ────────────────────────────────────────────────────────
# Elimina las ~2500 lecturas de disco en cada carga de la app.
# Estructura: { 'footballDB': {'data': {...}, 'ts': 1234, 'etag': 'abc'}, ... }
_cache = {}

def _cache_get(key):
    return _cache.get(key)

def _cache_set(key, data):
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True)
    etag = hashlib.md5(raw.encode()).hexdigest()
    _cache[key] = {'data': data, 'ts': time.time(), 'etag': etag}
    return etag

def _cache_invalidate(key):
    _cache.pop(key, None)

# ── DIRECTORIOS ─────────────────────────────────────────────────────────────
BRAIN_DIR = os.path.join(os.getcwd(), 'brain')

DB_SUBDIRS = {
    'teams':   os.path.join(BRAIN_DIR, 'database', 'teams'),
    'leagues': os.path.join(BRAIN_DIR, 'database', 'leagues'),
    'tracker': os.path.join(BRAIN_DIR, 'database', 'tracker'),
    'players': os.path.join(BRAIN_DIR, 'database', 'players'),
    'profiles':os.path.join(BRAIN_DIR, 'database', 'profiles'),
    'meta':    os.path.join(BRAIN_DIR, 'meta')
}

for path in DB_SUBDIRS.values():
    os.makedirs(path, exist_ok=True)

for sd in ['memories', 'training', 'general']:
    os.makedirs(os.path.join(BRAIN_DIR, sd), exist_ok=True)

# ── UTILIDADES ───────────────────────────────────────────────────────────────
def sanitize(name):
    return "".join([c for c in name if c.isalnum() or c in (' ', '.', '_', ':')]).rstrip().replace(':', '_').replace(' ', '_')

def _load_json_dir(directory):
    """Lee todos los archivos JSON de un directorio."""
    items = []
    try:
        for fname in os.listdir(directory):
            if fname.endswith('.json'):
                fpath = os.path.join(directory, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8') as f:
                        items.append(json.load(f))
                except Exception as e:
                    print(f"[WARN] No se pudo leer {fpath}: {e}")
    except FileNotFoundError:
        pass
    return items

# ── RECONSTRUIR / DIVIDIR DB ─────────────────────────────────────────────────
def reconstruct_db(db_type):
    """Reconstruye la DB desde caché (rápido) o desde disco (primera vez)."""
    cached = _cache_get(db_type)
    if cached:
        return cached['data']

    print(f"[Cache MISS] Cargando {db_type} desde disco...")

    if db_type == 'footballDB':
        skeleton_path = os.path.join(DB_SUBDIRS['meta'], "footballDB_skeleton.json")
        if not os.path.exists(skeleton_path):
            return None
        with open(skeleton_path, 'r', encoding='utf-8') as f:
            db = json.load(f)
        db['teams']   = _load_json_dir(DB_SUBDIRS['teams'])
        db['leagues'] = _load_json_dir(DB_SUBDIRS['leagues'])
        db['tracker'] = _load_json_dir(DB_SUBDIRS['tracker'])
        db['players'] = _load_json_dir(DB_SUBDIRS['players'])
        _cache_set('footballDB', db)
        print(f"  → {len(db['teams'])} equipos, {len(db['tracker'])} partidos, {len(db['players'])} jugadores cargados.")
        return db

    elif db_type == 'FL_BRAIN_V2':
        skeleton_path = os.path.join(DB_SUBDIRS['meta'], "FL_BRAIN_V2_skeleton.json")
        if not os.path.exists(skeleton_path):
            return None
        with open(skeleton_path, 'r', encoding='utf-8') as f:
            db = json.load(f)
        db['teamProfiles'] = {}
        for fname in os.listdir(DB_SUBDIRS['profiles']):
            if not fname.endswith('.json'):
                continue
            key = fname[:-5]
            if key.startswith('id_tm_'):
                key = 'id:tm_' + key[6:]
            else:
                key = key.replace('_', ':')
            fpath = os.path.join(DB_SUBDIRS['profiles'], fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as j:
                    db['teamProfiles'][key] = json.load(j)
            except Exception as e:
                print(f"[WARN] Perfil no leído {fpath}: {e}")
        _cache_set('FL_BRAIN_V2', db)
        print(f"  → {len(db['teamProfiles'])} perfiles de equipo cargados.")
        return db

    return None


def split_and_save_db(db_type, data):
    """Divide la DB en archivos individuales y actualiza el caché."""
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except:
            pass
    if not isinstance(data, dict):
        print(f"[WARN] Datos de {db_type} no son un dict. Ignorando.")
        return

    if db_type == 'footballDB':
        for team in data.get('teams', []):
            tid = team.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['teams'], f"{sanitize(tid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(team, f, ensure_ascii=False)

        for league in data.get('leagues', []):
            lid = league.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['leagues'], f"{sanitize(lid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(league, f, ensure_ascii=False)

        for match in data.get('tracker', []):
            mid = match.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['tracker'], f"{sanitize(mid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(match, f, ensure_ascii=False)

        for player in data.get('players', []):
            pid = player.get('id', 'unknown')
            with open(os.path.join(DB_SUBDIRS['players'], f"{sanitize(pid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(player, f, ensure_ascii=False)

        skeleton = data.copy()
        for k in ['teams', 'leagues', 'tracker', 'players']:
            skeleton[k] = []
        with open(os.path.join(DB_SUBDIRS['meta'], "footballDB_skeleton.json"), 'w', encoding='utf-8') as f:
            json.dump(skeleton, f, ensure_ascii=False)

        _cache_set('footballDB', data)

    elif db_type == 'FL_BRAIN_V2':
        for tid, profile in data.get('teamProfiles', {}).items():
            with open(os.path.join(DB_SUBDIRS['profiles'], f"{sanitize(tid)}.json"), 'w', encoding='utf-8') as f:
                json.dump(profile, f, ensure_ascii=False)

        skeleton = data.copy()
        skeleton['teamProfiles'] = {}
        with open(os.path.join(DB_SUBDIRS['meta'], "FL_BRAIN_V2_skeleton.json"), 'w', encoding='utf-8') as f:
            json.dump(skeleton, f, ensure_ascii=False)

        _cache_set('FL_BRAIN_V2', data)


# ── RUTAS ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/sportradar_tracker.html')
def tracker_page():
    return send_from_directory('.', 'sportradar_tracker.html')

@app.route('/src/<path:path>')
def send_src(path):
    response = make_response(send_from_directory('src', path))
    # Archivos estáticos: caché de 5 minutos en el navegador
    response.headers['Cache-Control'] = 'public, max-age=300'
    return response

@app.route('/api/storage/list', methods=['GET'])
def list_storage():
    keys = ['footballDB', 'FL_BRAIN_V2']
    general_dir = os.path.join(BRAIN_DIR, 'general')
    if os.path.exists(general_dir):
        for fname in os.listdir(general_dir):
            if fname.endswith('.json'):
                keys.append(fname[:-5])
    return jsonify({"keys": list(set(keys))})

@app.route('/api/storage/get', methods=['GET'])
def get_storage():
    key = request.args.get('key')
    if not key:
        return jsonify({"error": "Missing key"}), 400

    if key in ['footballDB', 'FL_BRAIN_V2']:
        data = reconstruct_db(key)
        if data:
            cached = _cache_get(key)
            etag = cached['etag'] if cached else ''
            # ETag: si el cliente ya tiene la versión actual, responder 304 sin datos
            if request.headers.get('If-None-Match') == etag:
                return ('', 304)
            json_str = json.dumps(data, ensure_ascii=False)
            response = make_response(jsonify({"value": json_str}))
            response.headers['ETag'] = etag
            response.headers['Cache-Control'] = 'no-cache'
            return response
        return jsonify({"value": None})

    # Fallback: búsqueda directa en archivos
    filename = sanitize(key) + '.json'
    for root, dirs, files in os.walk(BRAIN_DIR):
        if filename in files:
            with open(os.path.join(root, filename), 'r', encoding='utf-8') as f:
                try:
                    val = json.load(f)
                    if not isinstance(val, str):
                        val = json.dumps(val, ensure_ascii=False)
                    return jsonify({"value": val})
                except:
                    return jsonify({"value": None})
    return jsonify({"value": None})

@app.route('/api/storage/set', methods=['POST'])
def set_storage():
    data = request.json
    key = data.get('key')
    value = data.get('value')
    if not key:
        return jsonify({"error": "Missing key"}), 400

    if key in ['footballDB', 'FL_BRAIN_V2']:
        _cache_invalidate(key)
        split_and_save_db(key, value)
        return jsonify({"success": True})

    file_path = os.path.join(BRAIN_DIR, 'general', sanitize(key) + '.json')
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False)
    return jsonify({"success": True})

@app.route('/api/storage/delete', methods=['POST'])
def delete_storage():
    key = request.json.get('key')
    if not key:
        return jsonify({"error": "Missing key"}), 400
    _cache_invalidate(key)
    filename = sanitize(key) + '.json'
    for root, dirs, files in os.walk(BRAIN_DIR):
        if filename in files:
            os.remove(os.path.join(root, filename))
            return jsonify({"success": True})
    return jsonify({"success": False, "reason": "Not found"})

@app.route('/api/radar_ai', methods=['POST'])
def proxy_radar_ai():
    try:
        import requests
        payload = request.json
        api_url = "https://api.ollama.com/api/chat"
        api_key = "601550831c4149c2aac76f4a11a44d6e.i8Lyy5xT7VqNSYai6vapcM8R"
        headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}

        if "prompt" in payload and "messages" not in payload:
            payload = {"model": "gpt-oss:120b", "messages": [{"role": "user", "content": payload["prompt"]}], "stream": False}
        if "model" not in payload or payload["model"] == "llama3.2":
            payload["model"] = "gpt-oss:120b"

        response = requests.post(api_url, json=payload, headers=headers, timeout=60)
        if response.status_code != 200:
            print(f"--- AI PROXY ERROR {response.status_code} ---\n{response.text}\n---")

        excluded = ['content-encoding', 'content-length', 'transfer-encoding', 'connection']
        filtered = [(n, v) for (n, v) in response.headers.items() if n.lower() not in excluded]
        return (response.text, response.status_code, filtered)
    except Exception as e:
        print(f"--- AI PROXY EXCEPTION: {e} ---")
        return jsonify({"error": str(e)}), 500

@app.route('/api/proxy/football-data/<path:path>', methods=['GET'])
def proxy_football_data(path):
    import requests
    token = request.args.get('token')
    qs = "&".join([p for p in request.query_string.decode('utf-8').split('&') if not p.startswith('token=')])
    url = f"https://api.football-data.org/v4/{path}" + (f"?{qs}" if qs else "")
    headers = {"X-Auth-Token": token} if token else {}
    try:
        r = requests.get(url, headers=headers, timeout=30)
        return (r.text, r.status_code, [('Access-Control-Allow-Origin', '*')])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/proxy/odds-api/<path:path>', methods=['GET'])
def proxy_odds_api(path):
    import requests
    qs = request.query_string.decode('utf-8')
    url = f"https://api.the-odds-api.com/v4/{path}" + (f"?{qs}" if qs else "")
    try:
        r = requests.get(url, timeout=30)
        return (r.text, r.status_code, [('Access-Control-Allow-Origin', '*')])
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/tracker/push_event', methods=['POST', 'OPTIONS'])
def push_tracker_event():
    if request.method == 'OPTIONS':
        response = make_response()
        response.headers.add("Access-Control-Allow-Origin", "*")
        response.headers.add("Access-Control-Allow-Headers", "Content-Type")
        response.headers.add("Access-Control-Allow-Methods", "POST")
        return response

    data = request.json
    if not data or 'matchId' not in data:
        return jsonify({"error": "Missing data"}), 400

    match_id = sanitize(data['matchId'])
    tracker_path = os.path.join(DB_SUBDIRS['tracker'], f"{match_id}.json")
    
    if os.path.exists(tracker_path):
        with open(tracker_path, 'r', encoding='utf-8') as f:
            match_data = json.load(f)
    else:
        match_data = {"id": match_id, "live_events": []}
        
    if "live_events" not in match_data:
        match_data["live_events"] = []
        
    match_data["live_events"].append(data)
    
    with open(tracker_path, 'w', encoding='utf-8') as f:
        json.dump(match_data, f, ensure_ascii=False)
        
    _cache_invalidate('footballDB')
    
    response = jsonify({"success": True, "event_logged": data['action']})
    response.headers.add("Access-Control-Allow-Origin", "*")
    return response

@app.route('/api/tracker/get/<match_id>', methods=['GET'])
def get_tracker_data(match_id):
    match_id = sanitize(match_id)
    tracker_path = os.path.join(DB_SUBDIRS['tracker'], f"{match_id}.json")
    print(f"🔍 Buscando tracker en: {tracker_path}")
    
    if os.path.exists(tracker_path):
        with open(tracker_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        res = jsonify(data)
        res.headers.add("Access-Control-Allow-Origin", "*")
        return res
    
    # Intento secundario: buscar cualquier archivo que contenga el ID
    for fname in os.listdir(DB_SUBDIRS['tracker']):
        if match_id in fname and fname.endswith('.json'):
            with open(os.path.join(DB_SUBDIRS['tracker'], fname), 'r', encoding='utf-8') as f:
                data = json.load(f)
            res = jsonify(data)
            res.headers.add("Access-Control-Allow-Origin", "*")
            return res

    return jsonify({"error": f"Tracker {match_id} not found", "path_checked": tracker_path}), 404

@app.route('/api/sportradar/current', methods=['GET'])
def get_current_tracker_full():
    """Devuelve el historial COMPLETO del partido que se está trackeando ahora."""
    with poller_lock:
        active_ids = [mid for mid, p in active_pollers.items() if p['active']]
    
    if not active_ids:
        return jsonify({"error": "No hay tracker activo"}), 404
        
    match_id = active_ids[0]
    tracker_path = os.path.join(DB_SUBDIRS['tracker'], f"{match_id}.json")
    if os.path.exists(tracker_path):
        with open(tracker_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        res = jsonify(data)
        res.headers.add("Access-Control-Allow-Origin", "*")
        return res
    return jsonify({"error": "Archivo no encontrado"}), 404


def sportradar_poller_worker(match_id, url):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    headers = {
        'Origin': 'https://doradobet.com',
        'Referer': 'https://doradobet.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    
    eventos_procesados = set()
    
    def get_interval(minute):
        if minute is None: return None
        # Primera Parte
        if minute <= 15: return "1T 0-15'"
        if minute <= 30: return "1T 15-30'"
        if minute <= 45: return "1T 30-45'"
        # Segunda Parte (Minutos relativos)
        rel_2t = minute - 45
        if rel_2t <= 15: return "2T 0-15'"
        if rel_2t <= 30: return "2T 15-30'"
        if rel_2t <= 45: return "2T 30-45'"
        return "2T 45+'"

    def map_action(type_str):
        if not type_str: return None
        type_str = str(type_str).lower()
        mapping = {
            "dangerous_attack": "Atq. Peligroso",
            "attack": "Ataque",
            "safe_possession": "Posesión",
            "possession": "Posesión",
            "corner": "Corner",
            "shotontarget": "Tiro Portería",
            "shotofftarget": "Tiro Fuera",
            "goal": "Gol",
            "goal_kick": "Saque Meta",
            "goalkeeper_saved": "Parada",
            "free_kick": "Tiro Libre",
            "foul": "Falta",
            "card": "Falta",
            "offside": "Fuera Juego",
            "save": "Parada",
            "yellow_card": "Tarj. Amarilla",
            "red_card": "Tarj. Roja",
            "substitution": "Cambio",
            "periodstart": "Inicio",
            "periodend": "Fin"
        }
        if type_str in mapping: return mapping[type_str]
        
        # Búsquedas parciales más estrictas
        if type_str == "goal": return "Gol"
        if "attack" in type_str: return "Ataque"
        if "possession" in type_str: return "Posesión"
        if "ballcoordinates" in type_str: return "Posición Balón"
        return None

    active_pollers[match_id]['last_minute'] = 0
    
    while True:
        with poller_lock:
            if match_id not in active_pollers or not active_pollers[match_id]['active']:
                break
                
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, context=ctx) as response:
                data = json.loads(response.read().decode('utf-8'))
                
            def extract_events(obj):
                if isinstance(obj, dict):
                    for k in ['events', 'timeline']:
                        if k in obj and isinstance(obj[k], list) and len(obj[k]) > 0:
                            return obj[k]
                    for v in obj.values():
                        res = extract_events(v)
                        if res: return res
                elif isinstance(obj, list):
                    for item in obj:
                        res = extract_events(item)
                        if res: return res
                return None
                
            events = extract_events(data)
                
            if events and isinstance(events, list):
                print(f"   [Tracker] {match_id}: Detectados {len(events)} eventos en JSON")
                new_events = []
                for ev in events:
                    min_val = ev.get('match_time') or ev.get('time')
                    if min_val and min_val > 0:
                        active_pollers[match_id]['last_minute'] = min_val
                    
                    min_time = min_val if (min_val and min_val > 0) else active_pollers[match_id]['last_minute']
                    
                    ev_type = ev.get('type')
                    if ev_type == 'matchsituation' and ev.get('matchsituation'):
                        ev_type = ev.get('matchsituation')
                        
                    team = ev.get('team')
                    ev_id = ev.get('id') or f"{min_time}_{ev_type}_{team}"
                    
                    if ev_id in eventos_procesados: continue
                    eventos_procesados.add(ev_id)
                    
                    interval = get_interval(min_time)
                    action = map_action(ev_type) or f"Evento ({ev_type})"
                    
                    # Buscamos coordenadas en mayúsculas y minúsculas (Sportradar alterna)
                    x = ev.get('X') if ev.get('X') is not None else ev.get('x')
                    y = ev.get('Y') if ev.get('Y') is not None else ev.get('y')
                    coords = ev.get('coordinates')

                    # Si tiene coordenadas, lo guardamos SÍ O SÍ, aunque no tenga acción mapeada
                    if x is not None or y is not None or coords:
                        print(f"      + Capturado: [{interval}] {action} ({team}) en [{x}, {y}]")
                        team_label = "LOCAL" if team == "home" else ("VISITANTE" if team == "away" else "NONE")
                        ev_obj = {
                            "matchId": match_id,
                            "minute": min_time,
                            "interval": interval,
                            "action": action,
                            "team": team_label,
                            "rawType": ev_type,
                            "timestamp": datetime.now().isoformat()
                        }
                        if x is not None: ev_obj["x"] = x
                        if y is not None: ev_obj["y"] = y
                        if coords: ev_obj["coordinates"] = coords
                        
                        new_events.append(ev_obj)
                    elif action in ["Gol", "Tiro Portería", "Tiro Fuera", "Falta", "Tarj. Amarilla"]:
                        # Eventos importantes aunque no tengan coordenadas (para el log)
                        print(f"      * Evento Clave (Sin Coords): [{interval}] {action} ({team})")
                        team_label = "LOCAL" if team == "home" else ("VISITANTE" if team == "away" else "NONE")
                        new_events.append({
                            "matchId": match_id,
                            "minute": min_time,
                            "interval": interval,
                            "action": action,
                            "team": team_label,
                            "rawType": ev_type,
                            "timestamp": datetime.now().isoformat()
                        })
                        
                if new_events:
                    print(f"   [Tracker] {match_id}: Guardando {len(new_events)} nuevos eventos.")
                    tracker_path = os.path.join(DB_SUBDIRS['tracker'], f"{match_id}.json")
                    if os.path.exists(tracker_path):
                        with open(tracker_path, 'r', encoding='utf-8') as f:
                            match_data = json.load(f)
                    else:
                        match_data = {"id": match_id, "live_events": []}
                        
                    if "live_events" not in match_data:
                        match_data["live_events"] = []
                        
                    match_data["live_events"].extend(new_events)
                    
                    with open(tracker_path, 'w', encoding='utf-8') as f:
                        json.dump(match_data, f, ensure_ascii=False)
                        
                    _cache_invalidate('footballDB')
                    
                    with poller_lock:
                        if match_id in active_pollers:
                            active_pollers[match_id]['last_events'] = new_events
                            active_pollers[match_id]['total'] += len(new_events)
                            active_pollers[match_id]['last_check'] = datetime.now().isoformat()
        
        except Exception as e:
            print(f"[Tracker] Error para {match_id}: {e}")
            
        time.sleep(5)

@app.route('/api/sportradar/start', methods=['POST', 'OPTIONS'])
def start_sportradar():
    if request.method == 'OPTIONS':
        res = make_response()
        res.headers.add("Access-Control-Allow-Origin", "*")
        res.headers.add("Access-Control-Allow-Headers", "Content-Type")
        return res
        
    data = request.json
    url = data.get('url')
    match_id = data.get('matchId')
    
    if not url: return jsonify({"error": "Missing URL"}), 400
    
    # Si es una URL delta, intentar convertirla a timeline normal para traer el historial completo al inicio
    if "match_timelinedelta" in url:
        url = url.replace("match_timelinedelta", "match_timeline")
        
    if not match_id:
        m = re.search(r'match_[a-z]+/(\d+)', url)
        if m: match_id = m.group(1)
        else: match_id = "unknown_" + str(int(time.time()))
        
    match_id = sanitize(match_id)
    
    with poller_lock:
        if match_id in active_pollers and active_pollers[match_id]['active']:
            pass # Ya activo
        else:
            active_pollers[match_id] = {
                "active": True,
                "url": url,
                "thread": threading.Thread(target=sportradar_poller_worker, args=(match_id, url), daemon=True),
                "last_events": [],
                "total": 0,
                "last_check": None
            }
            active_pollers[match_id]["thread"].start()
            
    res = jsonify({"success": True, "matchId": match_id})
    res.headers.add("Access-Control-Allow-Origin", "*")
    return res

@app.route('/api/sportradar/stop', methods=['POST', 'OPTIONS'])
def stop_sportradar():
    if request.method == 'OPTIONS':
        res = make_response()
        res.headers.add("Access-Control-Allow-Origin", "*")
        res.headers.add("Access-Control-Allow-Headers", "Content-Type")
        return res
        
    match_id = sanitize(request.json.get('matchId', ''))
    with poller_lock:
        if match_id in active_pollers:
            active_pollers[match_id]['active'] = False
            
    res = jsonify({"success": True})
    res.headers.add("Access-Control-Allow-Origin", "*")
    return res

@app.route('/api/sportradar/status', methods=['GET'])
def status_sportradar():
    with poller_lock:
        status = {}
        for mid, p in active_pollers.items():
            if p['active']:
                status[mid] = {
                    "total": p["total"],
                    "last_check": p["last_check"],
                    "last_events": p["last_events"]
                }
    res = jsonify(status)
    res.headers.add("Access-Control-Allow-Origin", "*")
    return res

if __name__ == '__main__':
    import os as _os
    # Solo pre-cargar en el proceso principal (no en el reloader hijo)
    if _os.environ.get('WERKZEUG_RUN_MAIN') == 'true' or True:
        print("🚀 FootballLab con caché en memoria activo...")
        try:
            print("   Pre-cargando footballDB...")
            reconstruct_db('footballDB')
            print("   Pre-cargando FL_BRAIN_V2...")
            reconstruct_db('FL_BRAIN_V2')
            print("✅ Caché lista. Servidor en http://127.0.0.1:5000")
        except Exception as e:
            print(f"[WARN] Pre-carga fallida: {e}. Se cargará al primer request.")
    app.run(debug=True, port=5000, use_reloader=False)

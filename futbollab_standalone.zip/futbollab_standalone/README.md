# FootballLab Standalone

Este proyecto es una versión independiente del módulo FootballLab, extraída de MemoryCarl. Funciona con un servidor **Flask (Python)** que gestiona el almacenamiento de datos ("Cerebro") directamente en carpetas del sistema.

## Requisitos

- Python 3.7 o superior instalado.

## Instalación

1.  Abre una terminal en la carpeta `futbollab_standalone`.
2.  Instala las dependencias:
    ```bash
    pip install -r requirements.txt
    ```

## Cómo ejecutar

### Opción A: Usando el script de ejecución (Recomendado)
Simplemente haz doble clic en `run.bat`.

### Opción B: Desde la terminal
Ejecuta el servidor con:
```bash
python app.py
```
Luego abre tu navegador en: [http://localhost:5000](http://localhost:5000)

## Estructura del "Cerebro" (Datos)

Los datos se guardan en la carpeta `brain/`, organizada de la siguiente manera:

-   `brain/memories/`: Partidos y datos históricos de equipos.
-   `brain/profiles/`: Perfiles de rendimiento de equipos.
-   `brain/meta/`: Configuraciones y metadatos globales.
-   `brain/training/`: Datos relacionados con el entrenamiento del motor radar.
-   `brain/general/`: Otros datos persistentes.

Cada vez que la aplicación guarda algo, se crea o actualiza un archivo `.json` en la carpeta correspondiente.

## Notas Técnicas

-   Se ha implementado un bridge (`window.storage`) en `index.html` que redirige las llamadas de almacenamiento (que originalmente iban a `localStorage`) hacia la API de Flask.
-   El servidor está configurado en modo `debug=True` por defecto para facilitar el desarrollo.

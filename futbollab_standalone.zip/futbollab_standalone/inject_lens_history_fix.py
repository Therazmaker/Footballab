import os
import json
import uuid
import datetime

profiles_dir = 'brain/database/profiles'
tracker_dir = 'brain/database/tracker'

def get_team_map():
    team_map = {}
    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(profiles_dir, f), 'r', encoding='utf-8') as j:
                p = json.load(j)
                name = p.get('teamName', '')
                tid = p.get('teamId', '')
                if name and tid:
                    team_map[name.lower()] = tid
        except: continue
    return team_map

def find_id(name, team_map):
    name = name.lower()
    # Normalize some common variations
    norm = name.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
    for k, v in team_map.items():
        k_norm = k.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
        if norm == k_norm or norm in k_norm or k_norm in norm: return v
    
    overrides = {
        "marseille": "marsella", "nice": "niza", "rennes": "stade rennais",
        "monaco": "monaco", "strasbourg": "estrasburgo", "psg": "psg"
    }
    if norm in overrides:
        target = overrides[norm]
        for k, v in team_map.items():
            k_norm = k.replace('ó', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ú', 'u')
            if target in k_norm: return v
    return None

team_map = get_team_map()

# Matches involving Monaco/Mónaco that failed
missed_matches = [
    {"date": "2025-11-08", "home": "Monaco", "away": "Lens", "score": "1-4"},
    {"date": "2026-02-21", "home": "Lens", "away": "Monaco", "score": "2-3"},
]

for m in missed_matches:
    h_id = find_id(m['home'], team_map)
    a_id = find_id(m['away'], team_map)
    
    if not h_id or not a_id:
        print(f"Error IDs (still): {m['home']} vs {m['away']} (h={h_id}, a={a_id})")
        continue
        
    m_id = f"tr_{uuid.uuid4().hex[:12]}"
    score_parts = m['score'].split('-')
    
    match_obj = {
        "id": m_id, "leagueId": "lg_z0lkmnis0ge", "date": m['date'],
        "homeId": h_id, "awayId": a_id,
        "homeGoals": int(score_parts[0]), "awayGoals": int(score_parts[1]),
        "homeName": m['home'], "awayName": m['away'],
        "note": "Temporada Completa 25/26 (Inyectado)",
        "opponentStrengthByTeam": {}
    }
    
    with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
        json.dump(match_obj, j, indent=2)
    
    for tid in [h_id, a_id]:
        profile_file = os.path.join(profiles_dir, f"id_{tid}.json")
        if not os.path.exists(profile_file): continue
        with open(profile_file, 'r', encoding='utf-8') as j:
            p = json.load(j)
        if 'matchRefs' not in p: p['matchRefs'] = []
        if not any(ref.get('date') == m['date'] for ref in p['matchRefs']):
            p['matchRefs'].append({
                "memoryId": m_id, "teamId": tid, "teamName": p.get('teamName'),
                "date": m['date'], "opponent": m['away'] if tid == h_id else m['home'],
                "score": m['score']
            })
            p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
            with open(profile_file, 'w', encoding='utf-8') as j:
                json.dump(p, j, indent=2)

print("Inyección de remanentes completada.")

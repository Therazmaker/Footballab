import os
import json
import uuid
import datetime

profiles_dir = 'brain/database/profiles'
teams_dir = 'brain/database/teams'
tracker_dir = 'brain/database/tracker'

def repair_database():
    print("Reparando IDs de equipos...")
    team_name_to_id = {}
    
    # 1. Collect all IDs from teams_dir
    for f in os.listdir(teams_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
                t = json.load(j)
                name = t.get('name', '')
                tid = t.get('id', '')
                if name and tid:
                    team_name_to_id[name.lower()] = tid
        except: continue
        
    # 2. Update profiles if ID is missing
    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'): continue
        try:
            path = os.path.join(profiles_dir, f)
            with open(path, 'r', encoding='utf-8') as j:
                p = json.load(j)
            
            name = p.get('teamName', '').lower()
            current_id = p.get('teamId', '')
            
            if not current_id and name in team_name_to_id:
                p['teamId'] = team_name_to_id[name]
                with open(path, 'w', encoding='utf-8') as j:
                    json.dump(p, j, indent=2)
                print(f"Reparado: {p.get('teamName')} -> {p['teamId']}")
        except: continue

def get_team_map():
    team_map = {}
    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'): continue
        try:
            with open(os.path.join(profiles_dir, f), 'r', encoding='utf-8') as j:
                p = json.load(j)
                name = p.get('teamName', '')
                tid = p.get('teamId', '')
                if name and tid:
                    team_map[name.lower()] = tid
        except: continue
    return team_map

def find_id(name, team_map):
    name = name.lower()
    for k, v in team_map.items():
        if name == k or name in k or k in name: return v
    overrides = {
        "marseille": "marsella",
        "nice": "niza",
        "rennes": "stade rennais",
        "psg": "psg"
    }
    if name in overrides:
        target = overrides[name]
        for k, v in team_map.items():
            if target in k: return v
    return None

def run_update():
    team_map = get_team_map()
    matches_data = [
        {"date": "2026-03-14", "home": "Lorient", "away": "Lens", "score": "1-2"},
        {"date": "2026-03-20", "home": "Lens", "away": "Angers", "score": "5-1"},
        {"date": "2026-04-04", "home": "Lille", "away": "Lens", "score": "3-0"},
        {"date": "2026-04-17", "home": "Lens", "away": "Toulouse", "score": "3-2"},
        {"date": "2026-04-24", "home": "Brest", "away": "Lens", "score": "3-3"},
        {"date": "2026-05-02", "home": "Nice", "away": "Lens", "score": "1-1"},
        {"date": "2026-04-11", "home": "Auxerre", "away": "Nantes", "score": "0-0"},
        {"date": "2026-04-19", "home": "Nantes", "away": "Brest", "score": "1-1"},
        {"date": "2026-04-22", "home": "PSG", "away": "Nantes", "score": "3-0"},
        {"date": "2026-04-26", "home": "Rennes", "away": "Nantes", "score": "2-1"},
        {"date": "2026-05-02", "home": "Nantes", "away": "Marseille", "score": "0-3"},
    ]

    for m in matches_data:
        h_id = find_id(m['home'], team_map)
        a_id = find_id(m['away'], team_map)
        
        if not h_id or not a_id:
            print(f"Saltando: {m['home']} vs {m['away']} (IDs no encontrados: h={h_id}, a={a_id})")
            continue
            
        m_id = f"tr_{uuid.uuid4().hex[:12]}"
        score_parts = m['score'].split('-')
        
        match_obj = {
            "id": m_id,
            "leagueId": "lg_z0lkmnis0ge",
            "date": m['date'],
            "homeId": h_id,
            "awayId": a_id,
            "homeGoals": int(score_parts[0]),
            "awayGoals": int(score_parts[1]),
            "homeName": m['home'],
            "awayName": m['away'],
            "note": "Actualizado vía AI Research",
            "opponentStrengthByTeam": {}
        }
        
        with open(os.path.join(tracker_dir, f"{m_id}.json"), 'w', encoding='utf-8') as j:
            json.dump(match_obj, j, indent=2)
        
        for tid in [h_id, a_id]:
            # Find profile file
            profile_file = None
            for f in os.listdir(profiles_dir):
                if tid in f:
                    profile_file = os.path.join(profiles_dir, f)
                    break
            
            if not profile_file: continue
            
            with open(profile_file, 'r', encoding='utf-8') as j:
                p = json.load(j)
            
            if 'matchRefs' not in p: p['matchRefs'] = []
            
            if not any(ref.get('date') == m['date'] for ref in p['matchRefs']):
                opp_name = m['away'] if tid == h_id else m['home']
                p['matchRefs'].append({
                    "memoryId": m_id,
                    "teamId": tid,
                    "teamName": p.get('teamName'),
                    "date": m['date'],
                    "opponent": opp_name,
                    "score": m['score']
                })
                p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
                with open(profile_file, 'w', encoding='utf-8') as j:
                    json.dump(p, j, indent=2)

repair_database()
run_update()
print("Proceso finalizado.")

import requests
import json

# Configuración basada en los logs del usuario
API_KEY = "15ce0f0f900685e283746757013b414c"
SPORT = "soccer_germany_bundesliga"
URL = f"http://127.0.0.1:5000/api/proxy/odds-api/sports/{SPORT}/odds/?regions=eu&markets=h2h&bookmakers=pinnacle,bet365,williamhill&oddsFormat=decimal&apiKey={API_KEY}"

def test_api():
    print(f"Probando conexión a: {URL}")
    try:
        response = requests.get(URL)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"Éxito! Se recibieron {len(data)} partidos.")
            
            # Mostrar el primer partido como ejemplo
            if len(data) > 0:
                print("\nEjemplo de datos del primer partido:")
                print(json.dumps(data[0], indent=2))
                
                # Resumen de equipos encontrados
                print("\nResumen de partidos encontrados:")
                for m in data:
                    print(f"- {m['home_team']} vs {m['away_team']} ({m['commence_time']})")
        else:
            print(f"Error: {response.text}")
            
    except Exception as e:
        print(f"Excepción durante la prueba: {str(e)}")

if __name__ == "__main__":
    test_api()

import os
import json
import re
import uuid
import datetime

BRAIN_DIR = 'brain/database'
TEAMS_DIR = os.path.join(BRAIN_DIR, 'teams')
LEAGUES_DIR = os.path.join(BRAIN_DIR, 'leagues')
TRACKER_DIR = os.path.join(BRAIN_DIR, 'tracker')
PROFILES_DIR = os.path.join(BRAIN_DIR, 'profiles')

def normalize_name(name):
    if not name: return ""
    name = name.lower().strip()
    # Remove accents
    name = name.replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ó', 'o').replace('ú', 'u')
    # Remove common prefixes/suffixes but ONLY if they are not the only word
    parts = name.split()
    if len(parts) > 1:
        parts = [p for p in parts if p not in ('fc', 'ac', 'as', 'sc', 'rc', 'vfl', 'tsg', 'rb', 'ssc', 'stade', 'olympique')]
    
    name = " ".join(parts)
    name = "".join([c for c in name if c.isalnum() or c.isspace()])
    return " ".join(name.split())

class FootballParser:
    def __init__(self):
        self.teams = {} # normalized_name -> team_obj
        self.profiles = {} # normalized_name -> profile_obj
        self.load_teams()
        self.load_profiles()
        self.leagues = {} # name -> league_id
        self.load_leagues()

    def load_teams(self):
        if not os.path.exists(TEAMS_DIR): return
        for f in os.listdir(TEAMS_DIR):
            if f.endswith('.json'):
                with open(os.path.join(TEAMS_DIR, f), 'r', encoding='utf-8') as j:
                    team = json.load(j)
                    norm = normalize_name(team['name'])
                    if norm:
                        self.teams[norm] = team
                    for alias in team.get('aliases', []):
                        a_norm = normalize_name(alias)
                        if a_norm:
                            self.teams[a_norm] = team

    def load_profiles(self):
        if not os.path.exists(PROFILES_DIR): return
        for f in os.listdir(PROFILES_DIR):
            if f.endswith('.json'):
                with open(os.path.join(PROFILES_DIR, f), 'r', encoding='utf-8') as j:
                    profile = json.load(j)
                    norm = normalize_name(profile['teamName'])
                    if norm:
                        self.profiles[norm] = profile
                    for alias in profile.get('aliases', []):
                        a_norm = normalize_name(alias)
                        if a_norm:
                            self.profiles[a_norm] = profile

    def load_leagues(self):
        if not os.path.exists(LEAGUES_DIR): return
        for f in os.listdir(LEAGUES_DIR):
            if f.endswith('.json'):
                with open(os.path.join(LEAGUES_DIR, f), 'r', encoding='utf-8') as j:
                    league = json.load(j)
                    self.leagues[league['name'].lower()] = league['id']

    def get_or_create_league(self, name):
        name_l = name.lower()
        if name_l in self.leagues:
            return self.leagues[name_l]
        
        lid = f"lg_{uuid.uuid4().hex[:11]}"
        league = {
            "id": lid,
            "name": name,
            "code": "",
            "type": "league"
        }
        with open(os.path.join(LEAGUES_DIR, f"{lid}.json"), 'w', encoding='utf-8') as f:
            json.dump(league, f, indent=2, ensure_ascii=False)
        self.leagues[name_l] = lid
        return lid

    def find_team(self, name):
        norm = normalize_name(name)
        if not norm: return None

        # 1. Search in teams
        if norm in self.teams:
            return self.teams[norm]
        
        # 2. Search in profiles
        if norm in self.profiles:
            profile = self.profiles[norm]
            if profile.get('teamId'):
                # Try to load the team from that ID
                tid = profile['teamId']
                t_path = os.path.join(TEAMS_DIR, f"{tid}.json")
                if not os.path.exists(t_path):
                    t_path = os.path.join(TEAMS_DIR, f"id_{tid.replace(':', '_')}.json")
                
                if os.path.exists(t_path):
                    with open(t_path, 'r', encoding='utf-8') as j:
                        team = json.load(j)
                        self.teams[norm] = team
                        return team
            
            # If profile exists but no teamId, create the team
            return self.create_team_from_profile(profile)

        # 3. Fuzzy match in teams
        for t_norm, team in self.teams.items():
            if norm == t_norm: return team
        
        if len(norm) > 3:
            for t_norm, team in self.teams.items():
                if norm in t_norm or t_norm in norm:
                    return team

        # 4. Create new team and profile if really not found
        return self.create_new_team(name)

    def create_team_from_profile(self, profile):
        tid = f"tm_{uuid.uuid4().hex[:11]}"
        team = {
            "id": tid,
            "name": profile['teamName'],
            "country": "",
            "aliases": profile.get('aliases', []),
            "createdAt": int(datetime.datetime.now().timestamp() * 1000),
            "intProfile": {"priorityCompetition": "Liga"}
        }
        with open(os.path.join(TEAMS_DIR, f"{tid}.json"), 'w', encoding='utf-8') as f:
            json.dump(team, f, indent=2, ensure_ascii=False)
        
        # Update profile with teamId
        profile['teamId'] = tid
        # Find profile file
        p_path = os.path.join(PROFILES_DIR, f"name_{normalize_name(profile['teamName']).replace(' ', '_')}.json")
        with open(p_path, 'w', encoding='utf-8') as f:
            json.dump(profile, f, indent=2, ensure_ascii=False)
            
        self.teams[normalize_name(team['name'])] = team
        return team

    def create_new_team(self, name):
        print(f"Creating new team: {name}")
        tid = f"tm_{uuid.uuid4().hex[:11]}"
        team = {
            "id": tid,
            "name": name,
            "country": "",
            "aliases": [],
            "createdAt": int(datetime.datetime.now().timestamp() * 1000),
            "intProfile": {"priorityCompetition": "Liga"}
        }
        with open(os.path.join(TEAMS_DIR, f"{tid}.json"), 'w', encoding='utf-8') as f:
            json.dump(team, f, indent=2, ensure_ascii=False)
        
        # Create profile
        profile = {
            "teamId": tid,
            "teamName": name,
            "aliases": [name.lower()],
            "matchRefs": [],
            "updatedAt": int(datetime.datetime.now().timestamp() * 1000)
        }
        p_path = os.path.join(PROFILES_DIR, f"name_{normalize_name(name).replace(' ', '_')}.json")
        with open(p_path, 'w', encoding='utf-8') as f:
            json.dump(profile, f, indent=2, ensure_ascii=False)
            
        self.teams[normalize_name(name)] = team
        self.profiles[normalize_name(name)] = profile
        return team

    def register_match(self, match_data):
        home_name = match_data['home']
        away_name = match_data['away']
        home_goals = match_data['homeGoals']
        away_goals = match_data['awayGoals']
        date_str = match_data['date']
        jornada = match_data.get('jornada', '')
        league_name = match_data.get('league', 'Serie A') # Default to Serie A based on user request

        home_team = self.find_team(home_name)
        away_team = self.find_team(away_name)

        if not home_team or not away_team:
            print(f"Warning: Could not find teams for {home_name} vs {away_name}")
            return

        lid = self.get_or_create_league(league_name)
        mid = f"tr_{uuid.uuid4().hex[:12]}"
        
        # Create match record
        match_record = {
            "id": mid,
            "leagueId": lid,
            "homeId": home_team['id'],
            "awayId": away_team['id'],
            "homeName": home_team['name'],
            "awayName": away_team['name'],
            "homeGoals": home_goals,
            "awayGoals": away_goals,
            "date": date_str,
            "status": "finished",
            "jornada": jornada,
            "note": "Parsed from text"
        }

        with open(os.path.join(TRACKER_DIR, f"{mid}.json"), 'w', encoding='utf-8') as f:
            json.dump(match_record, f, indent=2, ensure_ascii=False)

        # Update profiles
        self.update_profile(home_team, match_record, is_home=True)
        self.update_profile(away_team, match_record, is_home=False)
        
        print(f"Registered: {home_team['name']} {home_goals}-{away_goals} {away_team['name']} ({date_str})")

    def update_profile(self, team, match, is_home):
        # Try both name_... and id_tm_... filenames
        profile_names = [f"name_{normalize_name(team['name']).replace(' ', '_')}.json", f"{team['id']}.json", f"id_{team['id'].replace(':', '_')}.json"]
        profile_path = None
        for pn in profile_names:
            p = os.path.join(PROFILES_DIR, pn)
            if os.path.exists(p):
                profile_path = p
                break
        
        if not profile_path:
            # Create new profile if not exists? For now just skip
            return

        with open(profile_path, 'r', encoding='utf-8') as f:
            profile = json.load(f)
        
        if 'matchRefs' not in profile:
            profile['matchRefs'] = []
        
        ref = {
            "memoryId": match['id'],
            "teamId": team['id'],
            "teamName": team['name'],
            "date": match['date'],
            "opponent": match['awayName'] if is_home else match['homeName'],
            "score": f"{match['homeGoals']}-{match['awayGoals']}"
        }
        profile['matchRefs'].append(ref)
        profile['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)

        with open(profile_path, 'w', encoding='utf-8') as f:
            json.dump(profile, f, indent=2, ensure_ascii=False)

def parse_input_text(text):
    lines = [l.strip() for l in text.split('\n') if l.strip()]
    parser = FootballParser()
    
    current_jornada = ""
    # Try to detect league from the first few lines
    default_league = "Serie A"
    for line in lines[:3]:
        # If line is not a date, not a jornada, and is reasonably long
        if not re.match(r'\d{2}\.\d{2}\.', line) and not line.lower().startswith('jornada') and len(line) > 3:
            default_league = line
            print(f"Detectada liga: {default_league}")
            break

    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Detect Jornada
        if line.lower().startswith('jornada'):
            current_jornada = line
            i += 1
            continue
        
        # Detect Date (formats: 04.05. 13:45 or 23.08.2025)
        if re.match(r'\d{2}\.\d{2}\.\s*(\d{2}:\d{2}|\d{4})', line):
            date_val = line
            # Convert to ISO format YYYY-MM-DD for correct database sorting/filtering
            try:
                if ':' in date_val: # Format 04.05. 13:45
                    day, month, rest = date_val.split('.', 2)
                    year = "2026" # Default year if missing
                    time = rest.strip()
                    date_val = f"{year}-{month.strip():0>2}-{day.strip():0>2} {time}"
                elif re.search(r'\.\d{4}', date_val): # Format 23.08.2025
                    day, month, year = date_val.split('.')
                    date_val = f"{year.strip()}-{month.strip():0>2}-{day.strip():0>2}"
            except:
                pass # Fallback to original if parsing fails
            
            try:
                # Robust search for Home, Away and Goals
                # 1. Home is usually the next line
                home = lines[i+1]
                
                # 2. Find Away (next string that isn't Home or a number)
                away = None
                home_goals = None
                away_goals = None
                
                idx = i + 2
                while idx < len(lines):
                    current = lines[idx]
                    # If it's a number and we don't have home_goals yet, it might be an interjected score
                    if current.isdigit():
                        if home_goals is None:
                            home_goals = int(current)
                        elif away_goals is None:
                            away_goals = int(current)
                    # If it's a name and not the same as home
                    elif current != home:
                        away = current
                        idx += 1
                        # Skip away duplicate if present
                        if idx < len(lines) and lines[idx] == away:
                            idx += 1
                        break
                    idx += 1
                
                # 3. If we didn't find goals interjected, look for them now
                while idx < len(lines) and (home_goals is None or away_goals is None):
                    current = lines[idx]
                    if current.isdigit():
                        if home_goals is None:
                            home_goals = int(current)
                        elif away_goals is None:
                            away_goals = int(current)
                    elif re.match(r'\d{2}\.\d{2}\.', current) or current.lower().startswith('jornada'):
                        # We hit the next match or round, stop looking for goals
                        break
                    idx += 1
                
                if away and home_goals is not None and away_goals is not None:
                    parser.register_match({
                        'date': date_val,
                        'home': home,
                        'away': away,
                        'homeGoals': home_goals,
                        'awayGoals': away_goals,
                        'jornada': current_jornada,
                        'league': default_league
                    })
                    i = idx # Move to the next match or end of current
                    continue
                else:
                    i += 1
                    continue
                    
            except Exception as e:
                print(f"Error parsing match at line {i} ('{line}'): {e}")
                i += 1
                continue
        
        i += 1

if __name__ == '__main__':
    input_file = 'flashscore_input.txt'
    if os.path.exists(input_file):
        print(f"Leyendo datos de {input_file}...")
        with open(input_file, 'r', encoding='utf-8') as f:
            data = f.read()
        parse_input_text(data)
    else:
        print(f"Error: No se encuentra el archivo {input_file}")

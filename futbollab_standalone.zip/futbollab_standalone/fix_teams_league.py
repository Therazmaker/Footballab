import os, json

teams_dir = 'brain/database/teams'
SERIE_A_ID = 'lg_z0lkmnis0ge'
LIGUE1_ID = 'lg_f06f449614c'

# Los 20 equipos reales de la Serie A 2025/26
SERIE_A_TEAMS = {
    'inter', 'milan', 'ac milan', 'juventus', 'atalanta', 'roma', 'lazio',
    'napoli', 'fiorentina', 'torino', 'bologna', 'genoa', 'monza', 'lecce',
    'udinese', 'verona', 'cagliari', 'empoli', 'parma', 'como', 'venezia',
    'hellas verona'
}

# Los equipos de la Ligue 1
LIGUE1_TEAMS = {
    'psg', 'paris saint-germain', 'mónaco', 'monaco', 'marsella', 'marseille',
    'lens', 'lille', 'niza', 'nice', 'lyon', 'olympique lyonnais',
    'stade rennais', 'rennes', 'reims', 'toulouse', 'estrasburgo', 'strasbourg',
    'montpellier', 'nantes', 'le havre', 'auxerre', 'angers',
    'saint-étienne', 'saint-etienne', 'brest', 'metz', 'paris fc', 'lorient'
}

print("=== Equipos actualmente asignados a Serie A ===")
wrong_in_sa = []
correct_in_sa = []

for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    p = os.path.join(teams_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        t = json.load(j)
    
    name = t.get('name', '').lower()
    league = t.get('leagueId', '')
    
    if league == SERIE_A_ID:
        if name in LIGUE1_TEAMS:
            wrong_in_sa.append((f, t.get('name'), name))
        else:
            correct_in_sa.append(t.get('name'))

print(f"Equipos CORRECTOS en Serie A: {len(correct_in_sa)} -> {correct_in_sa}")
print(f"\nEquipos MAL ASIGNADOS (Ligue 1 en Serie A): {len(wrong_in_sa)}")
for f, name, nl in wrong_in_sa:
    print(f"  {name}")

if wrong_in_sa:
    print("\nCorrigiendo leagueId de equipos Ligue 1 que estan en Serie A...")
    fixed = 0
    for f, name, nl in wrong_in_sa:
        p = os.path.join(teams_dir, f)
        with open(p, 'r', encoding='utf-8') as j:
            t = json.load(j)
        t['leagueId'] = LIGUE1_ID
        with open(p, 'w', encoding='utf-8') as j:
            json.dump(t, j, indent=2, ensure_ascii=False)
        fixed += 1
    print(f"Corregidos: {fixed} equipos -> movidos a Ligue 1")
else:
    print("\nNo hay equipos mal asignados.")

# Verificacion final
print("\n=== Verificacion final ===")
sa_count = 0
l1_count = 0
for f in os.listdir(teams_dir):
    if not f.endswith('.json'): continue
    with open(os.path.join(teams_dir, f), 'r', encoding='utf-8') as j:
        t = json.load(j)
    if t.get('leagueId') == SERIE_A_ID: sa_count += 1
    elif t.get('leagueId') == LIGUE1_ID: l1_count += 1

print(f"Equipos en Serie A: {sa_count}")
print(f"Equipos en Ligue 1: {l1_count}")

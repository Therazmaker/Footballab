import os
import json

tr_dir = 'brain/database/tracker'
profiles_dir = 'brain/database/profiles'

# IDs de las ligas que queremos limpiar
LIGUE1_ID = 'lg_f06f449614c'
SERIE_A_ID = 'lg_z0lkmnis0ge'

# Notas "limpias" que queremos mantener (los generados por nuestro script correcto)
KEEP_NOTES = {'Generado 25/26'}

# ─── Paso 1: Encontrar qué borrar ──────────────────────────────────────────
to_delete = []
to_keep = []

for f in os.listdir(tr_dir):
    if not f.endswith('.json'):
        continue
    p = os.path.join(tr_dir, f)
    with open(p, 'r', encoding='utf-8') as j:
        m = json.load(j)
    
    league = m.get('leagueId', '')
    note = m.get('note', '')

    if league in (LIGUE1_ID, SERIE_A_ID):
        if note not in KEEP_NOTES:
            to_delete.append((f, league, note, m.get('homeName',''), m.get('awayName','')))
        else:
            to_keep.append(f)

print(f"Partidos a MANTENER (limpios): {len(to_keep)}")
print(f"Partidos a BORRAR (viejos/sucios): {len(to_delete)}")
print("\nEjemplos de los que se van a borrar:")
for f, lg, note, h, a in to_delete[:10]:
    print(f"  [{lg}] {h} vs {a} — nota: '{note}'")

print("\n¿Confirmar borrado? (s/n): ", end='')
confirm = input().strip().lower()

if confirm == 's':
    # Recopilar IDs de partidos que se van a borrar
    deleted_ids = set()
    for f, lg, note, h, a in to_delete:
        mid = f.replace('.json', '')
        deleted_ids.add(mid)
        os.remove(os.path.join(tr_dir, f))
    
    print(f"\nBorrados {len(deleted_ids)} archivos de tracker.")
    
    # ─── Paso 2: Limpiar los matchRefs de los perfiles ──────────────────────
    print("Limpiando matchRefs en perfiles...")
    cleaned_profiles = 0
    removed_refs = 0

    for f in os.listdir(profiles_dir):
        if not f.endswith('.json'):
            continue
        p = os.path.join(profiles_dir, f)
        with open(p, 'r', encoding='utf-8') as j:
            profile = json.load(j)
        
        old_refs = profile.get('matchRefs', [])
        if not old_refs:
            continue
        
        new_refs = [ref for ref in old_refs if ref.get('memoryId') not in deleted_ids]
        
        if len(new_refs) != len(old_refs):
            removed = len(old_refs) - len(new_refs)
            removed_refs += removed
            profile['matchRefs'] = new_refs
            with open(p, 'w', encoding='utf-8') as j:
                json.dump(profile, j, indent=2, ensure_ascii=False)
            cleaned_profiles += 1

    print(f"Perfiles limpiados: {cleaned_profiles} ({removed_refs} referencias borradas)")
    print("\n✅ Limpieza completa.")
else:
    print("Cancelado.")

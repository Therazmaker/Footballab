import os
import json

BRAIN_DIR = 'brain/database'
LEAGUES_DIR = os.path.join(BRAIN_DIR, 'leagues')
TRACKER_DIR = os.path.join(BRAIN_DIR, 'tracker')
PROFILES_DIR = os.path.join(BRAIN_DIR, 'profiles')

def reset():
    print("Iniciando reseteo de la base de datos...")

    # 1. Clear Leagues
    print("Limpiando ligas...")
    if os.path.exists(LEAGUES_DIR):
        for f in os.listdir(LEAGUES_DIR):
            if f.endswith('.json'):
                os.remove(os.path.join(LEAGUES_DIR, f))
    
    # 2. Clear Tracker (Matches)
    print("Limpiando tracker (partidos)...")
    if os.path.exists(TRACKER_DIR):
        for f in os.listdir(TRACKER_DIR):
            if f.endswith('.json'):
                os.remove(os.path.join(TRACKER_DIR, f))

    # 3. Clear matchRefs in Profiles
    print("Limpiando referencias en perfiles...")
    if os.path.exists(PROFILES_DIR):
        for f in os.listdir(PROFILES_DIR):
            if f.endswith('.json'):
                path = os.path.join(PROFILES_DIR, f)
                with open(path, 'r', encoding='utf-8') as j:
                    try:
                        data = json.load(j)
                        if 'matchRefs' in data:
                            data['matchRefs'] = []
                        with open(path, 'w', encoding='utf-8') as jw:
                            json.dump(data, jw, indent=2, ensure_ascii=False)
                    except Exception as e:
                        print(f"Error procesando {f}: {e}")

    print("Reseteo completado.")

if __name__ == '__main__':
    reset()

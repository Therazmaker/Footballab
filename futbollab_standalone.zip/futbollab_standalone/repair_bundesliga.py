import os
import json
import urllib.request
import ssl
import datetime

ssl._create_default_https_context = ssl._create_unverified_context

tracker_dir = 'brain/database/tracker'
profiles_dir = 'brain/database/profiles'

def fetch_correct_data():
    print("Descargando resultados correctos de OpenLigaDB...")
    url = 'https://api.openligadb.de/getmatchdata/bl1/2025'
    req = urllib.request.urlopen(url)
    data = json.loads(req.read())
    
    correct_map = {}
    for m in data:
        home = m['team1']['teamName']
        away = m['team2']['teamName']
        date = m['matchDateTime'][:10]
        
        results = m.get('matchResults', [])
        if not results: continue
        
        final_result = next((r for r in results if r.get('resultTypeID') == 2), results[0])
        h_g = final_result.get('pointsTeam1', 0)
        a_g = final_result.get('pointsTeam2', 0)
        
        # Key by names and date
        correct_map[(home, away, date)] = (h_g, a_g)
    
    return correct_map

def repair():
    correct_map = fetch_correct_data()
    print(f"Mapeados {len(correct_map)} resultados correctos.")
    
    updates = 0
    match_id_map = {} # To update profiles later
    
    # 1. Update Tracker
    for f in os.listdir(tracker_dir):
        if not f.endswith('.json'): continue
        path = os.path.join(tracker_dir, f)
        with open(path, 'r', encoding='utf-8') as j:
            m = json.load(j)
        
        if m.get('note') != "Temporada 25/26 (OpenLigaDB)": continue
        
        key = (m.get('homeName'), m.get('awayName'), m.get('date'))
        if key in correct_map:
            h_g, a_g = correct_map[key]
            if m['homeGoals'] != h_g or m['awayGoals'] != a_g:
                print(f"Corrigiendo {m['homeName']} vs {m['awayName']} ({m['date']}): {m['homeGoals']}-{m['awayGoals']} -> {h_g}-{a_g}")
                m['homeGoals'] = h_g
                m['awayGoals'] = a_g
                m['note'] = "Temporada 25/26 (OpenLigaDB) [CORREGIDO]"
                with open(path, 'w', encoding='utf-8') as j:
                    json.dump(m, j, indent=2, ensure_ascii=False)
                updates += 1
                match_id_map[m['id']] = f"{h_g}-{a_g}"

    print(f"Actualizados {updates} partidos en el tracker.")

    # 2. Update Profiles
    if updates > 0:
        print("Sincronizando perfiles...")
        for f in os.listdir(profiles_dir):
            if not f.endswith('.json'): continue
            path = os.path.join(profiles_dir, f)
            with open(path, 'r', encoding='utf-8') as j:
                p = json.load(j)
            
            p_updated = False
            if 'matchRefs' in p:
                for ref in p['matchRefs']:
                    mid = ref.get('memoryId')
                    if mid in match_id_map:
                        ref['score'] = match_id_map[mid]
                        p_updated = True
            
            if p_updated:
                p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
                with open(path, 'w', encoding='utf-8') as j:
                    json.dump(p, j, indent=2, ensure_ascii=False)
        print("Perfiles sincronizados.")

if __name__ == '__main__':
    repair()

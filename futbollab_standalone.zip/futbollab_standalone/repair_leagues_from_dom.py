import os
import json
import re
import datetime

tracker_dir = 'brain/database/tracker'
profiles_dir = 'brain/database/profiles'

def normalize_name(name):
    if not name: return ""
    # Remove accents
    name = name.replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ó', 'o').replace('ú', 'u')
    name = name.replace('Á', 'A').replace('É', 'E').replace('Í', 'I').replace('Ó', 'O').replace('Ú', 'U')
    # Lower case and strip
    name = name.lower().strip()
    # Remove common prefixes/suffixes
    name = re.sub(r'\b(fc|ac|stade|as|olympique|rc|sc|vfl|tsg|rb|ssc|inter|acm|ac)\b', '', name)
    # Remove extra spaces
    name = " ".join(name.split())
    
    # Specific mappings
    mapping = {
        "paris saint germain": "psg",
        "paris st germain": "psg",
        "verona": "hellas verona",
        "atletico": "atletico de madrid", # Not Ligue 1 but for completeness
    }
    return mapping.get(name, name)

def parse_flashscore_dom(file_path):
    print(f"Procesando {file_path}...")
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    matches = []
    # Find match blocks
    blocks = re.split(r'id="g_1_', content)
    for b in blocks[1:]:
        # Participants
        # We try to find names using the class provided in the DOM snippet
        participants = re.findall(r'class="[^"]*wcl-name_jjfMf"[^>]*>([^<]+)</span>', b)
        if len(participants) < 2:
            # Try alternative regex
            participants = re.findall(r'class="event__(?:home|away)Participant"[^>]*>.*?>(.*?)</span>', b, re.DOTALL)
            if len(participants) < 2: continue
        
        home = participants[0].strip()
        away = participants[1].strip()
        
        # Score
        score_home_match = re.search(r'event__score--home"[^>]*>(\d+)</span>', b)
        score_away_match = re.search(r'event__score--away"[^>]*>(\d+)</span>', b)
        
        if score_home_match and score_away_match:
            h_g = int(score_home_match.group(1))
            a_g = int(score_away_match.group(1))
            matches.append({
                'home': home,
                'away': away,
                'homeGoals': h_g,
                'awayGoals': a_g
            })
            
    return matches

def repair():
    all_correct_matches = []
    if os.path.exists('Ligue 1 DOM.txt'):
        all_correct_matches.extend(parse_flashscore_dom('Ligue 1 DOM.txt'))
    if os.path.exists('Serie A DOM.txt'):
        all_correct_matches.extend(parse_flashscore_dom('Serie A DOM.txt'))
        
    print(f"Extraídos {len(all_correct_matches)} resultados reales de los DOM.")
    
    correct_map = {}
    for m in all_correct_matches:
        key = (normalize_name(m['home']), normalize_name(m['away']))
        correct_map[key] = (m['homeGoals'], m['awayGoals'])
        
    updates = 0
    match_id_map = {}
    unmatched_keys = set()
    total_simulated = 0
    
    tracker_files = [f for f in os.listdir(tracker_dir) if f.endswith('.json')]
    print(f"Escaneando {len(tracker_files)} archivos del tracker...")
    
    for f in tracker_files:
        path = os.path.join(tracker_dir, f)
        with open(path, 'r', encoding='utf-8') as j:
            m = json.load(j)
        
        if m.get('note') not in ["Generado 25/26", "Corregido con datos reales (Flashscore)"]: continue
        total_simulated += 1
        
        h_norm = normalize_name(m.get('homeName'))
        a_norm = normalize_name(m.get('awayName'))
        key = (h_norm, a_norm)
        
        if key in correct_map:
            h_g, a_g = correct_map[key]
            if m['homeGoals'] != h_g or m['awayGoals'] != a_g or m.get('note') == "Generado 25/26":
                if updates < 20: # Limit logging
                    print(f"Corrigiendo: {m['homeName']} vs {m['awayName']} -> {h_g}-{a_g}")
                m['homeGoals'] = h_g
                m['awayGoals'] = a_g
                m['note'] = "Corregido con datos reales (Flashscore)"
                with open(path, 'w', encoding='utf-8') as j:
                    json.dump(m, j, indent=2, ensure_ascii=False)
                updates += 1
                match_id_map[m['id']] = f"{h_g}-{a_g}"
        else:
            unmatched_keys.add(key)

    print(f"Partidos simulados encontrados: {total_simulated}")
    print(f"Actualizados/Verificados: {updates}")
    if unmatched_keys:
        print(f"No encontrados en DOM: {len(unmatched_keys)}")
        # Print some examples of unmatched to identify name issues
        print("Ejemplos no encontrados:")
        for k in list(unmatched_keys)[:10]:
            print(f"  {k[0]} vs {k[1]}")

    if updates > 0:
        print("Sincronizando perfiles...")
        for f in os.listdir(profiles_dir):
            if not f.endswith('.json'): continue
            path = os.path.join(profiles_dir, f)
            with open(path, 'r', encoding='utf-8') as j:
                p = json.load(j)
            
            p_updated = False
            if 'matchRefs' in p:
                for ref in p['matchRefs']:
                    mid = ref.get('memoryId')
                    if mid in match_id_map:
                        ref['score'] = match_id_map[mid]
                        p_updated = True
            
            if p_updated:
                p['updatedAt'] = int(datetime.datetime.now().timestamp() * 1000)
                with open(path, 'w', encoding='utf-8') as j:
                    json.dump(p, j, indent=2, ensure_ascii=False)
        print("Perfiles sincronizados.")

if __name__ == '__main__':
    repair()

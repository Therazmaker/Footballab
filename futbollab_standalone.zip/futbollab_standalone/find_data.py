import json

def find_key(obj, target, path=''):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if target == k:
                print(f"Found EXACT key match: {path}.{k}")
            if isinstance(v, str) and target in v:
                print(f"Found in string value of key '{k}': {path}.{k} (Value starts with: {v[:50]}...)")
            find_key(v, target, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            if isinstance(v, str) and target in v:
                print(f"Found in string element at index {i}: {path}[{i}] (Value starts with: {v[:50]}...)")
            find_key(v, target, f"{path}[{i}]")

print("Loading backup...")
with open('footballlab-brain-backup-v1-20260313-1711.json', 'r', encoding='utf-8') as f:
    b = json.load(f)

print("Searching for 'plays'...")
find_key(b, 'plays')
